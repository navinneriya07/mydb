// SVN:       $Id: EPLANToolbox.java 437 2017-09-14 09:45:49Z aska $            
package de.tesis.plmware.eda_eplan;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.lang.reflect.Method;
import java.nio.channels.FileChannel;
import java.sql.Timestamp;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Locale;
import java.util.Map;
import java.util.ResourceBundle;
import java.util.ResourceBundle.Control;
import java.util.Scanner;

import javax.swing.JOptionPane;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.teamcenter.edabase.EDACancelException;
import com.teamcenter.edabase.EDAConfiguration;
import com.teamcenter.edabase.EDAException;

public class EPLANToolbox {

  ResourceBundle registry;
  String newline = null;
  Map<String, String> Properties;
  // getLogger has to be the first call ion this class as it initializes the isTc91 variable by reflection!
  static Logger s_logger = EPLANToolbox.getLogger(EPLANToolbox.class.getName());
  public EPLANToolbox() throws IOException, EDAException 
  {
    registry = ResourceBundle.getBundle(this.getClass().getPackage().getName() + ".eda_eplan", Locale.getDefault(), ResourceBundle.Control.getControl(Control.FORMAT_PROPERTIES));
  
    newline = System.getProperty("line.separator");

    Properties = Init();
  }

  static public Logger getLogger(String classname) {
    Logger myLogger = null;
    myLogger = LoggerFactory.getLogger(classname);

    return myLogger;
  }
  
  public ResourceBundle GetRegistry() 
  {
    return registry;
  } 
  
  public String AssembleString(String template, Map<String, String> Contents) throws IOException, EDAException
  {
    int index = 0;
    String variableStart = registry.getString("templatevariable.startsequence");
    String variableEnd = registry.getString("templatevariable.endsequence");
    
    StringBuilder templateContent = new StringBuilder(template);
    templateContent.ensureCapacity(template.length() * 2);  
    s_logger.info(template);
    
    // search through the input for the begin of a variable:
    // this loop has time complexity of only O(template.length())
    while ((index = templateContent.indexOf(variableStart, index)) >= 0 && index < templateContent.length()) 
    {
      // the variable name ends at endIndex 
      int endIndex = templateContent.indexOf(variableEnd, index + 1);
      if (endIndex < 0) 
      {
        throw new EDAException("AssembleString: " + registry.getString("eplan.variable.end") + index + ", substring:" + templateContent.substring(index));
      }
      // the variable name is the key in our replacement map 
      String key = templateContent.substring(index + variableStart.length(), endIndex);
      
      //value is the replacement string 
      if(!Contents.containsKey(key)) 
      {
        s_logger.error("AssembleString: Unknown variable \"" + key + "\" at position " + index + " cannot be replaced!");
        for (String possibleKey : Contents.keySet()) {
          s_logger.info("AssembleString: Possible key: " + possibleKey); 
        }
        throw new EDAException("AssembleString: " + registry.getString("eplan.unknown.variable") + "\"" + key + "\"");
      }
      String value = Contents.get(key);
      
      s_logger.info(key + "=" + value);

      if (value == null) 
      {
        s_logger.error("AssembleString: Value for variable \"" + key + "\" at position " + index + " is empty!");
        throw new EDAException("AssembleString: " + registry.getString("eplan.no.value") + "\"" + key + "\"");
      }
      // replace the key plus the begin and end tags with the value:
      templateContent.replace(index, endIndex + variableEnd.length(), value);
      
      // proceed to the end of the current replacement (no recursive replacement!)
      index += value.length();
    }
    
    s_logger.info("Finished AssembleString ");
    
    return templateContent.toString();  
  }


  //
  // exchanges the special characters with the xml-coding
  //
  public String xmlEscapeText(String xmlInputString) 
  {
  	if (xmlInputString == null) return null;
  	
    StringBuilder escString = new StringBuilder();
    for(int x = 0; x < xmlInputString.length(); x++)
    {
      char singleChar= xmlInputString.charAt(x); 
      switch(singleChar)
      {
        case '<':  escString.append("&lt;"); break;
        case '>':  escString.append("&gt;"); break;
        case '\"': escString.append("&quot;"); break;
        case '&':  escString.append("&amp;"); break;
        case '\'': escString.append("&apos;"); break;
        default:
          if(singleChar > 0x7e) escString.append("&#"+((int)singleChar)+";");
          else escString.append(singleChar);
      }
    }
    return escString.toString();
  }
  
  //
  // checks if the file on the FS has the write access
  //
  public void IsCheckedOutCheckCall() throws IOException, EDACancelException
  { 
    s_logger.info("Start IsCheckedOutCheckCall");  
    
    try { 
      // get the project id of eplan - EPLAN_PROJECT_FILE
      if (Properties.get("EPLAN_PROJECT_FILE") == null)    throw new EDACancelException(registry.getString("missing.EPLAN_PROJECT_FILE"));
      if (Properties.get("EPLAN_PROJECT_FILE").equals("")) throw new EDACancelException(registry.getString("missing.EPLAN_PROJECT_FILE"));
    
      File elkFile = new File(Properties.get("EPLAN_PROJECT_FILE"));
      if (elkFile.exists())
      {
        if (!elkFile.canWrite())
        {

          if (Properties.get("ACTION").equals("SAVEASNEW"))
          {
            // if the elk file already there and has no write access mean we can save
            s_logger.info(Properties.get("DIALOGREFERENCED") + " " + registry.getString("useTemplateFkt"));
            throw new EDACancelException(Properties.get("DIALOGREFERENCED") + " " + registry.getString("useTemplateFkt"));          
          }
          else
          {
            // if the elk file already there and has no write access mean we can save
            s_logger.info(Properties.get("DIALOGREFERENCED"));
            throw new EDACancelException(Properties.get("DIALOGREFERENCED"));
          }
        }
      }
      else
      {
        s_logger.error(registry.getString("projectFile") + " " + Properties.get("EPLAN_PROJECT_FILE") + " " + registry.getString("doesntExist"));
        throw new EDACancelException(registry.getString("projectFile") + " " + Properties.get("EPLAN_PROJECT_FILE") + " " + registry.getString("doesntExist"));      
      }
    } catch (EDAException e) {
      s_logger.error("IsCheckedOutCheckCall EDAException cought: " + e.getMessage());
      throw new EDACancelException("IsCheckedOutCheckCall EDAException: " + e.getMessage());    
    } catch (Exception e) {
      s_logger.error("IsCheckedOutCheckCall Exception cought: " + e.getMessage());
      throw new EDACancelException("IsCheckedOutCheckCall Exception: " + e.getMessage());    
    } finally {
      s_logger.info("Finished IsCheckedOutCheckCall");
    } 
  }
  
  //
  // checks if the file on the FS has read only access
  //  
  public void IsCheckedInCheckCall() throws IOException, EDACancelException
  {
    s_logger.info("Start IsCheckedInCheckCall");   
    
    try { 
      // get the project id of eplan - EPLAN_PROJECT_FILE
      if (Properties.get("EPLAN_PROJECT_FILE") == null)    throw new EDACancelException(registry.getString("missing.EPLAN_PROJECT_FILE"));
      if (Properties.get("EPLAN_PROJECT_FILE").equals("")) throw new EDACancelException(registry.getString("missing.EPLAN_PROJECT_FILE"));
    
      File elkFile = new File(Properties.get("EPLAN_PROJECT_FILE"));
      if (elkFile.exists())
      {
        if (elkFile.canWrite())
        {
          // if the elk file already there and has no write access mean we can save
          s_logger.info(Properties.get("DIALOGCHECKEDOUT"));
          throw new EDACancelException(Properties.get("DIALOGCHECKEDOUT"));
        }
      }
      else
      {
        s_logger.error(registry.getString("projectFile") + " " + Properties.get("EPLAN_PROJECT_FILE") + " " + registry.getString("doesntExist"));
        throw new EDACancelException(registry.getString("projectFile") + " " + Properties.get("EPLAN_PROJECT_FILE") + " " + registry.getString("doesntExist"));      
      }
    } catch (EDAException e) {
      s_logger.error("IsCheckedInCheckCall EDAException caught: " + e.getMessage());
      throw new EDACancelException("IsCheckedInCheckCall EDAException: " + e.getMessage());    
    } catch (Exception e) {
      s_logger.error("IsCheckedInCheckCall Exception caught: " + e.getMessage());
      throw new EDACancelException("IsCheckedInCheckCall Exception: " + e.getMessage());    
    } finally {
      s_logger.info("Finished IsCheckedInCheckCall");
    } 
  }    
  
  //
  //  checks if the file with the given name exists on the FS and if its readable
  //
  public File CheckTemplate(String TemplateFileName) throws IOException, EDAException
  { 
    File TemplateFile = null;
    
    if (TemplateFileName == null || TemplateFileName.length() == 0) 
    {
      s_logger.error("CheckTemplates: template file name is empty");
      throw new EDAException("CheckTemplates: " + registry.getString("noTemplateName"));
    }  
    else
    {
      TemplateFile = new File(TemplateFileName);
      if (TemplateFile.isFile() == false || TemplateFile.canRead() == false)
      {
        s_logger.error("CheckTemplates: " + TemplateFileName + " isn't a file or can't be read.");
        throw new EDAException("CheckTemplates: " + TemplateFileName + " " + registry.getString("cantRead"));
      }
    }	
    return TemplateFile;
  }
  
  public void initDynamicProperties() throws ParserConfigurationException, SAXException, IOException, EDACancelException {
    
    final String[] dynamicKeys = {"BOMSELECTION", "ACTION", "EPLAN_PROJECT_ID", "UID", "EPLAN_PROJECT_FILE", "EPLAN_LIB_EXPORT_XML"};
    s_logger.debug("start initDynamicProperties");
    File file = getDesignExtensionFile();
    s_logger.debug("Reading parameters from file: " + file.getAbsolutePath());
    
    FileInputStream is = null;
    try
    {
      // parse XML file
      DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
      DocumentBuilder db = dbf.newDocumentBuilder();
      is = new FileInputStream(file);
      Document document = db.parse(is);

      Map<String, String> localMap = new HashMap<String, String> (); 
      // we want to dynamically read all children of E2EDynamicConfiguration:
      NodeList rootList = document.getElementsByTagName("E2EDynamicConfiguration");
      if (rootList.getLength() != 1) throw new SAXException("Root element E2EDynamicConfiguration not found or not unique!");
      NodeList parameterList = rootList.item(0).getChildNodes();
      for (int parameterIndex = 0; parameterIndex < parameterList.getLength(); ++parameterIndex) {
        Node parameter = parameterList.item(parameterIndex);
        if (parameter.getNodeType() == Node.ELEMENT_NODE) {
          // add key/value pair to class member hash map
          String key = parameter.getNodeName();
          String value = parameter.getTextContent();
          s_logger.debug("Read key: " + key + ", value: " + value);
          localMap.put(key, value);
        }
      }
      // remove dynamic properties from the map in case they diffused in here (same keys as int he edadesign_extended.xml):
      for (String key : dynamicKeys) {
        Properties.remove(key);
      }
      // only when successfully reaching this point, we want to apply the new configuration:
      Properties.putAll(localMap);
    }
    finally {
      // make sure the config file gets closed in every case:
      if (is != null) is.close();
    }
  }

	public File getDesignExtensionFile() {
		// the environment variable names the file where we will read the dynamic parameters from
    File file = new File(System.getenv("EDA_DESIGN_EXTENSION_XML"));
		return file;
	}
  
  //
  // Checks if all necessary settings are present and saves them up for easy access
  //
  private Map<String, String> Init() throws EDACancelException, IOException
  {
    s_logger.debug("EPLANToolbox Init called.");
    Map<String, String> PropertiesContent = new HashMap<String, String>();

    if (!registry.containsKey("templatevariable.startsequence"))
    {
      throw new EDACancelException(registry.getString("missing.STARTSEQUENCE"));
    }
     
    if (!registry.containsKey("templatevariable.endsequence"))
    {
      throw new EDACancelException(registry.getString("missing.ENDSEQUENCE"));
    } 

    PropertiesContent.put("ACTION", "");    
    
    //DIALOGINFO
    if (!registry.containsKey("dialog.info"))
    {
      throw new EDACancelException(registry.getString("missing.DIALOGTITLE"));
    }  
    PropertiesContent.put("DIALOGINFO", registry.getString("dialog.info"));   

    //DIALOGCHECKEDOUT
    if (!registry.containsKey("dialog.checkedout"))
    {
      throw new EDACancelException(registry.getString("missing.DIALOGCHECKOUT"));
    }  
    PropertiesContent.put("DIALOGCHECKEDOUT", registry.getString("dialog.checkedout"));    

    //DIALOGREFERENCED
    if (!registry.containsKey("dialog.referenced"))
    {
      throw new EDACancelException(registry.getString("missing.DIALOGREFERENCED"));
    }  
    PropertiesContent.put("DIALOGREFERENCED", registry.getString("dialog.referenced"));      
    
    if (!registry.containsKey("eda2eplan.derivedData"))
    {
      throw new EDACancelException(registry.getString("missing.DERIVEDDATANO"));
    }    
    PropertiesContent.put("DERIVEDDATANO", registry.getString("eda2eplan.derivedData"));     

    //NONLATEST
    if (System.getenv("NONLATEST") == null)    throw new EDACancelException(registry.getString("missing.NONLATEST"));
    if (System.getenv("NONLATEST").equals("")) throw new EDACancelException(registry.getString("missing.NONLATEST"));
    PropertiesContent.put("NONLATEST", System.getenv("NONLATEST"));       
      
    //EDA2EPLAN_TRANSFER_DIR
    if (System.getenv("EDA2EPLAN_TRANSFER_DIR") == null)    throw new EDACancelException(registry.getString("missing.EDA2EPLAN_TRANSFER_DIR"));
    if (System.getenv("EDA2EPLAN_TRANSFER_DIR").equals("")) throw new EDACancelException(registry.getString("missing.EDA2EPLAN_TRANSFER_DIR")); 
    PropertiesContent.put("EDA2EPLAN_TRANSFER_DIR", System.getenv("EDA2EPLAN_TRANSFER_DIR"));
    
    //EPLAN2EDA_TRANSFER_DIR
    if (System.getenv("EPLAN2EDA_TRANSFER_DIR") == null)    throw new EDACancelException(registry.getString("missing.EPLAN2EDA_TRANSFER_DIR"));
    if (System.getenv("EPLAN2EDA_TRANSFER_DIR").equals("")) throw new EDACancelException(registry.getString("missing.EPLAN2EDA_TRANSFER_DIR")); 
    PropertiesContent.put("EPLAN2EDA_TRANSFER_DIR", System.getenv("EPLAN2EDA_TRANSFER_DIR"));    
    
    //EPLAN2EDA_BOM_DIR
    if (System.getenv("EPLAN2EDA_BOM_DIR") == null)    throw new EDACancelException(registry.getString("missing.EPLAN2EDA_BOM_DIR"));
    if (System.getenv("EPLAN2EDA_BOM_DIR").equals("")) throw new EDACancelException(registry.getString("missing.EPLAN2EDA_BOM_DIR")); 
    PropertiesContent.put("EPLAN2EDA_BOM_DIR", System.getenv("EPLAN2EDA_BOM_DIR"));        

    //EPLAN_PUBLIC_DIR
    if (System.getenv("EPLAN_PUBLIC_DIR") == null)    throw new EDACancelException(registry.getString("missing.EPLAN_PUBLIC_DIR"));
    if (System.getenv("EPLAN_PUBLIC_DIR").equals("")) throw new EDACancelException(registry.getString("missing.EPLAN_PUBLIC_DIR")); 
    PropertiesContent.put("EPLAN_PUBLIC_DIR", System.getenv("EPLAN_PUBLIC_DIR"));        

    //INCL_NAME
    if (System.getenv("INCL_NAME") == null)
    {
      PropertiesContent.put("INCL_NAME", "ON");
    }
    else 
    {
      if (System.getenv("INCL_NAME").equals("OFF")) PropertiesContent.put("INCL_NAME", "OFF");  
      else                                          PropertiesContent.put("INCL_NAME", "ON");     
    }      
    
    //DELIMITER
    if (System.getenv("DELIMITER") == null)
    {
      PropertiesContent.put("DELIMITER", "@");
    }
    else 
    {
      if (System.getenv("DELIMITER").equals("")) PropertiesContent.put("DELIMITER", "@");  
      else                                       PropertiesContent.put("DELIMITER", System.getenv("DELIMITER"));     
    } 

    if (System.getenv("EPLAN_UID_ATTR") == null)    throw new EDACancelException(registry.getString("missing.EPLAN_UID_ATTR"));
    if (System.getenv("EPLAN_UID_ATTR").equals("")) throw new EDACancelException(registry.getString("missing.EPLAN_UID_ATTR"));
    PropertiesContent.put("EPLAN_UID_ATTR", xmlEscapeText(System.getenv("EPLAN_UID_ATTR")));      

    if (System.getenv("EDA_ATTRIBUTE_TEMPLATE") == null)    throw new EDACancelException(registry.getString("missing.EDA_ATTRIBUTE_TEMPLATE"));
    if (System.getenv("EDA_ATTRIBUTE_TEMPLATE").equals("")) throw new EDACancelException(registry.getString("missing.EDA_ATTRIBUTE_TEMPLATE"));
    PropertiesContent.put("EDA_ATTRIBUTE_TEMPLATE", System.getenv("EDA_ATTRIBUTE_TEMPLATE"));        
    
    if (System.getenv("ZW1_XML_TEMPLATE") == null)    throw new EDACancelException(registry.getString("missing.ZW1_XML_TEMPLATE"));
    if (System.getenv("ZW1_XML_TEMPLATE").equals("")) throw new EDACancelException(registry.getString("missing.ZW1_XML_TEMPLATE"));
    PropertiesContent.put("ZW1_XML_TEMPLATE", System.getenv("ZW1_XML_TEMPLATE"));        

    if (System.getenv("EPLAN_REMOTE_APP") == null)    throw new EDACancelException(registry.getString("missing.EPLAN_REMOTE_APP"));
    if (System.getenv("EPLAN_REMOTE_APP").equals("")) throw new EDACancelException(registry.getString("missing.EPLAN_REMOTE_APP"));
    PropertiesContent.put("EPLAN_REMOTE_APP", System.getenv("EPLAN_REMOTE_APP"));  

    // check that the environment variable is present
    if (System.getenv("EDA_DESIGN_EXTENSION_XML") == null)    throw new EDACancelException(registry.getString("missing.EDA_DESIGN_EXTENSION_XML"));
    if (System.getenv("EDA_DESIGN_EXTENSION_XML").equals("")) throw new EDACancelException(registry.getString("missing.EDA_DESIGN_EXTENSION_XML"));
    
    //EPLAN_PREFIX4TEMPLATE
    if (System.getenv("EPLAN_PREFIX4TEMPLATE") == null)
    {
    	PropertiesContent.put("EPLAN_PREFIX4TEMPLATE", "TPL_");
    }
    else
    {
      if (System.getenv("EPLAN_PREFIX4TEMPLATE").equals("")) PropertiesContent.put("EPLAN_PREFIX4TEMPLATE", "TPL_");
      else                                                   PropertiesContent.put("EPLAN_PREFIX4TEMPLATE", System.getenv("EPLAN_PREFIX4TEMPLATE")); 
    }
    return PropertiesContent;
  }
    
  //
  // converts the attribute of design file to the attribute of zw1.xml
  //
  public String PrepareXMLZw1Attributes(Map<String, String> DesignContent) throws IOException, EDAException
  {
    String AllAttributeLines = "";
    
    int noOfAttributes = Integer.parseInt(DesignContent.get("ATTR_NUMBER"));
    for(int x = 0; x < noOfAttributes ; x++)
    {
    	
      String attrName = DesignContent.get("ATTR_NAME_" + Integer.toString(x));
      String attrValue = DesignContent.get("ATTR_VALUE_" + Integer.toString(x));
      
      if (x > 0) AllAttributeLines += "\n";
      // attribute values are already XML escaped here!
      AllAttributeLines += "    <Property> <UserPropName>" + attrName + "</UserPropName> <Value>" + attrValue + "</Value> </Property>";
    }

    s_logger.info("PrepareXMLZw1Attributes returns: " + AllAttributeLines);
    return AllAttributeLines;
  }   
  
  //
  //  parse the design file and stores the TC data like
  //    itemid
  //    itemname
  //    revision
  //    bom
  //    dataset version
  //    dataset uid
  //    checkout
  //    dataset type
  //    attributes
  //
  public Map<String, String> ReadDesignXML(String XMLFileName, String Encoding) throws IOException, EDACancelException
  {
    Map<String, String> DesignXMLContent = new HashMap<String, String>();
    Scanner scanner = null;
    
    s_logger.info("Start ReadDesignXML with " + XMLFileName + " " + Encoding);

    if (Encoding.length() > 0)
    {
      scanner = new Scanner(new File(XMLFileName), Encoding);
    }
    else
    {
      scanner = new Scanner(new File(XMLFileName));
    }

    scanner.useDelimiter("\\Z"); // scan to end of file
    String template = scanner.next();
    
    s_logger.info("ReadDesignXML: " + template);
    
    scanner.close();

    File XMLFile = new File(XMLFileName);

    try
    {
      DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
      DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
      Document doc = docBuilder.parse(XMLFile);

      // normalize text representation
      doc.getDocumentElement().normalize();

      NodeList CCA_Node = doc.getElementsByTagName("CCA");
      
      if (CCA_Node.getLength() != 1) 
      {
        s_logger.error("ReadDesignXML: No CCA element found.");
        throw new EDACancelException("ReadDesignXML: " + registry.getString("edadesign.missing.cca"));
      }
      Element cca = (Element)CCA_Node.item(0);
      
      s_logger.info("ITEMID    - " + cca.getAttribute("itemId"));
      DesignXMLContent.put("ITEMID", cca.getAttribute("itemId"));
      DesignXMLContent.put("ITEMNAME", cca.getAttribute("name"));
      
      DesignXMLContent.put("HEAD_ID", cca.getAttribute("itemId"));
      DesignXMLContent.put("HEAD_NAME", xmlEscapeText(cca.getAttribute("name")));
      DesignXMLContent.put("HEAD_REV", cca.getAttribute("revId"));
      DesignXMLContent.put("HEAD_BOM", cca.getAttribute("bom"));
      
      s_logger.info("HEAD_ID:" + cca.getAttribute("itemId"));
      s_logger.info("HEAD_NAME:" + cca.getAttribute("name"));
      s_logger.info("HEAD_REV:" + cca.getAttribute("revId"));
      s_logger.info("HEAD_BOM:" + cca.getAttribute("bom"));
      
      NodeList DS_Node = doc.getElementsByTagName("dataset");
      Element ds = (Element)DS_Node.item(0);
      
      if (DS_Node.getLength() != 1) 
      {
        s_logger.error("ReadDesignXML: Datasets in CCA != 1");
        throw new EDACancelException("ReadDesignXML: " + registry.getString("edadesign.missing.dsnumbe"));
      }
        
      DesignXMLContent.put("DATASET_SRC", ds.getAttribute("src"));
      DesignXMLContent.put("DATASET_CKUSR", ds.getAttribute("checkedOutUser"));
      DesignXMLContent.put("DATASET_TYPE", ds.getAttribute("type"));
      DesignXMLContent.put("DATASET_UID", ds.getAttribute("UID"));
      DesignXMLContent.put("DATASET_VER", ds.getAttribute("version"));   
      DesignXMLContent.put("DATASET_CHECKEDOUT", ds.getAttribute("checkedOut"));
      if (ds.getAttribute("checkedOut").equals("true")) {
        DesignXMLContent.put("READONLY", "0");
	  } else {
	    DesignXMLContent.put("READONLY", "1");
	  }
      
      s_logger.info("DATASET_SRC:" + ds.getAttribute("src"));
      s_logger.info("DATASET_CKUSR:" + ds.getAttribute("checkedOutUser"));
      s_logger.info("DATASET_TYPE:" + ds.getAttribute("type"));
      s_logger.info("DATASET_UID:" + ds.getAttribute("UID"));
      s_logger.info("DATASET_VER:" + ds.getAttribute("version"));
      s_logger.info("DATASET_CHECKEDOUT:" + ds.getAttribute("checkedOut"));

      NodeList Attr_Node = ds.getElementsByTagName("attr"); 
      
      int AttrNo = Attr_Node.getLength();
      DesignXMLContent.put("ATTR_NUMBER", Integer.toString(AttrNo));       
      for (int x = 0; x < AttrNo; x++)
      {
        Element attr = (Element)Attr_Node.item(x);
        DesignXMLContent.put("ATTR_NAME_" + Integer.toString(x), xmlEscapeText(attr.getAttribute("name")));
        DesignXMLContent.put("ATTR_VALUE_" + Integer.toString(x), xmlEscapeText(attr.getAttribute("value")));
        s_logger.info(DesignXMLContent.get("ATTR_NAME_" + Integer.toString(x)) + "=" + DesignXMLContent.get("ATTR_VALUE_" + Integer.toString(x)));
      }    
    }
    catch (SAXException e)
    {
      s_logger.error("ReadDesignXML SAXException " + e.getMessage());
      throw new EDACancelException("ReadDesignXML SAXException: " + e.getMessage());
    }
    catch (ParserConfigurationException e)
    {
      s_logger.error("ReadDesignXML ParserConfigurationException " + e.getMessage());
      throw new EDACancelException("ReadDesignXML ParserConfigurationException: " + e.getMessage());
    } finally {
      s_logger.info("Finished ReadDesignXML");
    } 
    
	  return DesignXMLContent;
  }  
  
  //
  //
  //
  public boolean CheckTemplatePattern(String ItemName, String Pattern) throws IOException
  {
    s_logger.info("CheckTemplatePattern " + ItemName + ":" + Pattern);
    boolean result = ItemName.matches(Pattern);
    return result;
  }
  
  //
  //  read the project attributes from zw1.xml
  //  depending on the parameter SpecificAttrOnly:
  //    SpecificAttrOnly == "" - convert all the attributes into the design file form
  //    get only the value of one specified attribute
  //
  public String ParseZW1XML(String XMLFileName, String Encoding, String SpecificAttrOnly) throws EDACancelException, IOException
  {
    Scanner scanner = null;
    String AllAttributeLines = "";

    if (Encoding.length() > 0)
    {
      scanner = new Scanner(new File(XMLFileName), Encoding);
    }
    else
    {
      scanner = new Scanner(new File(XMLFileName));
    }
 
    scanner.useDelimiter("\\Z"); // scan to end of file
    String template = scanner.next();
    scanner.close();
    
    String reparedXML1 = template.replace("<Value />", "<Value> </Value>");
    template = reparedXML1.replace("<Value/>", "<Value> </Value>");
    
    OutputStreamWriter fwrite = new OutputStreamWriter(new FileOutputStream(XMLFileName), Encoding);
    fwrite.write(template.toString());
    fwrite.close();    
    
    File XMLFile = new File(XMLFileName);

    try
    {
      DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
      DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
      Document doc = docBuilder.parse(XMLFile);

      // normalize text representation
      doc.getDocumentElement().normalize();
      
      NodeList Attributes = doc.getElementsByTagName("Property");
      int noOfAttributes = Attributes.getLength();
      
      s_logger.info("Total no of attrs : " + Integer.toString(noOfAttributes));  

      for(int s = 0; s < noOfAttributes ; s++)
      {
        Node lineNode = Attributes.item(s);
        if(lineNode.getNodeType() == Node.ELEMENT_NODE) 
        {
          Element lineElement = (Element)lineNode;
        
          NodeList nameList = lineElement.getElementsByTagName("UserPropName");
          NodeList valueList = lineElement.getElementsByTagName("Value");   

          for (int x = 0; x < nameList.getLength(); x++)
          {
            Element nameElement = (Element)nameList.item(x);
            Element valueElement = (Element)valueList.item(x);
            
            String attrName = nameElement.getFirstChild().getNodeValue().trim();
            String attrVal = valueElement.getFirstChild().getNodeValue().trim(); 
            
            if (SpecificAttrOnly.equals(""))
            {
              // skip TeamcenterUID attribute as it shall not be mapped back to TC
              if (attrName.equals(Properties.get("EPLAN_UID_ATTR"))) continue;
            
              if (s > 0) AllAttributeLines += "\n";
              AllAttributeLines += "      <attr name=\"" + xmlEscapeText(attrName) +"\" value=\"" + xmlEscapeText(attrVal) + "\" />";
            }
            else
            {
              if (SpecificAttrOnly.equals(attrName)) AllAttributeLines = attrVal;
              break;
            }
          }
        }
      }
    }
    catch (SAXException e)
    {
      s_logger.error("ParseZW1XML SAXException " + e.getMessage());
      throw new EDACancelException("ParseZW1XML SAXException: " + e.getMessage());
    }
    catch (ParserConfigurationException e)
    {
      s_logger.error("ParseZW1XML ParserConfigurationException " + e.getMessage());
      throw new EDACancelException("ParseZW1XML ParserConfigurationException: " + e.getMessage());
    }   
    catch (IOException e)
    {
      s_logger.error("ParseZW1XML IOException " + e.getMessage());
      throw new EDACancelException("ParseZW1XML IOException: " + e.getMessage());
    } 
    s_logger.info("AllAttributeLines " + AllAttributeLines);
	  return AllAttributeLines;
  } 
  
  //
  // execute the epis call
  // depending on the ScriptId the parameter for the call will be extracted and the place holders filled with the 
  // data stored in the Properties
  // the call will be then executed and the exit code returned
  //
  public int StartEPLAN(String ScriptId, Map<String, String> dynamicProperties) throws IOException, InterruptedException, EDACancelException
  {
    java.util.Date date= new java.util.Date();
    int index = 0;
    String variableStart = registry.getString("templatevariable.startsequence");
    String variableEnd = registry.getString("templatevariable.endsequence");
    
    // merge tools.Properties with dynamicProperties:
    dynamicProperties.putAll(Properties);
    
    try {
      int parameterNum = Integer.parseInt(registry.getString("eplan." + ScriptId + ".script.pnum"));
      
      String[] cmd = new String[parameterNum];
      
      for (int x = 0; x < parameterNum; x++)
      {
        if (!registry.containsKey("eplan." + ScriptId + ".script.p" + Integer.toString(x + 1)))
        {
          s_logger.error("StartEPLAN: script parameter not defined: " + "eplan." + ScriptId + ".script.p" + Integer.toString(x + 1));
          throw new EDACancelException("StartEPLAN: " + registry.getString("eplan.script.parameter") + ": " + "eplan." + ScriptId + ".script.p" + Integer.toString(x + 1));
        }  
        
        StringBuilder templateLine = new StringBuilder(registry.getString("eplan." + ScriptId + ".script.p" + Integer.toString(x + 1)));
        
        while ((index = templateLine.indexOf(variableStart, index)) >= 0 && index < templateLine.length()) 
        {      
          // the variable name ends at endIndex 
          int endIndex = templateLine.indexOf(variableEnd, index + 1);
          if (endIndex < 0) 
          {
            s_logger.error("StartEPLAN: Variable end not found at position " + index + ", substring:" + templateLine.substring(index));
            throw new EDACancelException("StartEPLAN: " + registry.getString("eplan.variable.end") + index + ", substring:" + templateLine.substring(index));
          } 
          // the variable name is the key in our replacement map 
          String key = templateLine.substring(index + variableStart.length(), endIndex);   
          String value = null;
          //value is the replacement string 
          if(!dynamicProperties.containsKey(key)) 
          {
            s_logger.info("Check env var for key: " + key);
            // check if env variable for the key found
            if (System.getenv(key) == null)
            {
              s_logger.error("StartEPLAN: Unknown variable \"" + key + "\" at position " + index + " cannot be replaced!");
              throw new EDACancelException("StartEPLAN: " + registry.getString("eplan.unknown.variable") + "\"" + key + "\"");
            } 
            else
            {
              value = System.getenv(key); 
            }
          }
          else 
          {
            value = dynamicProperties.get(key);
          }
          if (value == null) 
          {
            s_logger.error("StartEPLAN: Value for variable \"" + key + "\" at position " + index + " is empty!");
            throw new EDACancelException("StartEPLAN: " + registry.getString("eplan.no.value") + "\"" + key + "\"");
          }
          // replace the key plus the begin and end tags with the value:
          templateLine.replace(index, endIndex + variableEnd.length(), value);
        }
        cmd[x] = templateLine.toString();       
        
        s_logger.info(ScriptId + " " + cmd[x]);
      }
      
      s_logger.info("start " + new Timestamp(date.getTime()));      
      ProcessBuilder procBuilder = new ProcessBuilder(cmd);
      Process process = procBuilder.start();
      BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
      String extLog;
      while ((extLog = reader.readLine()) != null) 
      {
        s_logger.info("exec log " + extLog); 
      }      
      int exitVal = process.waitFor();
      s_logger.info("exit code " + Integer.toString(exitVal));       
      s_logger.info("end " + new Timestamp(date.getTime())); 
      
      if (exitVal == 1)
      {
        // OK
        return 1;
      }
      else if (exitVal == 0) 
      {
        s_logger.warn("Epis call cancelled");
        return 0; 
      }      
      else if (exitVal == -1) 
      {
        throw new EDACancelException("StartEPLAN: returns ERROR_CANNOT_CONNECT_TO_DEFINED_SERVER");  
      }
      else if (exitVal == -2) 
      {
        throw new EDACancelException("StartEPLAN: returns ERROR_EPLAN_INSTANCE_NOT_AVAILABLE");  
      }      
      else if (exitVal == -3) 
      {
        throw new EDACancelException("StartEPLAN: returns ERROR_CANNOT_CONNECT_TO_STARTED_SERVER");  
      }       
      else if (exitVal == -4) 
      {
        throw new EDACancelException("StartEPLAN: returns ERROR_CONNECTION_FAILED");  
      } 
      else if (exitVal == -5) 
      {
        throw new EDACancelException("StartEPLAN: returns ERROR_CALLING_ACTION_FAILED");  
      }
      else if (exitVal == -6) 
      {
        throw new EDACancelException("StartEPLAN: returns ERROR_CLOSING_EPLAN_FAILED");  
      }
      else if (exitVal == -7) 
      {
        throw new EDACancelException("StartEPLAN: returns ERROR_MISSING_ACTION_PARAMETER");  
      } 
      else if (exitVal == 11) 
      {
        throw new EDACancelException("StartEPLAN: returns ERROR_WRONG_ACTION_PARAMETER");  
      }   
      else if (exitVal == 12) 
      {
        throw new EDACancelException("StartEPLAN: returns ERROR_ACTION_DISABLED_FOR_THIS_PROJECT");  
      }
      else if (exitVal == 16) 
      {
    	if(ScriptId.equals("bomExport")) {
    		// according to Andrea Di Figlia's Product Backlog Item 84947:
    		// "Cancellation of eplan structered BOM dialog does not cancel the action"
    		// the whole transfer should be canceled if the user presses cancel in the structured BoM dialog:
    		throw new EDACancelException("Epis action cancelled by user"); 
    	}
        s_logger.error("Epis action cancelled");
        return exitVal; 
      }
      else
      {    
        s_logger.error("Epis call unknown error");
        throw new EDACancelException("StartEPLAN: returns RESULT_UNKNOWN_ERROR");  
      }
    } catch (IOException e) {
      s_logger.error("StartEPLAN: IOException " + e.getMessage());
      throw new EDACancelException("StartEPLAN IOException:" + e.getMessage());  
    } catch (InterruptedException e) {
      s_logger.error("StartEPLAN: InterruptedException " + e.getMessage());
      throw new EDACancelException("StartEPLAN InterruptedException:" + e.getMessage()); 
    } 
  }   

  //
  // the staging directory will be checked if one of the subdirectories equals "nonLatest"
  // if such directory found it means the revision is non latest
  //
  public String CheckIfLatestRevision(String dirName, String rev, String nonLatest) throws IOException
  {
    String[] splitResult = dirName.split("\\\\");
      
    for (int x = 0; x < splitResult.length; x++)
    {
      s_logger.info("CheckIfLatestRevision: " + splitResult[x]);
      if (splitResult[x].equals(nonLatest)) return("_" + rev);
    }
    return("");
  }
  
  //
  // move file form source to target
  //
  public void MoveFile(String sourceFileName, String targetFileName) throws IOException, EDACancelException
  {
    try {
      s_logger.info("move " + sourceFileName + " to " + targetFileName);
      
	  File fSource = new File(sourceFileName);
      File fTarget = new File(targetFileName);
      
      if (!fSource.exists())
      {
        s_logger.error("Source file " + sourceFileName + " doesn't exist");
        throw new IOException(registry.getString("sourceFile") + " " + sourceFileName + " " + registry.getString("doesntExist"));
      }
      
      if (fTarget.exists()) fTarget.delete();
      
      if (!fSource.renameTo(fTarget))
      {
         s_logger.error("Cant move " + sourceFileName + " to " + targetFileName);
         throw new EDACancelException(registry.getString("cantMove") + " " + sourceFileName + " -> " + targetFileName);
      }
    } catch (IOException e) {
      s_logger.error(e.getMessage());
      throw new IOException("MoveFile IOException: " + e.getMessage()); 
    } 
  }   
  
  
  //
  // move file form source to target
  //
  public void CopyFile(String sourceFileName, String targetFileName) throws IOException
  {
    FileInputStream inStream = null; 
    FileChannel inChannel = null;
    FileOutputStream outStream = null;
    FileChannel outChannel = null; 

    try {
      s_logger.info("copy " + sourceFileName + " to " + targetFileName);
      
	  File fSource = new File(sourceFileName);
      File fTarget = new File(targetFileName);
      
      if (!fSource.exists())
      {
        s_logger.error("Source file " + sourceFileName + " doesn't exist");
        throw new IOException(registry.getString("sourceFile") + " " + sourceFileName + " " + registry.getString("doesntExist"));
      }
      
      if (fTarget.exists()) fTarget.delete();

      inStream = new FileInputStream(fSource); 
      inChannel = inStream.getChannel();
      outStream = new FileOutputStream(fTarget);
      outChannel = outStream.getChannel(); 
      
      inChannel.transferTo(0, inChannel.size(), outChannel);
      
    } catch (IOException e) {
      s_logger.error(e.getMessage());
      throw new IOException("CopyFile IOException: " + e.getMessage()); 
    } finally {
      if (inChannel != null) inChannel.close();
      if (inStream != null) inStream.close();
      if (outChannel != null) outChannel.close();
      if (outStream != null) outStream.close();
    }
  } 
  
  public void CancelDerivedData(String datasetSource, String itemId) throws IOException, EDACancelException
  {
    try {
      int typesNum = Integer.parseInt(Properties.get("DERIVEDDATANO"));
      for (int x = 1; x <= typesNum; x++)
      {
        // type
        if (!registry.containsKey("eda2eplan.derivedData.type." + Integer.toString(x)))
        {
          throw new EDACancelException("CancelDerivedData: " + registry.getString("eplan.no.deriveddata.type") + Integer.toString(x));
        }    
        String dataType = registry.getString("eda2eplan.derivedData.type." + Integer.toString(x)); 

        //target
        if (!registry.containsKey("eda2eplan." + dataType + ".target.dir"))
        {
          throw new EDACancelException("CancelDerivedData: " + registry.getString("eplan.no.deriveddata.targetDir") + dataType);
        }           
        String targetDir = datasetSource + "\\" + registry.getString("eda2eplan." + dataType + ".target.dir");
        
        //extension
        if (!registry.containsKey("eda2eplan." + dataType + ".extension"))
        {
          throw new EDACancelException("CancelDerivedData: "+ registry.getString("eplan.no.deriveddata.ext") + dataType);
        }           
        String extension = registry.getString("eda2eplan." + dataType + ".extension");
        
        s_logger.warn("CancelDerivedData: Proceed derived data of type " + dataType);

        CleanUpDirExt(targetDir, itemId, extension);
      }  
    } catch (IOException e) {
      s_logger.error("CancelDerivedData: " + e.getMessage()); 
      throw new EDACancelException("CancelDerivedData IOException:" + e.getMessage());
    }
  }
  
  //
  // delete files which name starts with the itemId in the derived data source directories
  //
  public void CleanUpDerivedDataSource(String itemId) throws IOException, EDACancelException
  {
    try {
      int typesNum = Integer.parseInt(Properties.get("DERIVEDDATANO"));
      for (int typeId = 1; typeId <= typesNum; typeId++)
      {
        cleanupDerivedDataSourceForType(itemId, typeId);  
      }  
    } catch (IOException e) {
      s_logger.error("CleanUpDerivedDataSource IOException: " + e.getMessage()); 
      throw new EDACancelException("CleanUpDerivedDataSource IOException: " + e.getMessage());
    }
  }

	public void cleanupDerivedDataSourceForType(String itemId, int typeId) throws EDACancelException, IOException {
		// type
		if (!registry.containsKey("eda2eplan.derivedData.type." + Integer.toString(typeId)))
		{
		  throw new EDACancelException("CleanUpDerivedDataSource: " + registry.getString("eplan.no.deriveddata.type") + Integer.toString(typeId));
		}    
		String dataType = registry.getString("eda2eplan.derivedData.type." + Integer.toString(typeId)); 
		
		// source
		if (!registry.containsKey("eda2eplan." + dataType + ".source.dir"))
		{
		  throw new EDACancelException("CleanUpDerivedDataSource: " + registry.getString("eplan.no.deriveddata.targetDir") + dataType);
		}           
		String sourceDir = Properties.get("EPLAN_PUBLIC_DIR") + "\\" + registry.getString("eda2eplan." + dataType + ".source.dir");
		
		//extension
		if (!registry.containsKey("eda2eplan." + dataType + ".extension"))
		{
		  throw new EDACancelException("CleanUpDerivedDataSource: "+ registry.getString("eplan.no.deriveddata.ext") + dataType);
		}
		CleanUpDir(sourceDir, itemId);
	}

  //
  // delete files which name starts with the itemId in the derived data target directories
  //
  public void CleanUpDerivedDataTarget(String datasetSource, String itemId) throws IOException, EDACancelException
  {
    try {
      int typesNum = Integer.parseInt(Properties.get("DERIVEDDATANO"));
      for (int typeId = 1; typeId <= typesNum; typeId++)
      {
        cleanupDerivedDataTargetforType(datasetSource, itemId, typeId);  
      }  
    } catch (IOException e) {
      s_logger.error("CleanUpDerivedDataTarget IOException: " + e.getMessage()); 
      throw new EDACancelException("CleanUpDerivedDataTarget IOException:" + e.getMessage());
    }
  }

	public void cleanupDerivedDataTargetforType(String datasetSource, String itemId, int typeId)
	    throws EDACancelException, IOException {
		// type
		if (!registry.containsKey("eda2eplan.derivedData.type." + Integer.toString(typeId)))
		{
		  throw new EDACancelException("CleanUpDerivedDataTarget: " + registry.getString("eplan.no.deriveddata.type") + Integer.toString(typeId));
		}    
		String dataType = registry.getString("eda2eplan.derivedData.type." + Integer.toString(typeId)); 
		
		//target
		if (!registry.containsKey("eda2eplan." + dataType + ".target.dir"))
		{
		  throw new EDACancelException("CleanUpDerivedDataTarget: " + registry.getString("eplan.no.deriveddata.targetDir") + dataType);
		}           
		String targetDir = datasetSource + "\\" + registry.getString("eda2eplan." + dataType + ".target.dir");

		//extension
		if (!registry.containsKey("eda2eplan." + dataType + ".extension"))
		{
		  throw new EDACancelException("CleanUpDerivedDataTarget: "+ registry.getString("eplan.no.deriveddata.ext") + dataType);
		}
		CleanUpDir(targetDir, itemId);
	}

  //
  // copy derived data files form source to target
  //
  public void ProceedDerivedData(String datasetSource, String eplanProjectID, String itemId) throws IOException, EDACancelException
  {
    try {
      int typesNum = Integer.parseInt(Properties.get("DERIVEDDATANO"));
      for (int typeId = 1; typeId <= typesNum; typeId++)
      {
        proceedDerivedDataForType(datasetSource, eplanProjectID, itemId, typeId);   
      }  
    } catch (IOException e) {
      s_logger.error("ProceedDerivedData IOException: " + e.getMessage()); 
      throw new EDACancelException("ProceedDerivedData IOException:" + e.getMessage());
    }
  }

	public void proceedDerivedDataForType(String datasetSource, String eplanProjectID, String itemId, int typeId)
	    throws EDACancelException, IOException {
		// type
		if (!registry.containsKey("eda2eplan.derivedData.type." + Integer.toString(typeId)))
		{
		  throw new EDACancelException("ProceedDerivedData: " + registry.getString("eplan.no.deriveddata.type") + Integer.toString(typeId));
		}    
		String dataType = registry.getString("eda2eplan.derivedData.type." + Integer.toString(typeId)); 
		// source
		if (!registry.containsKey("eda2eplan." + dataType + ".source.dir"))
		{
		  throw new EDACancelException("ProceedDerivedData: " + registry.getString("eplan.no.deriveddata.sourceDir") + dataType);
		}           
		String sourceDir = Properties.get("EPLAN_PUBLIC_DIR") + "\\" + registry.getString("eda2eplan." + dataType + ".source.dir");
		//target
		if (!registry.containsKey("eda2eplan." + dataType + ".target.dir"))
		{
		  throw new EDACancelException("ProceedDerivedData: " + registry.getString("eplan.no.deriveddata.targetDir") + dataType);
		}           
		String targetDir = datasetSource + "\\" + registry.getString("eda2eplan." + dataType + ".target.dir");
		//extension
		if (!registry.containsKey("eda2eplan." + dataType + ".extension"))
		{
		  throw new EDACancelException("ProceedDerivedData: "+ registry.getString("eplan.no.deriveddata.ext") + dataType);
		}           
		String targetFileName = itemId + registry.getString("eda2eplan." + dataType + ".extension");
		String sourceFileName = eplanProjectID + registry.getString("eda2eplan." + dataType + ".extension");
		
		s_logger.info("ProceedDerivedData: Proceed derived data of type " + dataType);
   
		FindAndCopyDerivedData(sourceDir, sourceFileName, targetDir, targetFileName);
	}
  
  //
  // copy derived data files form source to target
  //
  public void FindAndCopyDerivedData(String sourceDirName, String sourceFileName, String targetDirName, String targetFileName) throws IOException
  {
    s_logger.info("FindAndCopyDerivedData: " + sourceFileName + " from " + sourceDirName + " to " + targetFileName + " in " + targetDirName);
    try {
      File derivedFile = new File(sourceDirName + "\\" + sourceFileName);
    
      if (derivedFile.exists())
      {
        File targetDir = new File(targetDirName);
        
        if (!targetDir.exists())
        {
          s_logger.info("create " + targetDirName);
          if (!targetDir.mkdirs())
          {
            s_logger.error("error creating " + targetDirName);
            throw new IOException("FindAndCopyDerivedData: " + registry.getString("errorCreate") + targetDirName);
          }
        }
       
        s_logger.info("derived data exists");
        String sourceFilePath = sourceDirName + "\\" + sourceFileName;
        String targetFilePath = targetDirName + "\\" + targetFileName;
      
        CopyFile(sourceFilePath, targetFilePath);    
      }
      else
      {
        s_logger.warn(derivedFile.getAbsolutePath() + " not found");
      }
    } catch (IOException e) {
      s_logger.error(e.getMessage()); 
      throw new IOException("FindAndCopyDerivedData IOException:" + e.getMessage());
    }
  }
  
  //
  // check if the derived data exists
  //
  public String DerivedDataPreCheck(String itemId) throws IOException, EDAException
  {
    String retValue = "OK";
    int typesNum = Integer.parseInt(Properties.get("DERIVEDDATANO"));
    s_logger.info("DerivedDataPreCheck :" + Properties.get("DERIVEDDATANO"));
    for (int x = 1; x <= typesNum; x++)
    {
      // type
      if (!registry.containsKey("eda2eplan.derivedData.type." + Integer.toString(x)))
      {
        throw new EDAException("DerivedDataPreCheck: " + registry.getString("eplan.no.deriveddata.type") + Integer.toString(x));
      }    
      String dataType = registry.getString("eda2eplan.derivedData.type." + Integer.toString(x)); 
      
      // source
      if (!registry.containsKey("eda2eplan." + dataType + ".source.dir"))
      {
        throw new EDAException("DerivedDataPreCheck: " + registry.getString("eplan.no.deriveddata.sourceDir") + dataType);
      }           
      String sourceDir = Properties.get("EPLAN_PUBLIC_DIR") + "\\" + registry.getString("eda2eplan." + dataType + ".source.dir");
      
      //extension
      if (!registry.containsKey("eda2eplan." + dataType + ".extension"))
      {
        throw new EDAException("DerivedDataPreCheck: "+ registry.getString("eplan.no.deriveddata.ext") + dataType);
      }           
      String extension = registry.getString("eda2eplan." + dataType + ".extension"); 

      //do check
      if (!registry.containsKey("eda2eplan." + dataType + ".precheck"))
      {
        throw new EDAException("DerivedDataPreCheck: " + registry.getString("eplan.no.deriveddata.preCheck")  + dataType);
      }           
      int doCheck = Integer.parseInt(registry.getString("eda2eplan." + dataType + ".precheck")); 

      String DFName = sourceDir + "\\" + itemId + extension;
      
      s_logger.info("DerivedDataPreCheck: check file " + DFName);
      
      File DerivedFile = new File(DFName);
      if (doCheck == 1)
      {
        if (!DerivedFile.exists())
        {
          s_logger.warn("DerivedDataPreCheck: derived data file: " + DFName + " doesn't exists. Cancel");
          
          retValue = "derived data file: " + DFName + " doesn't exists. Cancel";
          break;
        }         
      } else if (doCheck == 0) {
        if (DerivedFile.exists())
        {
          DerivedFile.delete();
        }
      }
    }
    return retValue;
  }
   
  //
  // read the status info file and extract the attributes given in the list
  //
  public Map<String, String> GetStatusInfo(String XMLFileName, String StatusElement, String[] StatusData, String Encoding) throws IOException, EDACancelException
  {
    Scanner scanner = null;
    int x = 0;

	Map<String, String> StatusContent = new HashMap<String, String>();
    
    s_logger.info("Start GetStatusInfo with " + XMLFileName + " " + StatusElement + " " + Encoding);

    if (Encoding.length() > 0)
    {
      scanner = new Scanner(new File(XMLFileName), Encoding);
    }
    else
    {
      scanner = new Scanner(new File(XMLFileName));
    }

    scanner.useDelimiter("\\Z"); // scan to end of file
    scanner.next();
    scanner.close();

    File XMLFile = new File(XMLFileName);

    try
    {    
      DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
      DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
      Document doc = docBuilder.parse(XMLFile);

      // normalize text representation
      doc.getDocumentElement().normalize();

      NodeList EDAStatus = doc.getElementsByTagName(StatusElement);
      
      if (EDAStatus.getLength() != 1)
      {
        s_logger.error("GetStatusInfo: element not found: " + StatusElement);
        throw new SAXException("GetStatusInfo: " + registry.getString("notFound") + StatusElement);
      }
      Element el = (Element)EDAStatus.item(0);

      for (x = 0; x < StatusData.length; x++)
      {
	    StatusContent.put(StatusData[x].toUpperCase(), el.getAttribute(StatusData[x]));
        s_logger.info(StatusData[x].toUpperCase() + " - " + el.getAttribute(StatusData[x]));
      } 
    }
    catch (SAXException e)
    {
      s_logger.error("GetStatusInfo SAXException " + e.getMessage());
      throw new EDACancelException("GetStatusInfo SAXException: " + e.getMessage());
    }
    catch (ParserConfigurationException e)
    {
      s_logger.error("GetStatusInfo ParserConfigurationException " + e.getMessage());
      throw new EDACancelException("GetStatusInfo ParserConfigurationException: " + e.getMessage());
    } finally {
      s_logger.info("Finished GetStatusInfo");
    } 
    
    return StatusContent;
  }  

  //
  // using the mapped BOM data and a template file convert the EPLAN bom to TC design file with BOM data
  //
  public void CreateBOMDesign(String inputBomFileName, Map<String, String> BOMContent, String edaBOMFileName, String ItemId) throws IOException, EDAException, SAXException, ParserConfigurationException, InterruptedException, EDACancelException
  {
	try {
      s_logger.info("Start CreateBOMDesign");    
      
      s_logger.info(edaBOMFileName);
      
      FileDelete(edaBOMFileName);
      
      BOMContent.put("HEAD_ID", ItemId); 
      CreateXMLFromTemplate(new File(inputBomFileName), BOMContent, edaBOMFileName, "UTF-8", true);      
    } catch (IOException e) {
      s_logger.error("CreateBOMDesign IOException: " + e.getMessage()); 
      throw new IOException("CreateBOMDesign IOException:" + e.getMessage());       
    } finally {
      s_logger.info("Finished CreateBOMDesign"); 
    }
  } 
  
  //
  // create a file using a template
  // the place holders will be filled the the data mapped in the Contents
  // if the parameter Verify == true - a check will be run to assure all place holders are filled
  //
  public void CreateXMLFromTemplate(File XMLTemplate, Map<String, String> Contents, String XMLTarget, String Encoding, boolean Verify) throws EDAException, FileNotFoundException, IOException 
  {
    Scanner scanner = null;
    
    s_logger.info("Start CreateXMLFromTemplate with " + XMLTarget + " using template " + XMLTemplate + " with encoding " + Encoding);
    
    String variableStart = registry.getString("templatevariable.startsequence");
    String variableEnd = registry.getString("templatevariable.endsequence");
    
    if (Encoding.length() > 0)
    {
      scanner = new Scanner(XMLTemplate, Encoding);
    }
    else
    {
      scanner = new Scanner(XMLTemplate);
      s_logger.warn("no Encoding");
    }
    
    scanner.useDelimiter("\\Z"); // scan to end of file
    String template = scanner.next();
    scanner.close();

    String fileText = AssembleString(template, Contents);
    
    // verify that all variables were replaced:
    if (Verify == true)
    {
      if (fileText.matches("(?s).*" + variableStart + ".*" + variableEnd + ".*")) 
      {
        s_logger.error("CreateXMLFromTemplate: Not all variables were replaced!");
        throw new EDAException("CreateXMLFromTemplate: " + registry.getString("eplan.not.all.replaced"));
      }
    }
    
    try {
      OutputStreamWriter fwrite = null;
      if (Encoding.length() > 0)
      {    
        fwrite = new OutputStreamWriter(new FileOutputStream(XMLTarget), Encoding);
      } 
      else 
      {
        fwrite = new OutputStreamWriter(new FileOutputStream(XMLTarget));
      }
      fwrite.write(fileText);
      fwrite.close();
      
      // check now if exists
      File XMLFile = new File(XMLTarget);
      if (!XMLFile.exists())
      {
        s_logger.error("CreateXMLFromTemplate file " + XMLTarget + " couldn't be created.");
        throw new EDACancelException("CreateXMLFromTemplate " + registry.getString("errorCreate") + " " + XMLTarget);
      }       
      
    } catch (IOException e) {
      s_logger.error("CreateXMLFromTemplate IOException: " + e.getMessage());
      throw new EDACancelException("CreateXMLFromTemplate IOException: " + e.getMessage());  
    } finally {
      s_logger.info("Finished CreateXMLFromTemplate");
    }
  }   
  
  //
  // delete all files with the name starting with the nameFile in the given directory
  //
  public void CleanUpDir (String directoryName, String nameFile) throws IOException, EDACancelException
  {
    s_logger.info("Start CleanUpDir with " + directoryName +  "\\" + nameFile + "*.*");
    
    try {
      File dir = new File(directoryName);
    
      if (dir.exists())
      {
        for (File file : dir.listFiles()) 
        {
          String fileName = file.getName();
      
          // check the name and extension
          if (fileName.startsWith((nameFile))) 
          {
            if (file.isDirectory()) {
              // recurse, can happen for SaveDerivedData!
              CleanUpDir(file.getAbsolutePath(), nameFile);
            }
            if (!file.delete())
            {
              s_logger.error("CleanUpDir couldn't delete file: " + fileName);
              throw new EDACancelException(registry.getString("cantDelete") + fileName);
            }
            s_logger.info("File : " + fileName + " deleted");
          }
        } 
      }
    } catch (IOException e) {
      s_logger.error("CleanUpDir :" + e.getMessage());
      throw new EDACancelException("CleanUpDir IOException:" + e.getMessage());
    } finally {
      s_logger.info("Finished CleanUpDir");
    }
  }  
  
  //
  //  delete a single file
  //
  public void FileDelete (String FileName) throws IOException, EDACancelException
  {
    s_logger.info("Start FileDelete with " + FileName);
    
    try 
    {
      File myFile = new File(FileName);
      
      if (myFile.exists())
      {
        if (!myFile.delete())
        {
          s_logger.error("FileDelete couldn't delete file: " + FileName);
          throw new EDACancelException(registry.getString("cantDelete") + FileName);
        }
      }
    } finally {
      s_logger.info("Finished FileDelete");
    }    
  }    
  
  //
  //  delete in the directory all files with the name = nameFile+nameExt
  // if the nameFile equals * - delete all files witht he file name extension = nameExt
  //
  public void CleanUpDirExt (String directoryName, String nameFile, String nameExt) throws IOException, EDACancelException
  {
    s_logger.info("Start CleanUpDirExt with " + directoryName +  "\\" + nameFile + nameExt);
    
    try 
    {
      File dir = new File(directoryName);
      
      if (dir.exists())
      {
        for (File file : dir.listFiles()) 
        {
          String fileName = file.getName();
          s_logger.info("CleanUpDirExt found file " + fileName);
      
          if (!nameFile.equals("*"))
          {
            // check the name and extension
            if (fileName.equals((nameFile + nameExt))) 
            {
              if (!file.delete())
              {
                s_logger.error("CleanUpDirExt couldn't delete file: " + fileName);
                throw new EDACancelException(registry.getString("cantDelete") + fileName);
              }
            }
          }
          else
          {
            // check only extension
            if (fileName.endsWith((nameExt))) 
            {
              if (!file.delete())
              {
                s_logger.error("CleanUpDirExt couldn't delete file: " + fileName);
                throw new EDACancelException(registry.getString("cantDelete") + fileName);
              }
            }
          }
        }
      }
    } finally {
      s_logger.info("Finished CleanUpDirExt");
    }    
  }  
  
  
  //
  //  searches the directory for a file which name starts with projectId and the name extension .xml
  //
  public String FindBOMXML (String directoryName, String projectId) throws IOException
  {
    String CompleteBOMFileName = null;
    
    s_logger.info("Start FindBOMXML " + directoryName +  " " + projectId);
    
    try {
      File dir = new File(directoryName);
      
      if (dir.exists()) 
      {
        for (File file : dir.listFiles()) 
        {
          String fileName = file.getName();
          if (fileName.startsWith((projectId))) 
          {
            if (fileName.endsWith((".xml"))) 
            {
              CompleteBOMFileName = directoryName + "\\" + fileName;
            }
          }
        }  
      }      
    } finally {
      s_logger.info("Finished FindBOMXML " + CompleteBOMFileName);
    }
    return CompleteBOMFileName;
  }  
  
  //
  //  find a the name of a file with the given file name extension in the given directory
  //
  public String FindFileName (String directoryName, String nameExt)
  {
    String NameOnly = "";
    
    File dir = new File(directoryName);
    
    if (dir.exists()) 
    {
      for (File file : dir.listFiles()) 
      {
        String fileName = file.getName();
        if (fileName.endsWith((nameExt))) 
        {
           int dot = fileName.lastIndexOf(".");
           int sep = fileName.lastIndexOf("\\");
           NameOnly =  fileName.substring(sep + 1, dot);
        }
      }  
    }      
    return NameOnly;
  }
  
  //
  //  check if directory exists, id not create it
  //
  public void CheckDirectory (String directoryName, boolean CleanUp) throws IOException, EDACancelException
  {
    s_logger.info("Start CheckDirectory " + directoryName);
    try {
      File targetDir = new File(directoryName);
      if (!targetDir.exists())
      {
        s_logger.info("create " + directoryName);
        if (!targetDir.mkdirs())
        {
          s_logger.error("error creating " + directoryName);
          throw new EDACancelException("CheckDirectory: " + registry.getString("errorCreate") + " " + directoryName);
        }
      }
      else
      {
        if (CleanUp == true) CleanUpDir(directoryName, "");
      }
     } catch (IOException e) {
       s_logger.error("CheckDirectory IOException " + e.getMessage());
       throw new EDACancelException("CheckDirectory IOException:" + e.getMessage());
     } finally {
       s_logger.info("Finished CheckDirectory");
     } 
  }  
  
  //
  //  pop up dialog - with YES/NO buttons
  //  
  static boolean ask4EPLANStart(String titleTxt, String infoTxt)
  {
    int result = JOptionPane.showConfirmDialog(null, infoTxt, titleTxt, JOptionPane.YES_NO_OPTION);
  
    return(result == JOptionPane.YES_OPTION);
  }  
  
  //
  //  pop up dialog - with OK button
  //
  static void ShowInfo(String titleTxt, String infoTxt)
  {
    JOptionPane.showConfirmDialog(null, infoTxt, titleTxt, JOptionPane.DEFAULT_OPTION);
  }    
} 
