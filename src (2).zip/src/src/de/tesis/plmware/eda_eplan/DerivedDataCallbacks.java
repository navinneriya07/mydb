package de.tesis.plmware.eda_eplan;

import java.io.File;
import java.io.IOException;
import java.util.Map;
import java.util.ResourceBundle;

import javax.xml.parsers.ParserConfigurationException;

import org.slf4j.Logger;
import org.xml.sax.SAXException;

import com.teamcenter.edabase.EDACancelException;
import com.teamcenter.edabase.EDAConfiguration;
import com.teamcenter.edabase.EDAException;

public class DerivedDataCallbacks {

  ResourceBundle registry;
  private EPLANToolbox tools = new EPLANToolbox();
  private static Logger s_logger = null;
  
  public DerivedDataCallbacks() throws IOException, EDAException 
  {
    registry = tools.GetRegistry();      
    if (s_logger == null) {
      s_logger = EPLANToolbox.getLogger(EPLANAdapter.class.getName());
    }
  } 
  
  public static int getMethodNameIndex() {
    String methodName = Thread.currentThread().getStackTrace()[2].getMethodName();
    return Integer.valueOf(methodName.substring("Callback".length()));
  } 
  
  public void CreateDerivedData(String edaDesignFileName, int callbackId) throws IOException, InterruptedException, SAXException, ParserConfigurationException, EDAException {
    s_logger.info("CreateDerivedData: " + edaDesignFileName + ", Id: " + callbackId);
    tools.initDynamicProperties();

    Map<String, String> DesignContents = tools.ReadDesignXML(edaDesignFileName, "UTF-8");
    
    // get the project id of eplan - EPLAN_PROJECT_ID
    if (tools.Properties.get("EPLAN_PROJECT_ID") == null)    throw new EDACancelException(registry.getString("missing.EPLAN_PROJECT_ID"));
    if (tools.Properties.get("EPLAN_PROJECT_ID").equals("")) throw new EDACancelException(registry.getString("missing.EPLAN_PROJECT_ID"));

    String itemID = DesignContents.get("ITEMID");
    s_logger.info("CreateDerivedData: itemID from EDA design file: " + itemID);  
    if(itemID == null || itemID.isEmpty()) {
      // if itemID is not (yet) in the design file, retrieve it from the EPLAN_PROJECT_ID:
      tools.Properties.get("EPLAN_PROJECT_ID");
      s_logger.info("CreateDerivedData: EPLAN_PROJECT_ID " + itemID);  
      s_logger.info("CreateDerivedData: INCL_NAME is " + tools.Properties.get("INCL_NAME"));  
      if (tools.Properties.get("INCL_NAME").equals("ON"))
      {
        // split to get the item id
        String[] ItemIdOnly;
        ItemIdOnly = tools.Properties.get("EPLAN_PROJECT_ID").split(tools.Properties.get("DELIMITER"), 2);      
        s_logger.info("CreateDerivedData: ItemIdOnly " + ItemIdOnly);  

        itemID = ItemIdOnly[0];
      }
    }
    s_logger.info("CreateDerivedData: itemID " + itemID);  

    // check if the required data has been read
    if (!DesignContents.containsKey("DATASET_SRC")) throw new EDAException("CreateDerivedData: " + registry.getString("edadesign.missing.stagingDir"));

    DesignContents.put("EPLAN_PROJECT_ID", tools.Properties.get("EPLAN_PROJECT_ID"));

    String targetDirName = new File(DesignContents.get("DATASET_SRC")).getAbsolutePath();
    		//EDAConfiguration.getInstance().getStagingDirName() + "\\latest\\" + itemID;
    
    
    s_logger.info("targetDirName " + targetDirName);
    
    tools.CheckDirectory(targetDirName, false);

    String derivedDataCheck = tools.DerivedDataPreCheck(tools.Properties.get("EPLAN_PROJECT_ID"));
    if (!derivedDataCheck.equals("OK"))
    {
      throw new EDACancelException("CreateDerivedData: " + derivedDataCheck);
    }
    
		if (!registry.containsKey("eda2eplan.derivedData.type." + Integer.toString(callbackId)))
		{
		  throw new EDACancelException("ProceedDerivedData: " + registry.getString("eplan.no.deriveddata.type") + Integer.toString(callbackId));
		}    
		String dataType = registry.getString("eda2eplan.derivedData.type." + Integer.toString(callbackId)); 
    DesignContents.put("DOC_SCHEMA", dataType);

    if (!registry.containsKey("eda2eplan." + dataType + ".language"))
		{
		  throw new EDACancelException("ProceedDerivedData: " + registry.getString("eplan.no.deriveddata.language") + dataType);
		}           
		String language = registry.getString("eda2eplan." + dataType + ".language");
    DesignContents.put("DOC_LANGUAGE", language);

    if (!registry.containsKey("eda2eplan." + dataType + ".section"))
		{
		  throw new EDACancelException("ProceedDerivedData: " + registry.getString("eplan.no.deriveddata.section") + dataType);
		}
		String section = registry.getString("eda2eplan." + dataType + ".section");
    DesignContents.put("DOC_TYPE", section);
    
    if (tools.StartEPLAN("docExportExtern", DesignContents) != 1) throw new EDAException(registry.getString("eplan.derivedData.fail")); 

    // proceed the derived data
    tools.cleanupDerivedDataTargetforType(targetDirName, itemID, callbackId); 
    tools.proceedDerivedDataForType(targetDirName, tools.Properties.get("EPLAN_PROJECT_ID"), itemID, callbackId);   
    tools.cleanupDerivedDataSourceForType(tools.Properties.get("EPLAN_PROJECT_ID"), callbackId);
    
    s_logger.info("Finished CreateDerivedData");
  }

  public void Callback1(String edaDesignFileName) throws IOException, InterruptedException, SAXException, ParserConfigurationException, EDAException {
  	CreateDerivedData(edaDesignFileName, getMethodNameIndex());
  }

  public void Callback2(String edaDesignFileName) throws IOException, InterruptedException, SAXException, ParserConfigurationException, EDAException {
  	CreateDerivedData(edaDesignFileName, getMethodNameIndex());
  }

  public void Callback3(String edaDesignFileName) throws IOException, InterruptedException, SAXException, ParserConfigurationException, EDAException {
  	CreateDerivedData(edaDesignFileName, getMethodNameIndex());
  }

  public void Callback4(String edaDesignFileName) throws IOException, InterruptedException, SAXException, ParserConfigurationException, EDAException {
  	CreateDerivedData(edaDesignFileName, getMethodNameIndex());
  }

  public void Callback5(String edaDesignFileName) throws IOException, InterruptedException, SAXException, ParserConfigurationException, EDAException {
  	CreateDerivedData(edaDesignFileName, getMethodNameIndex());
  }

  public void Callback6(String edaDesignFileName) throws IOException, InterruptedException, SAXException, ParserConfigurationException, EDAException {
  	CreateDerivedData(edaDesignFileName, getMethodNameIndex());
  }

  public void Callback7(String edaDesignFileName) throws IOException, InterruptedException, SAXException, ParserConfigurationException, EDAException {
  	CreateDerivedData(edaDesignFileName, getMethodNameIndex());
  }

  public void Callback8(String edaDesignFileName) throws IOException, InterruptedException, SAXException, ParserConfigurationException, EDAException {
  	CreateDerivedData(edaDesignFileName, getMethodNameIndex());
  }

  public void Callback9(String edaDesignFileName) throws IOException, InterruptedException, SAXException, ParserConfigurationException, EDAException {
  	CreateDerivedData(edaDesignFileName, getMethodNameIndex());
  }

  public void Callback10(String edaDesignFileName) throws IOException, InterruptedException, SAXException, ParserConfigurationException, EDAException {
  	CreateDerivedData(edaDesignFileName, getMethodNameIndex());
  }

  public void Callback11(String edaDesignFileName) throws IOException, InterruptedException, SAXException, ParserConfigurationException, EDAException {
  	CreateDerivedData(edaDesignFileName, getMethodNameIndex());
  }

  public void Callback12(String edaDesignFileName) throws IOException, InterruptedException, SAXException, ParserConfigurationException, EDAException {
  	CreateDerivedData(edaDesignFileName, getMethodNameIndex());
  }

  public void Callback13(String edaDesignFileName) throws IOException, InterruptedException, SAXException, ParserConfigurationException, EDAException {
  	CreateDerivedData(edaDesignFileName, getMethodNameIndex());
  }

  public void Callback14(String edaDesignFileName) throws IOException, InterruptedException, SAXException, ParserConfigurationException, EDAException {
  	CreateDerivedData(edaDesignFileName, getMethodNameIndex());
  }

  public void Callback15(String edaDesignFileName) throws IOException, InterruptedException, SAXException, ParserConfigurationException, EDAException {
  	CreateDerivedData(edaDesignFileName, getMethodNameIndex());
  }

  public void Callback16(String edaDesignFileName) throws IOException, InterruptedException, SAXException, ParserConfigurationException, EDAException {
  	CreateDerivedData(edaDesignFileName, getMethodNameIndex());
  }

  public void Callback17(String edaDesignFileName) throws IOException, InterruptedException, SAXException, ParserConfigurationException, EDAException {
  	CreateDerivedData(edaDesignFileName, getMethodNameIndex());
  }

  public void Callback18(String edaDesignFileName) throws IOException, InterruptedException, SAXException, ParserConfigurationException, EDAException {
  	CreateDerivedData(edaDesignFileName, getMethodNameIndex());
  }

  public void Callback19(String edaDesignFileName) throws IOException, InterruptedException, SAXException, ParserConfigurationException, EDAException {
  	CreateDerivedData(edaDesignFileName, getMethodNameIndex());
  }

  public void Callback20(String edaDesignFileName) throws IOException, InterruptedException, SAXException, ParserConfigurationException, EDAException {
  	CreateDerivedData(edaDesignFileName, getMethodNameIndex());
  }

  public void Callback21(String edaDesignFileName) throws IOException, InterruptedException, SAXException, ParserConfigurationException, EDAException {
  	CreateDerivedData(edaDesignFileName, getMethodNameIndex());
  }

  public void Callback22(String edaDesignFileName) throws IOException, InterruptedException, SAXException, ParserConfigurationException, EDAException {
  	CreateDerivedData(edaDesignFileName, getMethodNameIndex());
  }

  public void Callback23(String edaDesignFileName) throws IOException, InterruptedException, SAXException, ParserConfigurationException, EDAException {
  	CreateDerivedData(edaDesignFileName, getMethodNameIndex());
  }

  public void Callback24(String edaDesignFileName) throws IOException, InterruptedException, SAXException, ParserConfigurationException, EDAException {
  	CreateDerivedData(edaDesignFileName, getMethodNameIndex());
  }

  public void Callback25(String edaDesignFileName) throws IOException, InterruptedException, SAXException, ParserConfigurationException, EDAException {
  	CreateDerivedData(edaDesignFileName, getMethodNameIndex());
  }

  public void Callback26(String edaDesignFileName) throws IOException, InterruptedException, SAXException, ParserConfigurationException, EDAException {
  	CreateDerivedData(edaDesignFileName, getMethodNameIndex());
  }

  public void Callback27(String edaDesignFileName) throws IOException, InterruptedException, SAXException, ParserConfigurationException, EDAException {
  	CreateDerivedData(edaDesignFileName, getMethodNameIndex());
  }

  public void Callback28(String edaDesignFileName) throws IOException, InterruptedException, SAXException, ParserConfigurationException, EDAException {
  	CreateDerivedData(edaDesignFileName, getMethodNameIndex());
  }

  public void Callback29(String edaDesignFileName) throws IOException, InterruptedException, SAXException, ParserConfigurationException, EDAException {
  	CreateDerivedData(edaDesignFileName, getMethodNameIndex());
  }

  public void Callback30(String edaDesignFileName) throws IOException, InterruptedException, SAXException, ParserConfigurationException, EDAException {
  	CreateDerivedData(edaDesignFileName, getMethodNameIndex());
  }

  public void Callback31(String edaDesignFileName) throws IOException, InterruptedException, SAXException, ParserConfigurationException, EDAException {
  	CreateDerivedData(edaDesignFileName, getMethodNameIndex());
  }

  public void Callback32(String edaDesignFileName) throws IOException, InterruptedException, SAXException, ParserConfigurationException, EDAException {
  	CreateDerivedData(edaDesignFileName, getMethodNameIndex());
  }

  public void Callback33(String edaDesignFileName) throws IOException, InterruptedException, SAXException, ParserConfigurationException, EDAException {
  	CreateDerivedData(edaDesignFileName, getMethodNameIndex());
  }

  public void Callback34(String edaDesignFileName) throws IOException, InterruptedException, SAXException, ParserConfigurationException, EDAException {
  	CreateDerivedData(edaDesignFileName, getMethodNameIndex());
  }

  public void Callback35(String edaDesignFileName) throws IOException, InterruptedException, SAXException, ParserConfigurationException, EDAException {
  	CreateDerivedData(edaDesignFileName, getMethodNameIndex());
  }

  public void Callback36(String edaDesignFileName) throws IOException, InterruptedException, SAXException, ParserConfigurationException, EDAException {
  	CreateDerivedData(edaDesignFileName, getMethodNameIndex());
  }

  public void Callback37(String edaDesignFileName) throws IOException, InterruptedException, SAXException, ParserConfigurationException, EDAException {
  	CreateDerivedData(edaDesignFileName, getMethodNameIndex());
  }

  public void Callback38(String edaDesignFileName) throws IOException, InterruptedException, SAXException, ParserConfigurationException, EDAException {
  	CreateDerivedData(edaDesignFileName, getMethodNameIndex());
  }

  public void Callback39(String edaDesignFileName) throws IOException, InterruptedException, SAXException, ParserConfigurationException, EDAException {
  	CreateDerivedData(edaDesignFileName, getMethodNameIndex());
  }

  public void Callback40(String edaDesignFileName) throws IOException, InterruptedException, SAXException, ParserConfigurationException, EDAException {
  	CreateDerivedData(edaDesignFileName, getMethodNameIndex());
  }

  public void Callback41(String edaDesignFileName) throws IOException, InterruptedException, SAXException, ParserConfigurationException, EDAException {
  	CreateDerivedData(edaDesignFileName, getMethodNameIndex());
  }

  public void Callback42(String edaDesignFileName) throws IOException, InterruptedException, SAXException, ParserConfigurationException, EDAException {
  	CreateDerivedData(edaDesignFileName, getMethodNameIndex());
  }

  public void Callback43(String edaDesignFileName) throws IOException, InterruptedException, SAXException, ParserConfigurationException, EDAException {
  	CreateDerivedData(edaDesignFileName, getMethodNameIndex());
  }

  public void Callback44(String edaDesignFileName) throws IOException, InterruptedException, SAXException, ParserConfigurationException, EDAException {
  	CreateDerivedData(edaDesignFileName, getMethodNameIndex());
  }

  public void Callback45(String edaDesignFileName) throws IOException, InterruptedException, SAXException, ParserConfigurationException, EDAException {
  	CreateDerivedData(edaDesignFileName, getMethodNameIndex());
  }

  public void Callback46(String edaDesignFileName) throws IOException, InterruptedException, SAXException, ParserConfigurationException, EDAException {
  	CreateDerivedData(edaDesignFileName, getMethodNameIndex());
  }

  public void Callback47(String edaDesignFileName) throws IOException, InterruptedException, SAXException, ParserConfigurationException, EDAException {
  	CreateDerivedData(edaDesignFileName, getMethodNameIndex());
  }

  public void Callback48(String edaDesignFileName) throws IOException, InterruptedException, SAXException, ParserConfigurationException, EDAException {
  	CreateDerivedData(edaDesignFileName, getMethodNameIndex());
  }

  public void Callback49(String edaDesignFileName) throws IOException, InterruptedException, SAXException, ParserConfigurationException, EDAException {
  	CreateDerivedData(edaDesignFileName, getMethodNameIndex());
  }

  public void Callback50(String edaDesignFileName) throws IOException, InterruptedException, SAXException, ParserConfigurationException, EDAException {
  	CreateDerivedData(edaDesignFileName, getMethodNameIndex());
  }

  public void Callback51(String edaDesignFileName) throws IOException, InterruptedException, SAXException, ParserConfigurationException, EDAException {
  	CreateDerivedData(edaDesignFileName, getMethodNameIndex());
  }

  public void Callback52(String edaDesignFileName) throws IOException, InterruptedException, SAXException, ParserConfigurationException, EDAException {
  	CreateDerivedData(edaDesignFileName, getMethodNameIndex());
  }

  public void Callback53(String edaDesignFileName) throws IOException, InterruptedException, SAXException, ParserConfigurationException, EDAException {
  	CreateDerivedData(edaDesignFileName, getMethodNameIndex());
  }

  public void Callback54(String edaDesignFileName) throws IOException, InterruptedException, SAXException, ParserConfigurationException, EDAException {
  	CreateDerivedData(edaDesignFileName, getMethodNameIndex());
  }

  public void Callback55(String edaDesignFileName) throws IOException, InterruptedException, SAXException, ParserConfigurationException, EDAException {
  	CreateDerivedData(edaDesignFileName, getMethodNameIndex());
  }

  public void Callback56(String edaDesignFileName) throws IOException, InterruptedException, SAXException, ParserConfigurationException, EDAException {
  	CreateDerivedData(edaDesignFileName, getMethodNameIndex());
  }

  public void Callback57(String edaDesignFileName) throws IOException, InterruptedException, SAXException, ParserConfigurationException, EDAException {
  	CreateDerivedData(edaDesignFileName, getMethodNameIndex());
  }

  public void Callback58(String edaDesignFileName) throws IOException, InterruptedException, SAXException, ParserConfigurationException, EDAException {
  	CreateDerivedData(edaDesignFileName, getMethodNameIndex());
  }

  public void Callback59(String edaDesignFileName) throws IOException, InterruptedException, SAXException, ParserConfigurationException, EDAException {
  	CreateDerivedData(edaDesignFileName, getMethodNameIndex());
  }

  public void Callback60(String edaDesignFileName) throws IOException, InterruptedException, SAXException, ParserConfigurationException, EDAException {
  	CreateDerivedData(edaDesignFileName, getMethodNameIndex());
  }

  public void Callback61(String edaDesignFileName) throws IOException, InterruptedException, SAXException, ParserConfigurationException, EDAException {
  	CreateDerivedData(edaDesignFileName, getMethodNameIndex());
  }

  public void Callback62(String edaDesignFileName) throws IOException, InterruptedException, SAXException, ParserConfigurationException, EDAException {
  	CreateDerivedData(edaDesignFileName, getMethodNameIndex());
  }

  public void Callback63(String edaDesignFileName) throws IOException, InterruptedException, SAXException, ParserConfigurationException, EDAException {
  	CreateDerivedData(edaDesignFileName, getMethodNameIndex());
  }

  public void Callback64(String edaDesignFileName) throws IOException, InterruptedException, SAXException, ParserConfigurationException, EDAException {
  	CreateDerivedData(edaDesignFileName, getMethodNameIndex());
  }

  public void Callback65(String edaDesignFileName) throws IOException, InterruptedException, SAXException, ParserConfigurationException, EDAException {
  	CreateDerivedData(edaDesignFileName, getMethodNameIndex());
  }

  public void Callback66(String edaDesignFileName) throws IOException, InterruptedException, SAXException, ParserConfigurationException, EDAException {
  	CreateDerivedData(edaDesignFileName, getMethodNameIndex());
  }

  public void Callback67(String edaDesignFileName) throws IOException, InterruptedException, SAXException, ParserConfigurationException, EDAException {
  	CreateDerivedData(edaDesignFileName, getMethodNameIndex());
  }

  public void Callback68(String edaDesignFileName) throws IOException, InterruptedException, SAXException, ParserConfigurationException, EDAException {
  	CreateDerivedData(edaDesignFileName, getMethodNameIndex());
  }

  public void Callback69(String edaDesignFileName) throws IOException, InterruptedException, SAXException, ParserConfigurationException, EDAException {
  	CreateDerivedData(edaDesignFileName, getMethodNameIndex());
  }

  public void Callback70(String edaDesignFileName) throws IOException, InterruptedException, SAXException, ParserConfigurationException, EDAException {
  	CreateDerivedData(edaDesignFileName, getMethodNameIndex());
  }

  public void Callback71(String edaDesignFileName) throws IOException, InterruptedException, SAXException, ParserConfigurationException, EDAException {
  	CreateDerivedData(edaDesignFileName, getMethodNameIndex());
  }

  public void Callback72(String edaDesignFileName) throws IOException, InterruptedException, SAXException, ParserConfigurationException, EDAException {
  	CreateDerivedData(edaDesignFileName, getMethodNameIndex());
  }

  public void Callback73(String edaDesignFileName) throws IOException, InterruptedException, SAXException, ParserConfigurationException, EDAException {
  	CreateDerivedData(edaDesignFileName, getMethodNameIndex());
  }

  public void Callback74(String edaDesignFileName) throws IOException, InterruptedException, SAXException, ParserConfigurationException, EDAException {
  	CreateDerivedData(edaDesignFileName, getMethodNameIndex());
  }

  public void Callback75(String edaDesignFileName) throws IOException, InterruptedException, SAXException, ParserConfigurationException, EDAException {
  	CreateDerivedData(edaDesignFileName, getMethodNameIndex());
  }

  public void Callback76(String edaDesignFileName) throws IOException, InterruptedException, SAXException, ParserConfigurationException, EDAException {
  	CreateDerivedData(edaDesignFileName, getMethodNameIndex());
  }

  public void Callback77(String edaDesignFileName) throws IOException, InterruptedException, SAXException, ParserConfigurationException, EDAException {
  	CreateDerivedData(edaDesignFileName, getMethodNameIndex());
  }

  public void Callback78(String edaDesignFileName) throws IOException, InterruptedException, SAXException, ParserConfigurationException, EDAException {
  	CreateDerivedData(edaDesignFileName, getMethodNameIndex());
  }

  public void Callback79(String edaDesignFileName) throws IOException, InterruptedException, SAXException, ParserConfigurationException, EDAException {
  	CreateDerivedData(edaDesignFileName, getMethodNameIndex());
  }
  
  public void Callback80(String edaDesignFileName) throws IOException, InterruptedException, SAXException, ParserConfigurationException, EDAException {
  	CreateDerivedData(edaDesignFileName, getMethodNameIndex());
  }

  public void Callback81(String edaDesignFileName) throws IOException, InterruptedException, SAXException, ParserConfigurationException, EDAException {
  	CreateDerivedData(edaDesignFileName, getMethodNameIndex());
  }

  public void Callback82(String edaDesignFileName) throws IOException, InterruptedException, SAXException, ParserConfigurationException, EDAException {
  	CreateDerivedData(edaDesignFileName, getMethodNameIndex());
  }

  public void Callback83(String edaDesignFileName) throws IOException, InterruptedException, SAXException, ParserConfigurationException, EDAException {
  	CreateDerivedData(edaDesignFileName, getMethodNameIndex());
  }

  public void Callback84(String edaDesignFileName) throws IOException, InterruptedException, SAXException, ParserConfigurationException, EDAException {
  	CreateDerivedData(edaDesignFileName, getMethodNameIndex());
  }

  public void Callback85(String edaDesignFileName) throws IOException, InterruptedException, SAXException, ParserConfigurationException, EDAException {
  	CreateDerivedData(edaDesignFileName, getMethodNameIndex());
  }

  public void Callback86(String edaDesignFileName) throws IOException, InterruptedException, SAXException, ParserConfigurationException, EDAException {
  	CreateDerivedData(edaDesignFileName, getMethodNameIndex());
  }

  public void Callback87(String edaDesignFileName) throws IOException, InterruptedException, SAXException, ParserConfigurationException, EDAException {
  	CreateDerivedData(edaDesignFileName, getMethodNameIndex());
  }

  public void Callback88(String edaDesignFileName) throws IOException, InterruptedException, SAXException, ParserConfigurationException, EDAException {
  	CreateDerivedData(edaDesignFileName, getMethodNameIndex());
  }

  public void Callback89(String edaDesignFileName) throws IOException, InterruptedException, SAXException, ParserConfigurationException, EDAException {
  	CreateDerivedData(edaDesignFileName, getMethodNameIndex());
  }

  public void Callback90(String edaDesignFileName) throws IOException, InterruptedException, SAXException, ParserConfigurationException, EDAException {
  	CreateDerivedData(edaDesignFileName, getMethodNameIndex());
  }

  public void Callback91(String edaDesignFileName) throws IOException, InterruptedException, SAXException, ParserConfigurationException, EDAException {
  	CreateDerivedData(edaDesignFileName, getMethodNameIndex());
  }

  public void Callback92(String edaDesignFileName) throws IOException, InterruptedException, SAXException, ParserConfigurationException, EDAException {
  	CreateDerivedData(edaDesignFileName, getMethodNameIndex());
  }

  public void Callback93(String edaDesignFileName) throws IOException, InterruptedException, SAXException, ParserConfigurationException, EDAException {
  	CreateDerivedData(edaDesignFileName, getMethodNameIndex());
  }

  public void Callback94(String edaDesignFileName) throws IOException, InterruptedException, SAXException, ParserConfigurationException, EDAException {
  	CreateDerivedData(edaDesignFileName, getMethodNameIndex());
  }

  public void Callback95(String edaDesignFileName) throws IOException, InterruptedException, SAXException, ParserConfigurationException, EDAException {
  	CreateDerivedData(edaDesignFileName, getMethodNameIndex());
  }

  public void Callback96(String edaDesignFileName) throws IOException, InterruptedException, SAXException, ParserConfigurationException, EDAException {
  	CreateDerivedData(edaDesignFileName, getMethodNameIndex());
  }

  public void Callback97(String edaDesignFileName) throws IOException, InterruptedException, SAXException, ParserConfigurationException, EDAException {
  	CreateDerivedData(edaDesignFileName, getMethodNameIndex());
  }

  public void Callback98(String edaDesignFileName) throws IOException, InterruptedException, SAXException, ParserConfigurationException, EDAException {
  	CreateDerivedData(edaDesignFileName, getMethodNameIndex());
  }

  public void Callback99(String edaDesignFileName) throws IOException, InterruptedException, SAXException, ParserConfigurationException, EDAException {
  	CreateDerivedData(edaDesignFileName, getMethodNameIndex());
  }

  public void Callback100(String edaDesignFileName) throws IOException, InterruptedException, SAXException, ParserConfigurationException, EDAException {
  	CreateDerivedData(edaDesignFileName, getMethodNameIndex());
  }
}
