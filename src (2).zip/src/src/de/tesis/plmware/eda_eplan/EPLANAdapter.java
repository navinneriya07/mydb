// SVN:       $Id: EPLANAdapter.java 446 2017-11-02 14:54:57Z aska $            
package de.tesis.plmware.eda_eplan;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.ResourceBundle;
import java.util.Vector;

import javax.xml.parsers.ParserConfigurationException;

import org.slf4j.Logger;
import org.xml.sax.SAXException;

import com.teamcenter.edabase.EDACancelException;
import com.teamcenter.edabase.EDAConfiguration;
import com.teamcenter.edabase.EDAException;

public class EPLANAdapter {

  ResourceBundle registry;
  EPLANToolbox tools = new EPLANToolbox();
  private static Logger s_logger = null;
  static long derivedDataLastCommandDate = 0;
  
  public EPLANAdapter() throws IOException, EDAException 
  {
    registry = tools.GetRegistry();      
    if (s_logger == null) {
      s_logger = EPLANToolbox.getLogger(EPLANAdapter.class.getName());
    }
  } 
  
  //
  //  REVISE...
  //
  //
  
  //
  // preRevise - pre action
  //   checks if the EPLAN project has write access for Revise
  //     save the EPLAN project to zw1 file
  //     copy the zw1 file to the eda staging directory
  //     creates the eda design xml file
  //
  public void PrePreReviseCall(String applicationName, String edaDesignFileName) throws IOException, EDAException, InterruptedException, SAXException, ParserConfigurationException
  {
    s_logger.info("PrePreReviseCall:" + "\napp: " + applicationName + "\nstatus: " + edaDesignFileName);
    tools.initDynamicProperties();
    
    try { 
      if (edaDesignFileName == null) throw new EDACancelException("PrePreReviseCall: " + registry.getString("eda.design.file.null"));

      Map<String, String> designContents = tools.ReadDesignXML(edaDesignFileName, "UTF-8");  
      
      int bomSelection = 0;
      if (tools.Properties.get("BOMSELECTION") != null) {
        bomSelection = Integer.valueOf(tools.Properties.get("BOMSELECTION")).intValue();
      }

      Map<String, String> StatusContent = new HashMap<String, String>();
      String targetDirName;
      
      // check if the project is checked out otherwise eplan cant write the zw1
      tools.IsCheckedOutCheckCall();
      
      // get the project id of eplan - EPLAN_PROJECT_ID
      if (tools.Properties.get("EPLAN_PROJECT_ID") == null)    throw new EDACancelException(registry.getString("missing.EPLAN_PROJECT_ID"));
      if (tools.Properties.get("EPLAN_PROJECT_ID").equals("")) throw new EDACancelException(registry.getString("missing.EPLAN_PROJECT_ID"));
      
      // get the TC object uid
      if (tools.Properties.get("UID") == null)    tools.Properties.put("UID", "");

      String sourceFileName = tools.Properties.get("EPLAN2EDA_TRANSFER_DIR")  + "\\" +  tools.Properties.get("EPLAN_PROJECT_ID") + ".zw1";
      final String zw1xmlFilename = sourceFileName + ".xml";
	    if ( new File(zw1xmlFilename).exists()) {
	    	// make sure we see the new content by deleting the old file before the extraction
	    	new File(zw1xmlFilename).delete();
	    }
      
      // save the zw1 from elk
      if (tools.StartEPLAN("metadata", StatusContent) == 0) throw new EDACancelException(registry.getString("eplan.revise.cancel"));  
      
      targetDirName = new File(designContents.get("DATASET_SRC")).toString();
      StatusContent.put("HEAD_ID", designContents.get("ITEMID"));

      s_logger.info("PrePreReviseAsCall: targetDirName " + targetDirName);
      // cleanup if exists, create if doesnt (cleanup unconditionally here!)
      tools.CheckDirectory(targetDirName, true);
      
      String targetFileName = targetDirName + "\\" + tools.Properties.get("EPLAN_PROJECT_ID") + ".zw1";
      
      // the real file gets created in Checkin, so we create a dummy here only!
	    File dummyFile = new File(targetFileName); 
	    if ( ! dummyFile.exists()) {
	    	dummyFile.createNewFile();
	    }
      // parse zw1.xml to get the attributes
      String Attributes = tools.ParseZW1XML(zw1xmlFilename, "UTF-16", "");  
    	new File(zw1xmlFilename).delete();
    	
      // store the data for creating design file from the template
      StatusContent.put("EDA_STAGING_DIR_COMPLETE", tools.xmlEscapeText(targetDirName));  
      StatusContent.put("ATTRIBUTES" , Attributes);
      StatusContent.put("HASBOM", "false");
      StatusContent.put("VERSION", "1"); 
      StatusContent.put("BOMLINES", "");
      StatusContent.put("ZW1NAME", tools.Properties.get("EPLAN_PROJECT_ID"));        
      StatusContent.put("UID" , tools.Properties.get("UID"));
      
      // export bom
      // delete in the bom transfer dir all files starting with projectId
      tools.CleanUpDir(tools.Properties.get("EPLAN2EDA_BOM_DIR"), tools.Properties.get("EPLAN_PROJECT_ID"));
      int BOMExported = 0;
      String BomXMLFileName = null;
      if (bomSelection > 1) {
        BOMExported = tools.StartEPLAN("bomExport", StatusContent);
        if (BOMExported == 1) 
        {
          BomXMLFileName = tools.FindBOMXML(tools.Properties.get("EPLAN2EDA_BOM_DIR"), tools.Properties.get("EPLAN_PROJECT_ID"));
        }
      }
      // handle the bom data
      // if no BoM file is present, create an empty "dummy" file.
      if (BOMExported == 0) {
        BomXMLFileName = tools.Properties.get("EPLAN2EDA_BOM_DIR") + "\\" + tools.Properties.get("EPLAN_PROJECT_ID") + ".xml";
        PrintWriter writer = new PrintWriter(BomXMLFileName, "UTF-16");
        writer.println("<Bom/>");
        writer.close();
      }
      if (BomXMLFileName != null)
      { 
        s_logger.trace("Start XSLT main BoM");
        String processedBomFileName = BomXMLFileName + ".processed";
        Vector<String> tmpArgs = new Vector<String> ();
        tmpArgs.add("-PARAM");
        tmpArgs.add("BoMSelection");
        tmpArgs.add(String.valueOf(bomSelection));
        tmpArgs.add("-PARAM");
        tmpArgs.add("UID");
        tmpArgs.add(tools.Properties.get("UID"));
        tmpArgs.add("-XSL");
        tmpArgs.add("scripts\\eplanbomtoedabom.xsl");  
        tmpArgs.add("-IN");
        tmpArgs.add(BomXMLFileName);
        tmpArgs.add("-OUT");
        tmpArgs.add(processedBomFileName);
          
        s_logger.trace("XSLT parameters: " + tmpArgs.toString() + ".");
        com.sun.org.apache.xalan.internal.xslt.Process._main(tmpArgs.toArray(new String[] {})); 
        s_logger.trace("End XSLT main BoM");

        tools.CreateBOMDesign(processedBomFileName, StatusContent, edaDesignFileName, "");
        
        // clean up bom xml
//            tools.FileDelete(BomXMLFileName);
//            tools.FileDelete(processedBomFileName);
      }
      else 
      {
        EPLANToolbox.ShowInfo(registry.getString("dialog.info"), registry.getString("dialog.noBOM")); 
      }            
      
    } finally {
      s_logger.info("Finished PrePreReviseCall");
    } 
  }  

  //
  // revise - post action
  // checks the status of the revise call
  // read the return data from eda status file
  // creates zw1.xml file with meta data and adds an extra attribute for storing the UID
  // opens the project in the EPLAN
  //
  public void PostReviseCall(String applicationName, String edaDesignFileName, String statusFileName) throws IOException, EDACancelException, Exception, InterruptedException
  {
    s_logger.info("PostReviseCall app: " + applicationName + " status: " + statusFileName + " design: " + edaDesignFileName);
    tools.initDynamicProperties();

    if (edaDesignFileName == null) throw new EDACancelException("PostReviseCall: " + registry.getString("eda.design.file.null"));
    if (statusFileName == null)    throw new EDACancelException("PostReviseCall: " + registry.getString("eda.status.file.null"));    
  
    if (tools.Properties.get("ORG_PROJECT_ACCESS") == null)    throw new EDACancelException(registry.getString("missing.ORG_PROJECT_ACCESS"));
    if (tools.Properties.get("ORG_PROJECT_ACCESS").equals("")) throw new EDACancelException(registry.getString("missing.ORG_PROJECT_ACCESS"));
    
    
    try { 
      String[] ReviseStatusData={"status", "message", "checkIn", "UID"};
      Map<String, String> StatusContent;
      Map<String, String> DesignContents;
      
      StatusContent = tools.GetStatusInfo(statusFileName, "EDASaveAsStatus", ReviseStatusData, "UTF-8");
	    s_logger.info("PostReviseCall: " + StatusContent.get("STATUS"));  
      
      // preSaving failed
      if (checkStatus(StatusContent)) return;    
      
      // open the tc object as a project in eplan
      // read the design xml file
	  DesignContents = tools.ReadDesignXML(edaDesignFileName, "UTF-8");  
      
      // get the project id of eplan - EPLAN_PROJECT_ID
      if (tools.Properties.get("EPLAN_PROJECT_ID") == null)    throw new EDACancelException(registry.getString("missing.EPLAN_PROJECT_ID"));
      if (tools.Properties.get("EPLAN_PROJECT_ID").equals("")) throw new EDACancelException(registry.getString("missing.EPLAN_PROJECT_ID"));
      
      // if project checked in no zw1, zw1.xml stay put as it will be closed in eplan->no need for any action here
      // the insert epis command for checked in projects is executed in revise bat script
      if (StatusContent.get("CHECKIN").equals("false"))
      {
        DesignContents.put("UID", StatusContent.get("UID"));
      
        DesignContents.put("READONLY", "0"); 

      
        String ProjectName;
        if (tools.Properties.get("INCL_NAME").equals("ON"))
        {
          ProjectName = DesignContents.get("ITEMID") + tools.Properties.get("DELIMITER") + DesignContents.get("ITEMNAME");
        }
        else
        {
          ProjectName = DesignContents.get("ITEMID");
        }
        DesignContents.put("PROJECT_NAME", ProjectName);
        
        // prepare the attributes from desig for zw1.xml
        DesignContents.put("ATTRIBUTES", tools.PrepareXMLZw1Attributes(DesignContents));
      
        // for the UID transfer
        DesignContents.put("EPLAN_UID_ATTR", tools.Properties.get("EPLAN_UID_ATTR"));

        File XMLTemplate = tools.CheckTemplate(tools.Properties.get("ZW1_XML_TEMPLATE"));
        tools.CreateXMLFromTemplate(XMLTemplate, DesignContents, tools.Properties.get("EDA2EPLAN_TRANSFER_DIR")  + "\\" + ProjectName + ".zw1.xml", "UTF-16", true);      
  
        s_logger.info("PostReviseCall: elkFile write access " + tools.Properties.get("ORG_PROJECT_ACCESS"));  
        if (tools.Properties.get("ORG_PROJECT_ACCESS").equals("RO"))
        {       
          // rename zw1 to the new itemid 
          String sourceFileName = DesignContents.get("DATASET_SRC")  + "\\" +  tools.FindFileName(DesignContents.get("DATASET_SRC"), "zw1") + ".zw1";
          String targetFileName = tools.Properties.get("EDA2EPLAN_TRANSFER_DIR")  + "\\" + ProjectName + ".zw1"; 
                
          // copy zw1 from transfer into staging - we need it for the ckeckOut at the end in batch file
          tools.CopyFile(sourceFileName, targetFileName);    
        } else {
          if (tools.StartEPLAN("updateHeader", DesignContents) == 16) throw new EDACancelException("PostReviseCall: " +  registry.getString("eplan.state.unusable")); 
          // clean up zw1.xml
          tools.FileDelete(tools.Properties.get("EDA2EPLAN_TRANSFER_DIR")  + "\\" + ProjectName + ".zw1.xml"); 
        }
      }
    } finally {
      s_logger.info("Finished PostReviseCall");
    }   
  }  

  //
  // preSaveAs - pre action
  //   just forwards to PrePreSaveImpl without using the UID
  //
  public void PrePreSaveAsCall(String applicationName, String edaDesignFileName) throws IOException, EDAException, InterruptedException, SAXException, ParserConfigurationException
  {
    PrePreSaveImpl(applicationName, edaDesignFileName, false);
  }  
  
  //
  // PreSaveAs - post action
  // checks the status of the preSaveAs call
  // and transforms the eda_design.xml to contain new values (why do _we_ have to do this?)
  // 
  public void PostPreSaveAsCall(String applicationName, String edaDesignFileName, String statusFileName) throws IOException, EDACancelException, EDAException, Exception, InterruptedException  {
    s_logger.info("Start PostPreSaveAsCall:" + "\napp: " + applicationName + "\nstatus: " + statusFileName + "\ndesign: " + edaDesignFileName);
    tools.initDynamicProperties();
  
    try {
      
      if (edaDesignFileName == null) throw new EDACancelException("PostPreSaveAsCall: " + registry.getString("eda.design.file.null"));
      if (statusFileName == null)    throw new EDACancelException("PostPreSaveAsCall: " + registry.getString("eda.status.file.null"));
          
      Map<String, String> statusContent;

      // list of data to be read from status file
      String[] PreSaveAsStatusData={"status", "message", "itemName", "itemId", "BOMOption", "designFolder", "checkIn"};
      
      statusContent = tools.GetStatusInfo(statusFileName, "EDAPreSaveAsStatus", PreSaveAsStatusData, "UTF-8");
      
      // preSaving failed
      if (checkStatus(statusContent)) return;    
    
      // get the project id of eplan - EPLAN_PROJECT_ID
      if (tools.Properties.get("EPLAN_PROJECT_ID") == null)    throw new EDACancelException(registry.getString("missing.EPLAN_PROJECT_ID"));
      if (tools.Properties.get("EPLAN_PROJECT_ID").equals("")) throw new EDACancelException(registry.getString("missing.EPLAN_PROJECT_ID"));
      
      String targetProjectName = null;
      if (tools.Properties.get("INCL_NAME").equals("ON"))
      {
        targetProjectName = statusContent.get("ITEMID") + tools.Properties.get("DELIMITER") + statusContent.get("ITEMNAME");
      } else {
        targetProjectName = statusContent.get("ITEMID");
      }

      s_logger.trace("Start XSLT transform " + edaDesignFileName);
      
      String targetDirName = null;
      targetDirName = EDAConfiguration.getInstance().getStagingDirName() + "\\latest\\" + statusContent.get("ITEMID");
      // cleanup if exists, create if doesnt (cleanup unconditionally here!)
      tools.CheckDirectory(targetDirName, true);

      String processedEdaDesignFileName = edaDesignFileName + ".processed";
      String[] args = new String[] {
        "-PARAM", "statusfile", statusFileName,
        "-PARAM", "designname", targetProjectName,
        "-PARAM", "datasetsrc", targetDirName,
        "-PARAM", "ccaname", statusContent.get("ITEMNAME"),
        // invert the EDA checkIn flag of the preSaveAs action to the checkout flag for preSave 
        "-PARAM", "checkedout", (statusContent.get("CHECKIN").equals("true") ? "false" : "true"),
        "-XSL", "scripts\\edadesignsaveas.xsl",  
        "-IN", edaDesignFileName, 
        "-OUT", processedEdaDesignFileName };
      s_logger.trace("XSLT parameters: " + Arrays.toString(args) + ".");
        
      com.sun.org.apache.xalan.internal.xslt.Process._main(args); 
      s_logger.trace("End XSLT transform " + edaDesignFileName);
      
    } finally {
      s_logger.info("Finish PostPreSaveAsCall");
    }    
  }

  // Checkin and Save - pre action
  // 
  //
  public void PreSaveAsCall(String applicationName, String edaDesignFileName) throws IOException, EDACancelException, EDAException, Exception, InterruptedException
  {
    s_logger.info("PreSaveAsCall:" + "\napp: " + applicationName + "\ndesign: " + edaDesignFileName); 
    tools.initDynamicProperties();

    try {
      if (edaDesignFileName == null) throw new EDACancelException("PreSaveAsCall: " + registry.getString("eda.design.file.null"));
        
      Map<String, String> designContents;
      designContents = tools.ReadDesignXML(edaDesignFileName, "UTF-8");  
        
      String targetProjectName = null;
      if (tools.Properties.get("INCL_NAME").equals("ON"))
      {
      	targetProjectName = designContents.get("ITEMID") + tools.Properties.get("DELIMITER") + designContents.get("ITEMNAME");
      } else {
      	targetProjectName = designContents.get("ITEMID");
      }

      // cleanup if exists, create if doesnt
      String targetDirName = new File(designContents.get("DATASET_SRC")).toString();
      //String targetDirName = EDAConfiguration.getInstance().getStagingDirName() + "\\latest\\" + ProjectName;
      s_logger.info("targetDirName " + targetDirName);

      String action = "save"; // default
      // we cannot do the insert here, as EDA calls the derivedData callbacks afterwards,
      // and EPIS does not allow creating derived data from a removed (i.e. closed) project.
//      if (designContents.get("UID") == null || designContents.get("UID").isEmpty()) {
//      	// special handling for Product Backlog Item 119078:TCC: Delete Template after SaveAsNew
//      	action = "insert";
//      }
      if (tools.StartEPLAN(action, designContents) == 0) throw new EDACancelException("EPLAN " + action + " " + registry.getString("eplan.cancel"));
      // copy zw1
      String targetFileName = targetDirName + "\\" + targetProjectName + ".zw1";
      String sourceFileName = tools.Properties.get("EPLAN2EDA_TRANSFER_DIR")  + "\\" +  tools.Properties.get("EPLAN_PROJECT_ID") + ".zw1";
      tools.MoveFile(sourceFileName, targetFileName);

      // delete the zw1.xml file
      new File(sourceFileName + ".xml").delete();
      
    } finally {
      s_logger.info("Finished PreSaveAsCall");
    }
    
  }

  //
  // SaveAs - post action
  // checks the status of the SaveAs call
  // read the return data from eda status file
  // creates zw1.xml file with meta data and adds an extra attribute for storing the UID
  // opens the project in the EPLAN
  //
  public void PostSaveAsCall(String applicationName, String edaDesignFileName, String statusFileName) throws IOException, EDACancelException, Exception, InterruptedException
  {
    s_logger.info("PostSaveAsCall app: " + applicationName + " status: " + statusFileName + " design: " + edaDesignFileName);
    tools.initDynamicProperties();

    if (edaDesignFileName == null) throw new EDACancelException("PostSaveAsCall: " + registry.getString("eda.design.file.null"));
    if (statusFileName == null)    throw new EDACancelException("PostSaveAsCall: " + registry.getString("eda.status.file.null"));    
    
    try {    	
      String[] saveAsStatusData={"status", "message", "checkIn", "UID"};
      Map<String, String> StatusContent;
      Map<String, String> designContents;
      
      StatusContent = tools.GetStatusInfo(statusFileName, "EDASaveAsStatus", saveAsStatusData, "UTF-8");
	  s_logger.info("PostSaveAsCall: " + StatusContent.get("STATUS"));  
      
      // preSaving failed
      if (checkStatus(StatusContent)) return;    
      
      // open the tc object as a project in eplan
      // read the design xml file
	  designContents = tools.ReadDesignXML(edaDesignFileName, "UTF-8");  
      
      if (tools.Properties.get("EPLAN_PROJECT_ID") == null)    throw new EDACancelException(registry.getString("missing.EPLAN_PROJECT_ID"));
      if (tools.Properties.get("EPLAN_PROJECT_ID").equals("")) throw new EDACancelException(registry.getString("missing.EPLAN_PROJECT_ID"));

      // execute only if project wont be checked in
      if (StatusContent.get("CHECKIN").equals("false")) {
        designContents.put("UID", StatusContent.get("UID"));

        String ProjectName;
        if (tools.Properties.get("INCL_NAME").equals("ON"))
        {
          ProjectName = designContents.get("ITEMID") + tools.Properties.get("DELIMITER") + designContents.get("ITEMNAME");
        }
        else
        {
          ProjectName = designContents.get("ITEMID");
        }
        designContents.put("PROJECT_NAME", ProjectName);

        // move zw1 from staging to transfer dir 
        String sourceDirName = new File(designContents.get("DATASET_SRC")).toString();
        s_logger.info("sourceDirName " + sourceDirName);
      
        String sourceFileName = sourceDirName + "\\" + ProjectName + ".zw1";
        String targetFileName = tools.Properties.get("EDA2EPLAN_TRANSFER_DIR")  + "\\" + ProjectName + ".zw1"; 
      
        // copy zw1 from transfer into staging
        tools.MoveFile(sourceFileName, targetFileName);    
      
        // prepare the attributes from desig for zw1.xml
        designContents.put("ATTRIBUTES", tools.PrepareXMLZw1Attributes(designContents));
      
        // for the UID transfer
        designContents.put("EPLAN_UID_ATTR", tools.Properties.get("EPLAN_UID_ATTR"));

        designContents.put("READONLY", "0"); 
      
        File XMLTemplate = tools.CheckTemplate(tools.Properties.get("ZW1_XML_TEMPLATE"));
        tools.CreateXMLFromTemplate(XMLTemplate, designContents, tools.Properties.get("EDA2EPLAN_TRANSFER_DIR")  + "\\" + ProjectName + ".zw1.xml", "UTF-16", true);      
          
	    // start eplan - open project
	    if (tools.StartEPLAN("open", designContents) == 16) throw new EDACancelException("PostSaveAsCall: " +  registry.getString("eplan.state.unusable")); 
      
        // clean up zw1.xml
        tools.FileDelete(tools.Properties.get("EDA2EPLAN_TRANSFER_DIR")  + "\\" + ProjectName + ".zw1.xml");
      }
    } finally {
      s_logger.info("Finished PostSaveAsCall");
    }   
  }  
  
  //
  //
  //  OPEN...
  //
  //  
  
  //
  // Open - post action
  // checks the status of the open call
  // read eda design file for TC data
  // check if item rev is the latest (none latest can be open readonly! and have the <_rev> as prefix in the project name)
  // create the zw1.xml with the meta data for EPLAN project, add the attribute for UID storage
  //   for the action is open store the UID of the project
  //   for the action open template set the UID to ""
  //  copy zw1 from staging to EPLAN directory
  //  open the project im EPLAN
  //   for open template the project will be always open with write access
  //
  public void PostOpenCall(String applicationName, String edaDesignFileName, String statusFileName) throws IOException, EDACancelException, Exception, InterruptedException
  {
    s_logger.info("Start PostOpenCall:" + "\napp: " + applicationName + "\nstatus: " + statusFileName + "\ndesign: " + edaDesignFileName);
    tools.initDynamicProperties();

    if (edaDesignFileName == null) throw new EDACancelException("PostOpenCall: " + registry.getString("eda.design.file.null"));
    if (statusFileName == null)    throw new EDACancelException("PostOpenCall: " + registry.getString("eda.status.file.null"));      
    
    try {   
      // check if the callback shall be run through  
      String[] PostOpenStatusData={"status", "message"};
      Map<String, String> DesignContents;
      Map<String, String> StatusContent;     
      
      StatusContent = tools.GetStatusInfo(statusFileName, "EDAOpenDataSetStatus", PostOpenStatusData, "UTF-8");      
      
      // opening failed
      if (checkStatus(StatusContent)) return;    

      // its check if called for open or open template
      if (tools.Properties.get("ACTION") == null)    tools.Properties.put("ACTION", "OPEN"); 
      else if (tools.Properties.get("ACTION").equals("")) tools.Properties.put("ACTION", "OPEN");
      
      // read the design xml file
      DesignContents = tools.ReadDesignXML(edaDesignFileName, "UTF-8"); 
      
      // check if the required data has been read
      if (!DesignContents.containsKey("HEAD_ID"))     throw new EDACancelException("PostOpenCall: " + registry.getString("edadesign.missing.itemid "));
      if (!DesignContents.containsKey("DATASET_SRC")) throw new EDACancelException("PostOpenCall: " + registry.getString("edadesign.missing.stagingDir"));
      if (!DesignContents.containsKey("DATASET_UID")) throw new EDACancelException("PostOpenCall: " + registry.getString("edadesign.missing.uid"));  
      
      // check if latest revision yes Revision = "" no Revision = _<ItemRev>
      String Revision = tools.CheckIfLatestRevision(DesignContents.get("DATASET_SRC"), DesignContents.get("HEAD_REV"), tools.Properties.get("NONLATEST"));
      s_logger.info("Revision: " + Revision);

      // for nonlatest revision open only without write access
      if (!Revision.equals("")) DesignContents.put("READONLY", "1");
        
      DesignContents.put("ATTRIBUTES", tools.PrepareXMLZw1Attributes(DesignContents));
      DesignContents.put("EPLAN_UID_ATTR", tools.Properties.get("EPLAN_UID_ATTR"));
      
      // for open we need to store the UID, for open_template we must not store the UID! 
      if (tools.Properties.get("ACTION").equals("OPEN"))
      {          
        // prepare the attributes from desig for zw1.xml
        DesignContents.put("UID", DesignContents.get("DATASET_UID"));       
      }
      else
      {
        // no UID mapping and always open with write access
        DesignContents.put("UID", "");
        DesignContents.put("READONLY", "0");
      }
      
      String ProjectName;
      if (tools.Properties.get("INCL_NAME").equals("ON"))
      {
        ProjectName = DesignContents.get("ITEMID") + Revision + tools.Properties.get("DELIMITER") + DesignContents.get("HEAD_NAME");
      }
      else
      {
        ProjectName = DesignContents.get("HEAD_ID") + Revision;
      }
      
      // for open we use the project name, for open_template use the project name with a prefix to see its a template 
      String targetFileName;
      if (tools.Properties.get("ACTION").equals("OPEN"))
      {          
        DesignContents.put("PROJECT_NAME", ProjectName);  
        targetFileName = tools.Properties.get("EDA2EPLAN_TRANSFER_DIR")  + "\\" + ProjectName + ".zw1"; 
      }
      else
      {
    	s_logger.info("PostOpenCall open as template -> add prefix: " +tools.Properties.get("EPLAN_PREFIX4TEMPLATE") + " to the project name");
    	DesignContents.put("PROJECT_NAME", tools.Properties.get("EPLAN_PREFIX4TEMPLATE") + ProjectName); 
    	targetFileName = tools.Properties.get("EDA2EPLAN_TRANSFER_DIR")  + "\\" + tools.Properties.get("EPLAN_PREFIX4TEMPLATE") + ProjectName + ".zw1"; 
      }      
        
        
      // the dataset checked in name doesnt include revision, so find the name of zw1
      String sourceFileName = DesignContents.get("DATASET_SRC")  + "\\" +  tools.FindFileName(DesignContents.get("DATASET_SRC"), "zw1") + ".zw1";
      
      // copy zw1 from transfer into staging
      tools.CopyFile(sourceFileName, targetFileName);

      File XMLTemplate = tools.CheckTemplate(tools.Properties.get("ZW1_XML_TEMPLATE"));
      tools.CreateXMLFromTemplate(XMLTemplate, DesignContents, targetFileName + ".xml", "UTF-16", true); 
      
      // start eplan - open project
      tools.StartEPLAN("open", DesignContents);        
    } finally {
      s_logger.info("Finish PostOpenCall");
    }    
  }
  
  //
  // postGetItemInfo - action
  // used actually for bom compare and start workflow - skipped for real getiteminfo 
  //
 
  public void PostGetItemInfoCall(String applicationName, String edaDesignFileName, String statusFileName, String UID) throws IOException, EDAException, InterruptedException, SAXException, ParserConfigurationException 
  {
	    s_logger.info("PostGetItemInfoCall:" + "\napp: " + applicationName + "\ndesign: " + edaDesignFileName); 
	    tools.initDynamicProperties();
	    
	    // get the  POST_INFO_ACTION
	    if (tools.Properties.get("ACTION") == null)
	    {
	      s_logger.info("PostGetItemInfoCall: no env var ACTION -> skip PostGetItemInfoCall"); 
	      return; 
	    }
	    if (!tools.Properties.get("ACTION").equals("BOM_XML"))
	    {
	      s_logger.info("PostGetItemInfoCall: ACTION!=BOM_XML -> skip PostGetItemInfoCall"); 
	      return; 
	    }

	    s_logger.info("PostGetItemInfoCall: ACTION=" + tools.Properties.get("ACTION")); 
	    
	    try {     
	      if (edaDesignFileName == null) throw new EDACancelException("PostGetItemInfoCall: " + registry.getString("eda.design.file.null"));
	        
	      // get the project id of eplan - EPLAN_PROJECT_ID
	      if (tools.Properties.get("EPLAN_PROJECT_ID") == null)    throw new EDACancelException(registry.getString("missing.EPLAN_PROJECT_ID"));
	      if (tools.Properties.get("EPLAN_PROJECT_ID").equals("")) throw new EDACancelException(registry.getString("missing.EPLAN_PROJECT_ID"));

	      // get the project id of eplan - EPLAN_PROJECT_FILE
	      if (tools.Properties.get("EPLAN_PROJECT_FILE") == null)    throw new EDACancelException(registry.getString("missing.EPLAN_PROJECT_FILE"));
	      if (tools.Properties.get("EPLAN_PROJECT_FILE").equals("")) throw new EDACancelException(registry.getString("missing.EPLAN_PROJECT_FILE"));
	        
	      
	      String BomXMLFileName = null;
	      Map<String, String> DesignContents;
	      Map<String, String> BOMContent = new HashMap<String, String> ();
	        
	      int BOMExported = 0;
	        
	      DesignContents = tools.ReadDesignXML(edaDesignFileName, "UTF-8");  
	        
	      // export bom - before save or checkin - as checkin closes the project and data cant be exported afterwards
	      // delete in the bom transfer dir all files starting with projectId
	      tools.CleanUpDir(tools.Properties.get("EPLAN2EDA_BOM_DIR"), tools.Properties.get("EPLAN_PROJECT_ID"));
	      
	      int bomSelection = 0;
	      if (tools.Properties.get("BOMSELECTION") != null) {
	        bomSelection = Integer.valueOf(tools.Properties.get("BOMSELECTION")).intValue();
	      }	   
	      s_logger.info("PostGetItemInfoCall: bomSelection = " + tools.Properties.get("BOMSELECTION")); 

	    
	      BOMExported = tools.StartEPLAN("bomExport", DesignContents);
	      if (BOMExported == 1) 
	      {
	        BomXMLFileName = tools.FindBOMXML(tools.Properties.get("EPLAN2EDA_BOM_DIR"), tools.Properties.get("EPLAN_PROJECT_ID"));
	        if (BomXMLFileName == null) 
	        {
	          EPLANToolbox.ShowInfo(registry.getString("dialog.info"), registry.getString("dialog.noBOM"));
	          throw new EDACancelException(registry.getString("dialog.noBOM"));
	        }            
	      }
	      
	      
	      String ProjectName;
	      if (tools.Properties.get("INCL_NAME").equals("ON"))
	      {
	        // split to get the item id
	        String[] OrgItemIdName;
	        OrgItemIdName = tools.Properties.get("EPLAN_PROJECT_ID").split(tools.Properties.get("DELIMITER"), 2);      
	        ProjectName = OrgItemIdName[0];
	      }
	      else
	      {
	        ProjectName = tools.Properties.get("EPLAN_PROJECT_ID");
	      }

	      // cleanup if exists, create if doesnt
	      String targetDirName = EDAConfiguration.getInstance().getStagingDirName() + "\\latest\\" + ProjectName;
	      s_logger.info("targetDirName " + targetDirName);
	      tools.CheckDirectory(targetDirName, true);
	        
	      String sourceFileName = tools.Properties.get("EPLAN2EDA_TRANSFER_DIR")  + "\\" +  tools.Properties.get("EPLAN_PROJECT_ID") + ".zw1";
	      final String zw1xmlFilename = sourceFileName + ".xml";
		  if ( new File(zw1xmlFilename).exists()) {
		  	// make sure we see the new content by deleting the old file before the extraction
		  	new File(zw1xmlFilename).delete();
		  }
	      
		  if (tools.StartEPLAN("metadata", DesignContents) == 0) throw new EDACancelException("EPLAN metadata" + registry.getString("eplan.cancel"));
		      
	      // read the attributes from zw1.xml - get it into xml string for design file
		  String Attributes = tools.ParseZW1XML(zw1xmlFilename, "UTF-16", ""); 
	      new File(zw1xmlFilename).delete();
	    	
	      // create the design.xml file using XSLT.
	      s_logger.trace("Start XSLT main BoM");
	      String processedBomFileName = BomXMLFileName + ".processed";
	      String[] args = new String[] {
	        "-PARAM", "UID", UID,
	        "-PARAM", "BoMSelection", String.valueOf(bomSelection),
	        "-XSL", "scripts\\eplanbomtoedabom.xsl",  
	        "-IN", BomXMLFileName, 
	        "-OUT", processedBomFileName };
	      s_logger.trace("XSLT parameters: " + Arrays.toString(args) + ".");
	        
	      com.sun.org.apache.xalan.internal.xslt.Process._main(args); 
	      s_logger.trace("End XSLT main BoM");


	      BOMContent.put("HASBOM", "true"); 
	      BOMContent.put("ATTRIBUTES", Attributes);
	      BOMContent.put("VERSION", DesignContents.get("DATASET_VER"));
	      BOMContent.put("EDA_STAGING_DIR_COMPLETE", tools.xmlEscapeText(targetDirName));
	      BOMContent.put("ZW1NAME", tools.Properties.get("EPLAN_PROJECT_ID"));
	      tools.CreateBOMDesign(processedBomFileName, BOMContent, edaDesignFileName, "");
	    } catch (Exception e) {
	        s_logger.error( "PostGetItemInfoCall Exception cought: " + e.getMessage());
	        throw new EDACancelException("PostGetItemInfoCall Exception: " + e.getMessage());    
	 
        } finally {
	      s_logger.info("Finished PostGetItemInfoCall");
	    }
	    
  }  

  //
  //
  //  SAVE... / CHECKIN...
  //
  // 
  
  //
  // PreSave - pre action
  // check if project has the write access
  //
  public void PrePreSaveCall(String applicationName, String edaDesignFileName) throws IOException, EDAException, InterruptedException, SAXException, ParserConfigurationException 
  {
    PrePreSaveImpl(applicationName, edaDesignFileName, true);
  }
  //
  // PreSave - pre action implementation function
  // check if project has the write access
  // the additional 3rd parameter indicates whether UID should be written or not.
  //
  public void PrePreSaveImpl(String applicationName, String edaDesignFileName, boolean useUID) throws IOException, EDAException, InterruptedException, SAXException, ParserConfigurationException 
  {
    s_logger.info("PrePreSaveImpl:" + "\napp: " + applicationName + "\ndesign: " + edaDesignFileName); 
    tools.initDynamicProperties();

    try {
      int bomSelection = 0;
      if (tools.Properties.get("BOMSELECTION") != null) {
        bomSelection = Integer.valueOf(tools.Properties.get("BOMSELECTION")).intValue();
      }
      
      // check if the project is checked out otherwise eplan cant write the zw1
      tools.IsCheckedOutCheckCall(); 

      if (edaDesignFileName == null) throw new EDACancelException("PrePreSaveImpl: " + registry.getString("eda.design.file.null"));
        
      // get the project id of eplan - EPLAN_PROJECT_ID
      if (tools.Properties.get("EPLAN_PROJECT_ID") == null)    throw new EDACancelException(registry.getString("missing.EPLAN_PROJECT_ID"));
      if (tools.Properties.get("EPLAN_PROJECT_ID").equals("")) throw new EDACancelException(registry.getString("missing.EPLAN_PROJECT_ID"));

      // get the project id of eplan - EPLAN_PROJECT_FILE
      if (tools.Properties.get("EPLAN_PROJECT_FILE") == null)    throw new EDACancelException(registry.getString("missing.EPLAN_PROJECT_FILE"));
      if (tools.Properties.get("EPLAN_PROJECT_FILE").equals("")) throw new EDACancelException(registry.getString("missing.EPLAN_PROJECT_FILE"));
        
      String BomXMLFileName = null;
      Map<String, String> DesignContents;
      Map<String, String> BOMContent = new HashMap<String, String> ();
        
      int BOMExported = 0;
        
      DesignContents = tools.ReadDesignXML(edaDesignFileName, "UTF-8");  
        
      // export bom - before save or checkin - as checkin closes the project and data cant be exported afterwards
      // delete in the bom transfer dir all files starting with projectId
      tools.CleanUpDir(tools.Properties.get("EPLAN2EDA_BOM_DIR"), tools.Properties.get("EPLAN_PROJECT_ID"));
      if (bomSelection > 1) {
        BOMExported = tools.StartEPLAN("bomExport", DesignContents);
        if (BOMExported == 1) 
        {
          BomXMLFileName = tools.FindBOMXML(tools.Properties.get("EPLAN2EDA_BOM_DIR"), tools.Properties.get("EPLAN_PROJECT_ID"));
          if (BomXMLFileName == null) 
          {
            EPLANToolbox.ShowInfo(registry.getString("dialog.info"), registry.getString("dialog.noBOM"));
            BOMExported = 0;
          }            
        }
      }
      
      String ProjectName;
      if (tools.Properties.get("INCL_NAME").equals("ON"))
      {
        // split to get the item id
        String[] OrgItemIdName;
        OrgItemIdName = tools.Properties.get("EPLAN_PROJECT_ID").split(tools.Properties.get("DELIMITER"), 2);      
        ProjectName = OrgItemIdName[0];
      }
      else
      {
        ProjectName = tools.Properties.get("EPLAN_PROJECT_ID");
      }

      // cleanup if exists, create if doesnt
      String targetDirName = EDAConfiguration.getInstance().getStagingDirName() + "\\latest\\" + ProjectName;
      s_logger.info("targetDirName " + targetDirName);
      tools.CheckDirectory(targetDirName, true);
        
      String sourceFileName = tools.Properties.get("EPLAN2EDA_TRANSFER_DIR")  + "\\" +  tools.Properties.get("EPLAN_PROJECT_ID") + ".zw1";
      final String zw1xmlFilename = sourceFileName + ".xml";
	    if ( new File(zw1xmlFilename).exists()) {
	    	// make sure we see the new content by deleting the old file before the extraction
	    	new File(zw1xmlFilename).delete();
	    }
      
	    if (tools.StartEPLAN("metadata", DesignContents) == 0) throw new EDACancelException("EPLAN metadata" + registry.getString("eplan.cancel"));
	
      String targetFileName = targetDirName + "\\" + tools.Properties.get("EPLAN_PROJECT_ID") + ".zw1";
	    // the real file gets created in Checkin, so we create a dummy here only!
	    File dummyFile = new File(targetFileName); 
	    if ( ! dummyFile.exists()) {
	    	dummyFile.createNewFile();
	    }
      
      // read the attributes from zw1.xml - get it into xml string for design file
		String Attributes = tools.ParseZW1XML(zw1xmlFilename, "UTF-16", ""); 
    	new File(zw1xmlFilename).delete();
    	
      // create the design.xml file using XSLT.
      // if no BoM file is present, create an empty "dummy" file.
      if (BOMExported == 0) {
        BomXMLFileName = tools.Properties.get("EPLAN2EDA_BOM_DIR") + "\\" + tools.Properties.get("EPLAN_PROJECT_ID") + ".xml";
        PrintWriter writer = new PrintWriter(BomXMLFileName, "UTF-16");
        writer.println("<Bom/>");
        writer.close();
      }
      s_logger.trace("Start XSLT main BoM");
      String processedBomFileName = BomXMLFileName + ".processed";
      String[] args = new String[] {
        "-PARAM", "UID", useUID ? DesignContents.get("DATASET_UID") : "",
        "-PARAM", "BoMSelection", String.valueOf(bomSelection),
        "-XSL", "scripts\\eplanbomtoedabom.xsl",  
        "-IN", BomXMLFileName, 
        "-OUT", processedBomFileName };
      s_logger.trace("XSLT parameters: " + Arrays.toString(args) + ".");
        
      com.sun.org.apache.xalan.internal.xslt.Process._main(args); 
      s_logger.trace("End XSLT main BoM");

      if (bomSelection > 1) {
        BOMContent.put("HASBOM", "true"); 
      } else {
        BOMContent.put("HASBOM", "false"); 
      }

      BOMContent.put("ATTRIBUTES", Attributes);
      //BOMContent.put("UID", DesignContents.get("DATASET_UID"));
      BOMContent.put("VERSION", DesignContents.get("DATASET_VER"));
      BOMContent.put("EDA_STAGING_DIR_COMPLETE", tools.xmlEscapeText(targetDirName));
      BOMContent.put("ZW1NAME", tools.Properties.get("EPLAN_PROJECT_ID"));
      tools.CreateBOMDesign(processedBomFileName, BOMContent, edaDesignFileName, "");

    } finally {
      s_logger.info("Finished PrePreSaveImpl");
    }
    
  }
  
  // Checkin and Save - pre action
  // 
  //
  public void PreSaveCall(String applicationName, String edaDesignFileName) throws IOException, EDACancelException, EDAException, Exception, InterruptedException
  {
    s_logger.info("PreSaveCall:" + "\napp: " + applicationName + "\ndesign: " + edaDesignFileName); 
    tools.initDynamicProperties();

    try {
      if (edaDesignFileName == null) throw new EDACancelException("PreSaveCall: " + registry.getString("eda.design.file.null"));
        
      // get the project id of eplan - EPLAN_PROJECT_ID
      if (tools.Properties.get("EPLAN_PROJECT_ID") == null)    throw new EDACancelException(registry.getString("missing.EPLAN_PROJECT_ID"));
      if (tools.Properties.get("EPLAN_PROJECT_ID").equals("")) throw new EDACancelException(registry.getString("missing.EPLAN_PROJECT_ID"));

      // get the project id of eplan - EPLAN_PROJECT_FILE
      if (tools.Properties.get("EPLAN_PROJECT_FILE") == null)    throw new EDACancelException(registry.getString("missing.EPLAN_PROJECT_FILE"));
      if (tools.Properties.get("EPLAN_PROJECT_FILE").equals("")) throw new EDACancelException(registry.getString("missing.EPLAN_PROJECT_FILE"));
        
      Map<String, String> designContents;
      designContents = tools.ReadDesignXML(edaDesignFileName, "UTF-8");  
        
      // cleanup if exists, create if doesnt
      String targetDirName = new File(designContents.get("DATASET_SRC")).toString();
      //String targetDirName = EDAConfiguration.getInstance().getStagingDirName() + "\\latest\\" + ProjectName;
      s_logger.info("targetDirName " + targetDirName);
      
      // use "Save_Project_TP" here in all cases, for checkin we'll later do another EPIS checkin if necessary
      if (tools.StartEPLAN("save", designContents) == 0) throw new EDACancelException("EPLAN Save_Project_TP" + registry.getString("eplan.cancel"));
      // copy zw1
      String targetFileName = targetDirName + "\\" + tools.Properties.get("EPLAN_PROJECT_ID") + ".zw1";
      String sourceFileName = tools.Properties.get("EPLAN2EDA_TRANSFER_DIR")  + "\\" +  tools.Properties.get("EPLAN_PROJECT_ID") + ".zw1";
      tools.MoveFile(sourceFileName, targetFileName);

      // delete the zw1.xml file
      new File(sourceFileName + ".xml").delete();
      
    } finally {
      s_logger.info("Finished PreSaveCall");
    }
    
  }

  
  /**
   * checkStatus checks the StatusContent 
   * @param StatusContent
   * @throws IOException
   * @throws EDAException if StatusContent shows an error
   * @return true if StatusContent show that the action was canceled
   */
  private boolean checkStatus(Map<String, String> StatusContent)
      throws IOException, EDAException {
    if (StatusContent.get("STATUS").equals("Cancel")) 
    { 
      s_logger.error( "EDA call canceled.");     
      return true;
    }
    else if (StatusContent.get("STATUS").equals("Success") == false) 
    {
//      if(StatusContent.get("MESSAGE") == null || StatusContent.get("MESSAGE").isEmpty()) {
//        return true;
//      }
      String message = registry.getString("eda.fail") + " " + StatusContent.get("STATUS") + ": " + StatusContent.get("MESSAGE"); 
      s_logger.error( message);     
      throw new EDAException(message);
    }
    return false;
  }   
  

  //
  //
  //  REFRESH...
  //
  // 
 
  //
  // refresh -pre action
  // checks if the EPLAN project is in readOnly mode
  // 
  public void PreRefreshCall(String applicationName, String designFileName, String UID) throws IOException, EDACancelException, ParserConfigurationException, SAXException
  {
    s_logger.info("PreRefreshCall:" + "\napp: " + applicationName + "\nstatus: " + designFileName  + "\nUID: " + UID);
    tools.initDynamicProperties();

    try {
      // call only for ro=1 projects - otherwise no sense to refresh project u work on    
      tools.IsCheckedInCheckCall();
    } finally {
      s_logger.info("Finished PreRefreshCall");
    } 
  } 
  
  //
  // refresh -post action
  // reads the status file to check the call status and check if a new zw1 has been downloaded from TC
  //   the dataset will be refreshed only if another iser has checked in a new version in the mean time
  // in case the zw1 has been renewed:
  //   copy the zw1 from staging to EPLAN directory
  //   create the zw1.xml with updated meta data
  //   reopen the project in EPLAN in readOnly mode
  //  
  public void PostRefreshCall(String applicationName, String edaDesignFileName, String statusFileName, String UID) throws IOException, EDAException, Exception, InterruptedException
  {
    s_logger.info("Start PostRefreshCall:" + "\napp: " + applicationName + "\nstatus: " + statusFileName + "\ndesign: " + edaDesignFileName + "\nUID: " + UID);
    tools.initDynamicProperties();

    if (edaDesignFileName == null) throw new EDACancelException("PostRefreshCall: " + registry.getString("eda.design.file.null"));
    if (statusFileName == null)    throw new EDACancelException("PostRefreshCall: " + registry.getString("eda.status.file.null")); 
    
    // get the project id of eplan - EPLAN_PROJECT_ID
    if (tools.Properties.get("EPLAN_PROJECT_ID") == null)    throw new EDACancelException(registry.getString("missing.EPLAN_PROJECT_ID"));
    if (tools.Properties.get("EPLAN_PROJECT_ID").equals("")) throw new EDACancelException(registry.getString("missing.EPLAN_PROJECT_ID"));
    
    try {  
      // check if the callback shall be run through
      String[] RefreshStatusData={"status", "message", "refreshed"};
      
      Map<String, String> StatusContent;
      Map<String, String> DesignContents;
      
      StatusContent = tools.GetStatusInfo(statusFileName, "EDARefreshStatus", RefreshStatusData, "UTF-8");
      // checkout failed
      if (checkStatus(StatusContent)) return;    
        
        
      if (StatusContent.get("REFRESHED").equals("true"))
      {
        DesignContents = tools.ReadDesignXML(edaDesignFileName, "UTF-8"); 
        
        String ProjectName;
        if (tools.Properties.get("INCL_NAME").equals("ON"))
        {
          ProjectName = DesignContents.get("ITEMID") + tools.Properties.get("DELIMITER") + DesignContents.get("HEAD_NAME");
        }        
        else
        {
          ProjectName = DesignContents.get("ITEMID");
        }
        DesignContents.put("PROJECT_NAME", ProjectName);
        
        String sourceFileName = DesignContents.get("DATASET_SRC") + "\\" + ProjectName + ".zw1";
        String targetFileName = tools.Properties.get("EDA2EPLAN_TRANSFER_DIR")  + "\\" + ProjectName + ".zw1";  
        // check if any zw1 file exists in the dataset source directory - if yes and the name isnt = head_id -> rename it      
        String zw1FileName = tools.FindFileName(DesignContents.get("DATASET_SRC"), "zw1");
        if (!zw1FileName.equals(ProjectName)) 
        {
          String orgFileName = DesignContents.get("DATASET_SRC") + "\\" + zw1FileName + ".zw1";
          File orgZW1File = new File(orgFileName);
          if (!orgZW1File.renameTo(new File(sourceFileName)))
          {
            throw new EDACancelException("PostRefreshCall: " + registry.getString("cantRename") + " " + orgFileName + " -> " + sourceFileName);
          }        
        } 
        
        File checkSourceFile = new File(sourceFileName);
        if (!checkSourceFile.exists())
        {
          throw new EDACancelException(registry.getString("eda.design.missing") + ":" + sourceFileName + " " + registry.getString("reopen"));
        }      
        
        // copy zw1 from staging to eda2eplan
        tools.CopyFile(sourceFileName, targetFileName);
        
        // prepare the attributes from design for zw1.xml
        DesignContents.put("ATTRIBUTES", tools.PrepareXMLZw1Attributes(DesignContents));
        
        // for the UID mapping
        DesignContents.put("UID", UID); 
        DesignContents.put("EPLAN_UID_ATTR", tools.Properties.get("EPLAN_UID_ATTR"));
        
        // create the zw1.xml 
        File XMLTemplate = tools.CheckTemplate(tools.Properties.get("ZW1_XML_TEMPLATE"));
        tools.CreateXMLFromTemplate(XMLTemplate, DesignContents, targetFileName + ".xml", "UTF-16", true);           
        
        DesignContents.put("READONLY", "1");
        // get the eplan checkout script
        if (tools.StartEPLAN("open", DesignContents) != 1) throw new EDACancelException("PostRefreshCall: " + registry.getString("eplan.header.fail"));
        
        // cleanup
        tools.FileDelete(targetFileName + ".xml");
      }
    } finally {
      s_logger.info("Finished PostRefreshCall");
    }   
  }  
  
  //
  //  Create Derived Data
  //  read design file
  //
  //
  public void CreateDerivedData(String edaDesignFileName) throws IOException, InterruptedException, SAXException, ParserConfigurationException, EDAException {
    s_logger.info("CreateDerivedData: " + edaDesignFileName);
    tools.initDynamicProperties();

    //if (edaDesignFileName == null) throw new EDACancelException("CreateDerivedData: " + registry.getString("eda.design.file.null"));

    File edaDesignExtensionFile = tools.getDesignExtensionFile();
    if(edaDesignExtensionFile.lastModified() <= derivedDataLastCommandDate) {
      s_logger.info("CreateDerivedData skipped, already processed!");
    } else {

      Map<String, String> DesignContents = tools.ReadDesignXML(edaDesignFileName, "UTF-8");
      
      // get the project id of eplan - EPLAN_PROJECT_ID
      if (tools.Properties.get("EPLAN_PROJECT_ID") == null)    throw new EDACancelException(registry.getString("missing.EPLAN_PROJECT_ID"));
      if (tools.Properties.get("EPLAN_PROJECT_ID").equals("")) throw new EDACancelException(registry.getString("missing.EPLAN_PROJECT_ID"));

      String itemID = DesignContents.get("ITEMID");
      s_logger.info("CreateDerivedData: itemID from EDA design file: " + itemID);  
      if(itemID == null || itemID.isEmpty()) {
        // if itemID is not (yet) in the design file, retrieve it from the EPLAN_PROJECT_ID:
        tools.Properties.get("EPLAN_PROJECT_ID");
        s_logger.info("CreateDerivedData: EPLAN_PROJECT_ID " + itemID);  
        s_logger.info("CreateDerivedData: INCL_NAME is " + tools.Properties.get("INCL_NAME"));  
        if (tools.Properties.get("INCL_NAME").equals("ON"))
        {
          // split to get the item id
          String[] ItemIdOnly;
          ItemIdOnly = tools.Properties.get("EPLAN_PROJECT_ID").split(tools.Properties.get("DELIMITER"), 2);      
          s_logger.info("CreateDerivedData: ItemIdOnly " + ItemIdOnly);  
  
          itemID = ItemIdOnly[0];
        }
      }
      s_logger.info("CreateDerivedData: itemID " + itemID);  

      // check if the required data has been read
      if (!DesignContents.containsKey("DATASET_SRC")) throw new EDAException("CreateDerivedData: " + registry.getString("edadesign.missing.stagingDir"));
  
      DesignContents.put("EPLAN_PROJECT_ID", tools.Properties.get("EPLAN_PROJECT_ID"));
  
      String targetDirName = EDAConfiguration.getInstance().getStagingDirName() + "\\latest\\" + itemID;
      
      
      s_logger.info("targetDirName " + targetDirName);
      
      tools.CheckDirectory(targetDirName, false);
  
      String derivedDataCheck = tools.DerivedDataPreCheck(tools.Properties.get("EPLAN_PROJECT_ID"));
      if (!derivedDataCheck.equals("OK"))
      {
        throw new EDACancelException("CreateDerivedData: " + derivedDataCheck);
      }
      
      if (tools.StartEPLAN("docExport", DesignContents) != 1) throw new EDAException(registry.getString("eplan.derivedData.fail")); 
  
      // proceed the derived data
      tools.CleanUpDerivedDataTarget(targetDirName, itemID); 
      tools.ProceedDerivedData(targetDirName, tools.Properties.get("EPLAN_PROJECT_ID"), itemID);   
      tools.CleanUpDerivedDataSource(tools.Properties.get("EPLAN_PROJECT_ID"));
      derivedDataLastCommandDate = edaDesignExtensionFile.lastModified();
    }
    
    s_logger.info("Finished CreateDerivedData");
  }
  
  //
  // ###
  //
  public void PreSaveDerivedDataCall(String applicationName, String edaDesignFileName) throws IOException, EDAException, SAXException, ParserConfigurationException, InterruptedException
  {
    s_logger.info("PreSaveDerivedDataCall:" + "\napp: " + applicationName + "\ndesign: " + edaDesignFileName);
    tools.initDynamicProperties();
    
    try { 
      // get the project id of eplan - EPLAN_PROJECT_FILE
      if (tools.Properties.get("EPLAN_PROJECT_FILE") == null)    throw new EDACancelException(registry.getString("missing.EPLAN_PROJECT_FILE"));
      if (tools.Properties.get("EPLAN_PROJECT_FILE").equals("")) throw new EDACancelException(registry.getString("missing.EPLAN_PROJECT_FILE"));
    
      File elkFile = new File(tools.Properties.get("EPLAN_PROJECT_FILE"));
      if (!elkFile.exists())
      {
        s_logger.error( registry.getString("projectFile") + " " + tools.Properties.get("EPLAN_PROJECT_FILE") + " " + registry.getString("doesntExist"));
        throw new EDACancelException(registry.getString("projectFile") + " " + tools.Properties.get("EPLAN_PROJECT_FILE") + " " + registry.getString("doesntExist"));      
      }
      
      // check if the required data has been read
      Map<String, String> DesignContents = tools.ReadDesignXML(edaDesignFileName, "UTF-8");
      if (!DesignContents.containsKey("DATASET_SRC")) throw new EDAException("CreateDerivedData: " + registry.getString("edadesign.missing.stagingDir"));
  
      String targetDirName = EDAConfiguration.getInstance().getStagingDirName() + "\\latest\\" + DesignContents.get("ITEMID");
      
      s_logger.info("targetDirName " + targetDirName);
      
      String ProjectName;
      if (tools.Properties.get("INCL_NAME").equals("ON"))
      { 
        ProjectName = DesignContents.get("ITEMID") + tools.Properties.get("DELIMITER") + DesignContents.get("ITEMNAME");
      }
      else
      {
        ProjectName = DesignContents.get("ITEMID");
      }
      String sourceFileName = DesignContents.get("DATASET_SRC") + "\\" + ProjectName + ".zw1";
      
      // touch the zw1 file (create if not present, ignore if not present)
      // EDA checks the existence in order to execute the derived data callbacks.
      new File(sourceFileName).createNewFile();
      
   } catch (Exception e) {
      s_logger.error( "PreSaveDerivedDataCall Exception cought: " + e.getMessage());
      throw new EDACancelException("PreSaveDerivedDataCall Exception: " + e.getMessage());    
    }   
    //CreateDerivedData(edaDesignFileName);
  }    

  //
  // saveDerivedData -post action
  // only purpose: check status file and display error if necessary.
  //  
  public void PostSaveDerivedDataCall(String applicationName, String edaDesignFileName, String statusFileName) throws IOException, EDAException, Exception, InterruptedException
  {
    s_logger.info("Start PostSaveDerivedDataCall:" + "\napp: " + applicationName + "\nstatus: " + statusFileName + "\ndesign: " + edaDesignFileName );
    tools.initDynamicProperties();

    if (edaDesignFileName == null) throw new EDACancelException("PostSaveDerivedDataCall: " + registry.getString("eda.design.file.null"));
    if (statusFileName == null)    throw new EDACancelException("PostSaveDerivedDataCall: " + registry.getString("eda.status.file.null")); 
    
    try {  
      // check if the callback shall be run through
      String[] StatusData={"status", "message"};
      
      Map<String, String> StatusContent;
      
      StatusContent = tools.GetStatusInfo(statusFileName, "EDASaveDerivedDataStatus", StatusData, "UTF-8");
      // checkout failed
      if (checkStatus(StatusContent)) return;    
        
    } finally {
      s_logger.info("Finished PostSaveDerivedDataCall");
    }      
  }    

  //
  //
  //  ############ CHECKOUT... ############
  //
  //
  
  //
  // checkOut - pre action
  // check if the EPLAN project is in readOnly mode
  //
  public void PreCheckOutCall(String applicationName, String designFileName, String UID) throws IOException, EDACancelException, ParserConfigurationException, SAXException
  {
    s_logger.info("PreCheckOutCall:" + "\napp: " + applicationName + "\nstatus: " + designFileName  + "\nUID: " + UID);
    tools.initDynamicProperties();

    try {     
      // call only for ro=1 projects - otherwise no sense to check out a checked out project
      tools.IsCheckedInCheckCall();
    } finally {
      s_logger.info("Finished PreCheckOutCall");
    } 
  }    
  
  //
  // checkOut - post action
  // check the status of the eda checkout call
  // copy the zw1 file form the staging to EPLAN directory
  // create the zw1.xml file with the meta data
  // call the Epis checkout call to give the project the write access
  //  
  public void PostCheckOutCall(String applicationName, String edaDesignFileName, String statusFileName, String UID) throws IOException, EDAException, InterruptedException, ParserConfigurationException, SAXException
  {
    s_logger.info("Start PostCheckoutCall:" + "\napp: " + applicationName + "\nstatus: " + statusFileName + "\ndesign: " + edaDesignFileName + "\nUID: " + UID);
    tools.initDynamicProperties();

    if (edaDesignFileName == null) throw new EDACancelException("PostCheckoutCall: " + registry.getString("eda.design.file.null"));
    if (statusFileName == null)    throw new EDACancelException("PostCheckoutCall: " + registry.getString("eda.status.file.null"));      
    
    // get the project id of eplan - EPLAN_PROJECT_ID
    if (tools.Properties.get("EPLAN_PROJECT_ID") == null)    throw new EDACancelException(registry.getString("missing.EPLAN_PROJECT_ID"));
    if (tools.Properties.get("EPLAN_PROJECT_ID").equals("")) throw new EDACancelException(registry.getString("missing.EPLAN_PROJECT_ID"));
    
    try {  
      // check if the callback shall be run through
      String[] CheckOutStatusData={"status", "message", "refreshed"};
      
      Map<String, String> StatusContent;
      Map<String, String> DesignContents;
      
      StatusContent = tools.GetStatusInfo(statusFileName, "EDACheckOutStatus", CheckOutStatusData, "UTF-8");
      // checkout failed
      if (checkStatus(StatusContent)) return;    
        
      DesignContents = tools.ReadDesignXML(edaDesignFileName, "UTF-8"); 
      
      String ProjectName;
      if (tools.Properties.get("INCL_NAME").equals("ON"))
      { 
        ProjectName = DesignContents.get("ITEMID") + tools.Properties.get("DELIMITER") + DesignContents.get("ITEMNAME");
      }
      else
      {
        ProjectName = DesignContents.get("ITEMID");
      }
      String sourceFileName = DesignContents.get("DATASET_SRC") + "\\" + ProjectName + ".zw1";
      String targetFileName = tools.Properties.get("EDA2EPLAN_TRANSFER_DIR")  + "\\" + tools.Properties.get("EPLAN_PROJECT_ID") + ".zw1";      
      
      // check if any zw1 file exists in the dataset source directory - if yes and the name isnt = head_id -> rename it      
      String zw1FileName = tools.FindFileName(DesignContents.get("DATASET_SRC"), "zw1");
      if (!zw1FileName.equals(ProjectName)) 
      {
        String orgFileName = DesignContents.get("DATASET_SRC") + "\\" + zw1FileName + ".zw1";
        File orgZW1File = new File(orgFileName);
        if (!orgZW1File.renameTo(new File(sourceFileName)))
        {
          throw new EDACancelException("PostCheckoutCall: " + registry.getString("cantRename") + " " + orgFileName + " -> " + sourceFileName);
        }        
      }
      
      File checkSourceFile = new File(sourceFileName);
      if (!checkSourceFile.exists())
      {
        throw new EDACancelException("PostCheckoutCall: " + registry.getString("eda.design.missing") + ":" + sourceFileName + registry.getString("reopen"));
      }
      
      // copy zw1     
      tools.CopyFile(sourceFileName, targetFileName);
      
      // prepare the attributes from design for zw1.xml
      DesignContents.put("ATTRIBUTES", tools.PrepareXMLZw1Attributes(DesignContents));
      
      // for the UID transfer
      DesignContents.put("UID", UID); 
      DesignContents.put("EPLAN_UID_ATTR", tools.Properties.get("EPLAN_UID_ATTR"));      

      // create the zw1.xml 
      File XMLTemplate = tools.CheckTemplate(tools.Properties.get("ZW1_XML_TEMPLATE"));
      tools.CreateXMLFromTemplate(XMLTemplate, DesignContents, targetFileName + ".xml", "UTF-16", true);           
        
      // get the eplan checkout script   
      if (tools.StartEPLAN("checkOut", DesignContents) != 1) throw new EDAException("PostCheckoutCall: " + registry.getString("eplan.checkOut.fail"));
      
      // cleanUP zw1.xml
      tools.FileDelete(targetFileName + ".xml");
    } finally {
      s_logger.info("Finished PostCheckOutCall");
    }      
  }
  
  //
  //
  //  ############ CANCEL CHECKOUT... ############
  //
  //  
  
  //
  // Uncheckout - pre action
  // check if the EPLAN project has the write access
  //
  public void PreCancelCheckoutCall(String applicationName, String edaDesignFileName , String UID) throws IOException, EDACancelException, ParserConfigurationException, SAXException
  {
    s_logger.info("PreCancelCheckoutCall:" + "\napp: " + applicationName + "\ndesign: " + edaDesignFileName  + "\nUID: " + UID);
    tools.initDynamicProperties();

    try {
      // check if the project is checked out otherwise cancel check out doesnt make sense
      tools.IsCheckedOutCheckCall(); 
    } finally {
      s_logger.info("Finished PreCancelCheckoutCall");
    }    
  }  
  
  //
  // Uncheckout - post action
  // check the status of the eda Uncheckout call
  // execute epis call to cancelcheckout - the project will closed
  // copy the zw1 file from staging to EPLAN directory
  // create zw1.xml with the meta data
  // execute epis open call - the proejct will be opened in readOnly mode
  public void PostCancelCheckoutCall(String applicationName, String edaDesignFileName, String statusFileName, String UID) throws IOException, EDAException, InterruptedException, ParserConfigurationException, SAXException
  {
    s_logger.info("Start PostCancelCheckoutCall:" + "\napp: " + applicationName + "\nstatus: " + statusFileName + "\ndesign: " + edaDesignFileName + "\nUID: " + UID);
    tools.initDynamicProperties();

    if (edaDesignFileName == null) throw new EDACancelException("PostCancelCheckoutCall: " + registry.getString("eda.design.file.null"));
    if (statusFileName == null)    throw new EDACancelException("PostCancelCheckoutCall: " + registry.getString("eda.status.file.null"));      
    
    // get the project id of eplan - EPLAN_PROJECT_FILE
    if (tools.Properties.get("EPLAN_PROJECT_FILE") == null)    throw new EDACancelException(registry.getString("missing.EPLAN_PROJECT_FILE"));
    if (tools.Properties.get("EPLAN_PROJECT_FILE").equals("")) throw new EDACancelException(registry.getString("missing.EPLAN_PROJECT_FILE"));

    // get the project id of eplan - EPLAN_PROJECT_ID
    if (tools.Properties.get("EPLAN_PROJECT_ID") == null)    throw new EDACancelException(registry.getString("missing.EPLAN_PROJECT_ID"));
    if (tools.Properties.get("EPLAN_PROJECT_ID").equals("")) throw new EDACancelException(registry.getString("missing.EPLAN_PROJECT_ID"));

    try {
      // check if the callback shall be run through
      String[] CancelCheckOutStatusData={"status", "message", "doNotKeep"};
      
      Map<String, String> StatusContent;
      
      StatusContent = tools.GetStatusInfo(statusFileName, "EDACancelCheckoutStatus", CancelCheckOutStatusData, "UTF-8");

      if (checkStatus(StatusContent)) return;

      // check if purge executed -> no design file exists in that case      
      if (StatusContent.get("DONOTKEEP").equals("true") == true)
      {
        s_logger.info("PostCancelCheckoutCall: Purge! Don't reopen the project.");
        
        Map<String, String> DesignContents = new HashMap<String, String>();
        
        // put the data neccessery for the EPLAN call
        DesignContents.put("EPLAN_REMOTE_APP", tools.Properties.get("EPLAN_REMOTE_APP"));
        DesignContents.put("EPLAN_PROJECT_FILE", tools.Properties.get("EPLAN_PROJECT_FILE"));
              
        // epis undocall
        tools.StartEPLAN("cancelCheckOut", DesignContents);        
      } 
      else
      {
    	s_logger.info("PostCancelCheckoutCall: No Purge! Reopen the project read only.");
       
        Map<String, String> DesignContents = tools.ReadDesignXML(edaDesignFileName, "UTF-8");    
        
        if (!DesignContents.containsKey("HEAD_ID")) throw new EDAException("PostCancelCheckoutCall: " + registry.getString("edadesign.missing.itemid"));
        if (!DesignContents.containsKey("DATASET_SRC")) throw new EDAException("PostCancelCheckoutCall: " + registry.getString("edadesign.missing.stagingDir"));
            
        // epis undocall
        if (tools.StartEPLAN("cancelCheckOut", DesignContents) == 1)
        {
          String ProjectName;
          if (tools.Properties.get("INCL_NAME").equals("ON"))
          { 
            ProjectName = DesignContents.get("ITEMID") + tools.Properties.get("DELIMITER") + DesignContents.get("ITEMNAME");
          }
          else
          {
            ProjectName = DesignContents.get("ITEMID");
          }
          
          DesignContents.put("PROJECT_NAME", ProjectName);
          String sourceFileName = DesignContents.get("DATASET_SRC") + "\\" + ProjectName + ".zw1";
          String targetFileName = tools.Properties.get("EDA2EPLAN_TRANSFER_DIR")  + "\\" + tools.Properties.get("EPLAN_PROJECT_ID") + ".zw1";
          // copy files from staging to transfer
          tools.CopyFile(sourceFileName, targetFileName);
        
          // prepare the attributes from design for zw1.xml
          DesignContents.put("ATTRIBUTES", tools.PrepareXMLZw1Attributes(DesignContents));
      
          // for the UID transfer
          DesignContents.put("UID", UID); 
          DesignContents.put("EPLAN_UID_ATTR", tools.Properties.get("EPLAN_UID_ATTR"));   

          // create the zw1.xml 
          File XMLTemplate = tools.CheckTemplate(tools.Properties.get("ZW1_XML_TEMPLATE"));
          tools.CreateXMLFromTemplate(XMLTemplate, DesignContents, targetFileName + ".xml", "UTF-16", true);           
        
          // make sure project opened readonly
          DesignContents.put("READONLY", "1");
        
          // reopen the project in EPLAN ro=1   
          if (tools.StartEPLAN("open", DesignContents) != 1) throw new EDAException("PostCancelCheckoutCall: " + registry.getString("eplan.open.fail"));
        
          // cleanUP zw1.xml
          tools.FileDelete(targetFileName + ".xml");
        }  
      }
    } finally {
      s_logger.info("Finished PostCancelCheckoutCall");
    } 
  }

}
