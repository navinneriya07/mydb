// SVN:       $Id: EPLANLibAdapter.java 432 2017-09-11 15:25:30Z uschu $     
package de.tesis.plmware.eda_eplan;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.math.BigInteger;
import java.nio.channels.FileChannel;
import java.util.HashMap;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

import org.slf4j.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.teamcenter.edabase.EDACancelException;
import com.teamcenter.edabase.EDAConfiguration;
import com.teamcenter.edabase.EDAException;
import com.teamcenter.edabase.lib.utils.EDALibUtils;
import com.teamcenter.edabase.model.LoginModel;
import com.teamcenter.edabase.services.DefaultSOAService;
import com.teamcenter.edabase.services.IEDASessionService;
import com.teamcenter.schemas.soa._2006_03.exceptions.ServiceException;
import com.teamcenter.services.strong.core.DataManagementService;
import com.teamcenter.services.strong.core.SessionService;
import com.teamcenter.services.strong.core._2006_03.DataManagement.GenerateItemIdsAndInitialRevisionIdsProperties;
import com.teamcenter.services.strong.core._2006_03.DataManagement.GenerateItemIdsAndInitialRevisionIdsResponse;
import com.teamcenter.services.strong.core._2006_03.DataManagement.ItemIdsAndInitialRevisionIds;
import com.teamcenter.services.strong.core._2007_01.DataManagement.GetItemFromIdInfo;
import com.teamcenter.services.strong.core._2007_01.DataManagement.GetItemFromIdPref;
import com.teamcenter.services.strong.core._2007_01.DataManagement.GetItemFromIdResponse;
import com.teamcenter.services.strong.core._2007_01.Session.MultiPreferencesResponse;
import com.teamcenter.services.strong.core._2007_01.Session.ScopedPreferenceNames;
import com.teamcenter.services.strong.query.SavedQueryService;
import com.teamcenter.services.strong.query._2006_03.SavedQuery.GetSavedQueriesResponse;
import com.teamcenter.services.strong.query._2007_09.SavedQuery.QueryResults;
import com.teamcenter.services.strong.query._2007_09.SavedQuery.SavedQueriesResponse;
import com.teamcenter.services.strong.query._2008_06.SavedQuery.QueryInput;
import com.teamcenter.soa.client.Connection;
import com.teamcenter.soa.client.model.ModelObject;
import com.teamcenter.soa.client.model.ServiceData;
import com.teamcenter.soa.client.model.strong.ImanQuery;
import com.teamcenter.soa.exceptions.NotLoadedException;



/**
 * Class to implement the callbacks necessary for the
 * "PLM Teamcenter Connector EPLAN Integration". Parameter description:
 * "Teamcenter EDA Library Connector Integration Guide" 9.0:
 */
public class EPLANLibAdapter {
  private static final String EDALIB_ITEM_TYPES_MAPPING_EPLAN = "EDALIB_ItemTypesMapping_EPLAN";
	private static Logger s_logger = null;
  String itemIdIndex = null;
  String artIdIndex = null;
  
  EPLANToolbox tools = null;
  
  public EPLANLibAdapter() throws IOException, EDAException
  { 
    tools = new EPLANToolbox();
  }  
  

  // necessary to use this class in Xalan. Xalan cannot load classes with static initializers.
  private static void init() {
    if (s_logger == null) {
      s_logger = EPLANToolbox.getLogger(EPLANLibAdapter.class.getName());
    }  
  }
  /**
   * a main function to make the XSLT processor available via command line
   * @param args
   */
  public static void main(String[] args) {
    init();
    s_logger.info("XSLT main entry");
    //Thread.currentThread().setContextClassLoader(EPLANLibAdapter.class.getClassLoader());
    try {
      com.sun.org.apache.xalan.internal.xslt.Process._main(args); 
    } catch (Exception e) {
      s_logger.error(e.getMessage());
    }
    s_logger.info("XSLT main exit");
  }
  
  public String getTCNextFreeID(DataManagementService dmSoaService, String ItemType) throws IOException {
    String newItemId = null;
    s_logger.info("START getTCNextFreeID - " +  ItemType);
    
    try {
      GenerateItemIdsAndInitialRevisionIdsProperties[] properties = new GenerateItemIdsAndInitialRevisionIdsProperties[1];
      GenerateItemIdsAndInitialRevisionIdsProperties property = new GenerateItemIdsAndInitialRevisionIdsProperties();
      if (properties.length == 1)
      {
        property.count = 1;
        property.itemType = ItemType;
        property.item = null; // Not used
        properties[0] = property;    

        GenerateItemIdsAndInitialRevisionIdsResponse response = dmSoaService.generateItemIdsAndInitialRevisionIds(properties);
  
        Map newIds = response.outputItemIdsAndInitialRevisionIds;
  
        BigInteger bIKey = new BigInteger("0");
        ItemIdsAndInitialRevisionIds [] newId = (ItemIdsAndInitialRevisionIds[]) newIds.get(bIKey);

        newItemId = newId[0].newItemId;
        s_logger.info("getTCNextFreeID - newItemId " +  newItemId);
      }
    } catch (Exception e) {
      s_logger.error( "getTCNextFreeID - Exception " +  e.getMessage());
    } finally {
      s_logger.info("FINISH getTCNextFreeID");
    }
    return newItemId;
  }
  

  public boolean itemIdExists(DataManagementService dmSoaService, String itemId) throws NotLoadedException, IOException
  {
    boolean existID = false;
    
    s_logger.info("START itemIdExists - " +  itemId);

    GetItemFromIdInfo[] itemInfos = new GetItemFromIdInfo[1];
    GetItemFromIdInfo itemInfo = new GetItemFromIdInfo();
    itemInfo.itemId =itemId;
    
    itemInfos[0] = itemInfo;
    

    GetItemFromIdPref IdPref = new GetItemFromIdPref();

    try {
      // find all items
      GetItemFromIdResponse findResponse = dmSoaService.getItemFromId(itemInfos, 1, IdPref);
    
      if(findResponse.output.length == 1)
      {
        existID = true;
        s_logger.info("itemIdExists - 1 item with the itemID " + itemId + " found");
      }
    } catch (Exception e) {
      s_logger.info("itemIdExists - itemID " + itemId + " doesn't exist");
    }

    s_logger.info("FINISH itemIdExists");

    return existID;
  }
  
  //
  // move file form source to target
  //
  public void CopyFile(String sourceFileName, String targetFileName) throws IOException
  {
    FileInputStream inStream = null; 
    FileChannel inChannel = null;
    FileOutputStream outStream = null;
    FileChannel outChannel = null; 

    try {
      
	  File fSource = new File(sourceFileName);
      File fTarget = new File(targetFileName);
      
      if (!fSource.exists())
      {
        throw new IOException(sourceFileName);
      }
      
      if (fTarget.exists()) fTarget.delete();

      inStream = new FileInputStream(fSource); 
      inChannel = inStream.getChannel();
      outStream = new FileOutputStream(fTarget);
      outChannel = outStream.getChannel(); 
      
      inChannel.transferTo(0, inChannel.size(), outChannel);
      
    } catch (IOException e) {
      throw new IOException("CopyFile IOException :" + e.getMessage()); 
    } finally {
      if (inChannel != null)
        inChannel.close();
      if (inStream != null)
      inStream.close();
      if (outChannel != null)
      outChannel.close();
      if (outStream != null)
      outStream.close();
      
    }
  }   
  
  public void transformIntoFile(Document doc, String XMLFileName, String Encoding) throws IOException, TransformerConfigurationException, TransformerException, EDACancelException
  {
    s_logger.info("START transformIntoFile " + XMLFileName + " : " + Encoding);
    
    tools.FileDelete(XMLFileName);

    // write the content into xml file
    TransformerFactory transformerFactory = TransformerFactory.newInstance();
    Transformer transformer = transformerFactory.newTransformer();
    transformer.setOutputProperty(OutputKeys.ENCODING, Encoding);

    DOMSource source = new DOMSource(doc);
    StreamResult result = new StreamResult(new File(XMLFileName));
    transformer.transform(source, result);       

    s_logger.info("FINISH transformIntoFile");
  }
  
  
  
  public Boolean CompleteXMLFile(String XMLFileName, String Encoding, DataManagementService dmSoaService, SavedQueryService queryService, String itemType) throws IOException
  {
	Boolean retValue = true;
	Map<Node, String> keepForUpdate = new HashMap<Node, String>();
	
	s_logger.info("START CompleteXMLFile");

    File XMLFile = new File(XMLFileName);
    
    if (!XMLFile.exists())
    {
      s_logger.error( "CompleteXMLFile - xml file doesn't exist " + XMLFileName);
      return false;
    }
    
    try 
    {    
      DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
      DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
      Document doc = docBuilder.parse(XMLFile);
     
      // normalize text representation
      doc.getDocumentElement().normalize();
    
      NodeList Parts = doc.getElementsByTagName("part");
      int noOfParts = Parts.getLength();
      
      s_logger.info("CompleteXMLFile - number of parts " +  Integer.toString(noOfParts));
      
      for(int s = 0; s < noOfParts ; s++)
      {
        Node propNode = Parts.item(s);

        if(propNode.getNodeType() == Node.ELEMENT_NODE) 
        { 
          Element propElement = (Element)propNode;
        
          NodeList properties = propElement.getElementsByTagName("property");
          Element IDProperty = null;
          
          String itemID = null;
          String artID = null;
          
          for (int x = 0; x < properties.getLength(); x++)
          {  
            Element property = (Element)properties.item(x);
            Node propIndex = property.getAttributeNode("propertyIndex");
              
            String Indx = propIndex.getNodeValue();

            String propIndexVal = null;
            
            if (Indx.equals(itemIdIndex)) IDProperty = property;

            try {
              propIndexVal  = property.getFirstChild().getNodeValue();
              
              if (Indx.equals(itemIdIndex)) itemID = propIndexVal;
              if (Indx.equals(artIdIndex)) artID = propIndexVal;
            } catch (Exception e) {
              if (Indx.equals(itemIdIndex)) itemID = null;
              if (Indx.equals(artIdIndex)) artID = null;
            }
          }
          
          if (artID != null)
          {
          	// "Product Backlog Item 128916:TCC: Sync part from EPLAN to TC with filled ERP Number":
          	// The query checks: either articleIds are equal or itemIds are equal and articleID in TC is empty
            String[] matchingItems = lookUpMatchingItem(dmSoaService, queryService, artID, itemID, itemType);
          
            if (matchingItems == null)
            {
              if (itemID != null)
              {
                if (itemIdExists(dmSoaService, itemID))
                {
                  // error remove the block
                  s_logger.error( "### ERROR CompleteXMLFile - " +  itemID + " - itemID already exists ");
                  // take the whole part out of xml!!
                  propNode.getParentNode().removeChild(propNode);
                  // Normalize the DOM tree to combine all adjacent nodes
                  doc.normalize();    

                  // decrese index and get the new number of parts
                  s--;
                  noOfParts = Parts.getLength();                
                } else {
                  keepForUpdate.put(propNode, "SKIP");
                }
              }
              else
              {
                s_logger.info("CompleteXMLFile - matchingItemId = null get free id");
                itemID =  getTCNextFreeID(dmSoaService, itemType);
            
                IDProperty.setTextContent(itemID);
                s_logger.info("CompleteXMLFile - set new id " +  itemID);  
                keepForUpdate.put(propNode, "UPDATE");
              }
            }
            else
            {
              if (matchingItems.length == 1)
              { 
                s_logger.info("CompleteXMLFile - matchingItemId " + matchingItems[0]);
            
                if (itemID != null)
                {
                  if (!itemID.equals(matchingItems[0])) 
                  {
                    s_logger.error( "### ERROR CompleteXMLFile - " +  artID + " - itemID and found itemId don't match " +  itemID + "<>" + matchingItems[0]);
                    // take the whole part out of xml!!
                    propNode.getParentNode().removeChild(propNode);
                    // Normalize the DOM tree to combine all adjacent nodes
                    doc.normalize();    

                    // decrese index and get the new number of parts
                    s--;
                    noOfParts = Parts.getLength();
                  } 
                  else
                  {
                  	// "Product Backlog Item 128916:TCC: Sync part from EPLAN to TC with filled ERP Number":
                  	// if articelID in TC is empty, SKIP this entry, so it will be updated
                  	
                    keepForUpdate.put(propNode, "SKIP");
                  }
                }
                else
                {
                  IDProperty.setTextContent( matchingItems[0]);
                  s_logger.info("CompleteXMLFile - set id to found by query" +   matchingItems[0]);                    
                  keepForUpdate.put(propNode, "UPDATE");
                }
              }
              else
              {
                s_logger.error( "### ERROR CompleteXMLFile - " + artID + " more then one item with the articleNo found");
                // take the whole part out of xml!!!
                propNode.getParentNode().removeChild(propNode);
                // Normalize the DOM tree to combine all adjacent nodes
                doc.normalize();    

                // decrese index and get the new number of parts
                s--;
                noOfParts = Parts.getLength();            
              }
            }   
          }//end of if clause
        }
        else
        {
          s_logger.error( "### ERROR CompleteXMLFile - parts with empty articleNo are not allowed");
          // take the whole part out of xml!!
          propNode.getParentNode().removeChild(propNode);
          // Normalize the DOM tree to combine all adjacent nodes
          doc.normalize();    

          // decrese index and get the new number of parts
          s--;
          noOfParts = Parts.getLength();          
        }
      }//end of for loop with s var
      
      noOfParts = Parts.getLength();
      s_logger.info("Kept parts: " + noOfParts);
      s_logger.info("CompleteXMLFile - transform xml");
      
      transformIntoFile(doc, XMLFileName + "_eda", Encoding);
      
      s_logger.info("CompleteXMLFile - xml transformed to " + XMLFileName + "_eda");
      
      XMLFile.delete();
      
      File NewXMLFile = new File(XMLFileName + "_eda");
      NewXMLFile.renameTo(new File(XMLFileName));
      s_logger.info("CompleteXMLFile - delted and renamed to " + XMLFileName);    
      
      for(int s = 0; s < noOfParts ; s++)
      {
        Node propNode = Parts.item(s);

        if(propNode.getNodeType() == Node.ELEMENT_NODE) 
        {
          if (keepForUpdate.get(propNode).equals("SKIP"))
          {
            s_logger.info("CompleteXMLFile - remove part from EDA -> EPLAN update xml");
            // take the whole part out of xml!!
            propNode.getParentNode().removeChild(propNode);
            // Normalize the DOM tree to combine all adjacent nodes
            doc.normalize();    

            // decrese index and get the new number of parts
            s--;
            noOfParts = Parts.getLength();              
          }
        }
      }
      
      transformIntoFile(doc, XMLFileName + "_eplan", Encoding);
      s_logger.info("CompleteXMLFile - xml transformed to " + XMLFileName + "_eplan");
    } catch (SAXException e) { 
      s_logger.error( "CompleteXMLFile - SAXException" +  e.getMessage());
      retValue = false;
    } catch (ParserConfigurationException e) { 
      s_logger.error( "CompleteXMLFile - ParserConfigurationException" +  e.getMessage()); 
      retValue = false;
    } catch (TransformerConfigurationException e) { 
      s_logger.error( "CompleteXMLFile - TransformerConfigurationException" +  e.getMessage());    
      retValue = false;
    } catch (TransformerException e) { 
      s_logger.error( "CompleteXMLFile - TransformerException" +  e.getMessage());  
      retValue = false;
    } catch (Exception e) {
      s_logger.error( "CompleteXMLFile - Exception" +  e.getMessage());  
      retValue = false;
    } finally {
      s_logger.info("FINISH CompleteXMLFile");
    }
    
    return retValue;
  }  
  

  /**
   * Configure the ECAD library path.
   * 
   * @param edaLibXmlFileName
   *          Specifies EDALib xml file that is used to store the library path.
   **/
  public void configureLibraryPath(String edaLibXmlFileName) {
    init();
    s_logger.trace("enter configureLibraryPath",
        new Object[] { edaLibXmlFileName });

    s_logger.trace("exit configureLibraryPath");
  }

  /**
   * Import parts into the ECAD file-based part library.
   * 
   * @param edaLibXmlFileName
   *          Specifies EDALib xml file which contains the parts
   * @param libraryPath
   *          Specifies the ECAD library path.
   **/
  public void importLibrary(String edaLibXmlFileName, String libraryPath) {
    init();
    s_logger.trace("enter importLibrary",
        new Object[] { edaLibXmlFileName, libraryPath });

    s_logger.trace("exit importLibrary");
  }
  
  
  public String getPreferenceValue(Connection connection, String preferenceName, String scope) throws EDACancelException, IOException {
    String PreferenceValue  = null;
    
    s_logger.info("Start getPreferenceValue " + preferenceName + "-" + scope);
    
    try {
      SessionService sessionService = SessionService.getService(connection);
      ScopedPreferenceNames[] Prefs = new ScopedPreferenceNames[1];
      ScopedPreferenceNames Pref = new ScopedPreferenceNames();
      String[] PrefName = {preferenceName};
      Pref.names = PrefName;
      Pref.scope = scope;
      Prefs[0] = Pref;

      MultiPreferencesResponse PrefResponse = sessionService.getPreferences(Prefs);
    
      if (PrefResponse.preferences.length == 1)
      {
        PreferenceValue =  PrefResponse.preferences[0].values[0];
        s_logger.info("getPreferenceValue value" +PreferenceValue);
      }
      else s_logger.error( "getPreferenceValue found preferences" + PrefResponse.preferences.length);
        
    } catch (ServiceException e) {
      s_logger.error( "getPreferenceValue - ServiceException" +  e.getMessage());  
      throw new EDACancelException("getPreferenceValue - reading preference " + preferenceName + " " + scope + ":" + e.getMessage()); 
    } finally {
      s_logger.info("FINISH getPreferenceValue");
    }
    
    return PreferenceValue;
    
  }
  
  public String[] getPreferenceValues(Connection connection, String preferenceName, String scope) throws EDACancelException, IOException {
    String PreferenceValues[]  = null;
    
    s_logger.info("Start getPreferenceValues " + preferenceName + "-" + scope);
    
    try {
      SessionService sessionService = SessionService.getService(connection);
      ScopedPreferenceNames[] Prefs = new ScopedPreferenceNames[1];
      ScopedPreferenceNames Pref = new ScopedPreferenceNames();
      String[] PrefName = {preferenceName};
      Pref.names = PrefName;
      Pref.scope = scope;
      Prefs[0] = Pref;

      MultiPreferencesResponse PrefResponse = sessionService.getPreferences(Prefs);
    
	      PreferenceValues =  PrefResponse.preferences[0].values;
	      s_logger.info("getPreferenceValues value" +PreferenceValues);
        
    } catch (ServiceException e) {
      s_logger.error( "getPreferenceValues - ServiceException" +  e.getMessage());  
      throw new EDACancelException("getPreferenceValues - reading preference " + preferenceName + " " + scope + ":" + e.getMessage()); 
    } finally {
      s_logger.info("FINISH getPreferenceValues");
    }
    
    return PreferenceValues;
    
  }
  
  
  public ImanQuery GetQuery(DataManagementService dmSoaService, SavedQueryService queryService, String queryName) throws EDACancelException, IOException {
    ImanQuery Query = null;
    
    s_logger.info("START: GetQuery " + queryName);  
    
    if (queryName == null) throw new EDACancelException("GetQuery: ERROR Query Name is null");
    
    try {
      GetSavedQueriesResponse savedQueries = queryService.getSavedQueries();
      
      if (savedQueries.queries.length == 0)
      {
        s_logger.error( "GetQuery - no saved queries found");  
        throw new EDACancelException("ERROR: GetQuery - no saved queries found ");
      }
      
      // Find one with the given name
      Boolean queryFound = false;
      for (int x = 0; x < savedQueries.queries.length; x++)
      {
        if (savedQueries.queries[x].name.equals(queryName))
        {
          Query = savedQueries.queries[x].query;
          queryFound = true;
          break;
        }
      }
      if (queryFound == false)
      {
        s_logger.error( "GetQuery - no search query found " + queryName);  
        throw new EDACancelException("ERROR: GetQuery - no search query found " + queryName);
      }      
    } catch (Exception e) {
      s_logger.error( "GetQuery - Exception " + e.getMessage());  
      throw new EDACancelException("GetQuery - Exception " + e.getMessage()); 
    } finally {
      s_logger.info("FINISH: GetQuery");  
    }
    
    return Query;
  }    
  
  
  /**
   * @param dmSoaService
   * @param queryService
   * @param articleId		articleID/EPLAN Part number as given by EPIS parts export, mandatory
   * @param itemID			itemID/EPLAN ERP number as given by EPIS parts export, optional, may be empty
   * @param itemType    item type for parts to create
   * @return a String array with either one single ID of the potential matching item or a String array with empty strings just to indicate the size of the match. 
   * @throws EDACancelException
   * @throws IOException
   */
  public String[] lookUpMatchingItem(DataManagementService dmSoaService, SavedQueryService queryService, String articleId, String itemID, String itemType) throws EDACancelException, IOException {
    String matchingItemIds[]  = null;
    
    s_logger.info("START: lookUpMatchingItem articleId: " + articleId + " ItemID: " + itemID + " itemType: " + itemType);  
    
    if (System.getenv("EPLAN_LIB_EXPORT_QUERY_ARTICLEID") == null)    throw new EDACancelException("Missing EPLAN_LIB_EXPORT_QUERY_ARTICLEID");
    if (System.getenv("EPLAN_LIB_EXPORT_QUERY_ARTICLEID").equals("")) throw new EDACancelException("Missing EPLAN_LIB_EXPORT_QUERY_ARTICLEID");
    String articleQueryName = System.getenv("EPLAN_LIB_EXPORT_QUERY_ARTICLEID");		  
  
    if (System.getenv("EPLAN_LIB_EXPORT_QUERY_ITEMID") == null)    throw new EDACancelException("Missing EPLAN_LIB_EXPORT_QUERY_ITEMID");
    if (System.getenv("EPLAN_LIB_EXPORT_QUERY_ITEMID").equals("")) throw new EDACancelException("Missing EPLAN_LIB_EXPORT_QUERY_ITEMID");
    String itemQueryName = System.getenv("EPLAN_LIB_EXPORT_QUERY_ITEMID");		  
  
    if (System.getenv("EPLAN_LIB_EXPORT_ENTRY_TYPE") == null)    throw new EDACancelException("Missing EPLAN_LIB_EXPORT_ENTRY_TYPE");
    if (System.getenv("EPLAN_LIB_EXPORT_ENTRY_TYPE").equals("")) throw new EDACancelException("Missing EPLAN_LIB_EXPORT_ENTRY_TYPE");
    String entryType = System.getenv("EPLAN_LIB_EXPORT_ENTRY_TYPE");	
  
    if (System.getenv("EPLAN_LIB_EXPORT_ENTRY_NO") == null)    throw new EDACancelException("Missing EPLAN_LIB_EXPORT_ENTRY_NO");
    if (System.getenv("EPLAN_LIB_EXPORT_ENTRY_NO").equals("")) throw new EDACancelException("Missing EPLAN_LIB_EXPORT_ENTRY_NO");
    String entryNo = System.getenv("EPLAN_LIB_EXPORT_ENTRY_NO");		    
        
    if (System.getenv("EPLAN_LIB_EXPORT_ENTRY_ITEMID") == null)    throw new EDACancelException("Missing EPLAN_LIB_EXPORT_ENTRY_ITEMID");
    if (System.getenv("EPLAN_LIB_EXPORT_ENTRY_ITEMID").equals("")) throw new EDACancelException("Missing EPLAN_LIB_EXPORT_ENTRY_ITEMID");
    String entryItemID = System.getenv("EPLAN_LIB_EXPORT_ENTRY_ITEMID");		    
        
    s_logger.debug("QUERY:" + articleQueryName + " Type:" + entryType + " No:" + entryNo + " ItemID: " + entryItemID);
    
    if ( articleId == null || itemType == null) throw new EDACancelException("lookUpMatchingItem: ERROR unsufficient input " + articleQueryName);
    
    try {
    	// TODO #4256: 
    	// the simple approach with a single query does not work for 2 reasons:
    	// 1.) TC saved queries do not support mixed "AND" and "OR" clauses --> "unexpected results" 
    	// 2.) An empty value in a query clause causes TC saved queries to ignore the complete clause --> 
    	//        if itemId is empty we will get all EP2Parts with an empty articleID, not the one with the correct articleID.
    	// So we need to do 2 queries: The old one first, and then, only if an itemId is set, a second one searching for
    	// parts with empty article ID and the correct itemID.
    	
      //Search for all Items, returning a maximum of 2 objects
      QueryResults found = executeQuery(dmSoaService, queryService, articleQueryName, entryNo, articleId, entryType,
			    itemType);
            
      if (itemID != null && itemID.length() > 0 && found.objectUIDS.length == 0)
      {
      	// in case an itemId is given and we could not find a matching item based on the article ID,
      	// we try to find a part with an empty article ID and the given itemID instead.
        found = executeQuery(dmSoaService, queryService, itemQueryName, entryItemID, itemID, entryType,
  			    itemType);
      } 
      
      
      if (found.objectUIDS.length == 1)
      {
        String[] uids = new String[1];
               
        uids[0]= found.objectUIDS[0];
        ServiceData sd = dmSoaService.loadObjects(uids);
        ModelObject[] foundObjs = new ModelObject[sd.sizeOfPlainObjects()];
        foundObjs[0] = sd.getPlainObject(0);
                
        matchingItemIds = new String[1];
        matchingItemIds[0] = foundObjs[0].getPropertyDisplayableValue("item_id");   
      }
      if (found.objectUIDS.length > 1)
      {
      	// we return an array of empty entries and the size reflects the number of matching objects.
      	// this is sufficient to determine the error situation, there is no need to copy the item IDs
      	// to the array.
        matchingItemIds = new String[found.objectUIDS.length];
      }
    } catch (Exception e) {
      s_logger.error("marker", "lookupMatchingItem", e);
      s_logger.error( "lookUpMatchingItem - Exception " + e.getMessage());  
      throw new EDACancelException("lookUpMatchingItem - Exception " + e.getMessage()); 
    } finally {
      s_logger.info("FINISH: lookUpMatchingItem");  
    }
    
    return matchingItemIds;
  }


	public QueryResults executeQuery(DataManagementService dmSoaService, SavedQueryService queryService, String queryName,
	    String param1Name, String param1Value, String param2Name, String param2Value)
	    throws EDACancelException, IOException {
		s_logger.debug("executeQuery: " + queryName + " param1Name: " + param1Name + " param1Value: " + param1Value + " param2Name: " + param2Name + " param2Value: " + param2Value + ".");
		ImanQuery savedQuery;
		QueryInput savedQueryInput[] = new QueryInput[1];
		     
		QueryInput myQueryInput = new QueryInput();
		      
		savedQuery = GetQuery(dmSoaService, queryService, queryName);

		savedQueryInput[0] = myQueryInput;
		savedQueryInput[0].query = savedQuery;
		savedQueryInput[0].maxNumToReturn = 2;
		savedQueryInput[0].limitList = new ModelObject[0];
		String [] entry = new String[2];
		String [] value = new String[2];
		      
		entry[0] = param2Name;
		value[0] = param2Value; 
		    
		entry[1] = param1Name;
		value[1] = param1Value;
		    
		savedQueryInput[0].entries = entry; 
		savedQueryInput[0].values = value;
		        
		// execute query
		SavedQueriesResponse savedQueryResult = queryService.executeSavedQueries(savedQueryInput);
		// get the results
		QueryResults found = savedQueryResult.arrayOfResults[0];
		return found;
	}  
  
  /**
   * @param edaLibXmlFileName101
   *          check the status and if success copy the xml file for reverse mapping
   * @throws EDAException
   * @throws IOException 
   **/
  public void postExportLibrary101(String applicationName, String edaLibXmlFileName, String statusFileName)  throws EDAException, IOException, SAXException, ParserConfigurationException {
    s_logger.info("START postExportLibrary 10.1 " +  applicationName + " - " +  edaLibXmlFileName + " - " + statusFileName);
    postExportLibrary(statusFileName); 
  }
  
  /**
   * @param edaLibXmlFileName
   *          check the status and if success copy the xml file for reverse mapping
   * @throws EDAException
   * @throws IOException 
   **/
  public void postExportLibrary(String statusFileName)  throws EDAException, IOException, SAXException, ParserConfigurationException {
    /*String[] ExportLibraryStatusData={"status", "message"};
    
    Map<String, String> StatusContent = tools.GetStatusInfo(statusFileName, "EDAExportLibraryStatus", ExportLibraryStatusData, "UTF-8");

    if (StatusContent.get("STATUS").equals("Cancel")) 
    { 
      s_logger.error( "EDA call canceled.");     
      return;
    }
    else if (StatusContent.get("STATUS").equals("Success") == false) 
    {
      s_logger.error( "LibraryLibrary failed: " + StatusContent.get("STATUS") + ": " + StatusContent.get("MESSAGE"));     
      throw new EDAException("LibraryLibrary failed: " + StatusContent.get("STATUS") + ": " + StatusContent.get("MESSAGE"));
    }*/
    tools.initDynamicProperties();
    try {
      s_logger.info("START postExportLibrary " +  statusFileName);
      // if call successfull copy the xml file
      if (tools.Properties.get("EPLAN_LIB_EXPORT_XML") == null)    throw new EDACancelException("Missing EPLAN_LIB_EXPORT_XML");
      if (tools.Properties.get("EPLAN_LIB_EXPORT_XML").equals("")) throw new EDACancelException("Missing EPLAN_LIB_EXPORT_XML");
      String xmlSourceName = tools.Properties.get("EPLAN_LIB_EXPORT_XML");
      
      if (System.getenv("EDA2EPLAN_TRANSFER_PARTS_DIR") == null)    throw new EDACancelException("Missing EDA2EPLAN_TRANSFER_PARTS_DIR");
      if (System.getenv("EDA2EPLAN_TRANSFER_PARTS_DIR").equals("")) throw new EDACancelException("Missing EDA2EPLAN_TRANSFER_PARTS_DIR");
      String xmlTargetDir = System.getenv("EDA2EPLAN_TRANSFER_PARTS_DIR");
      
      if (xmlSourceName.startsWith("\"") && xmlSourceName.endsWith("\"")) xmlSourceName = xmlSourceName.substring(1, xmlSourceName.length()-1);
      if (xmlTargetDir.startsWith("\"") && xmlTargetDir.endsWith("\"")) xmlTargetDir = xmlTargetDir.substring(1, xmlTargetDir.length()-1);
      
      File sourceFile = new File(xmlSourceName);
      String xmlTargetName = xmlTargetDir + "\\" + sourceFile.getName();
    
      tools.MoveFile(xmlSourceName + "_eplan", xmlTargetName);
      
      File targetFile = new File(xmlTargetName);
      if (!targetFile.exists())
      {
        s_logger.error( "postExportLibrary - file " + xmlSourceName + "_eplan" + "move failed");  
        throw new EDAException("postExportLibrary - file " + xmlSourceName + "_eplan" + "move failed");         
      }
    } finally {
      s_logger.info("FINISH postExportLibrary ");
    }
  }
  
  /**
   * @param edaLibXmlFileName
   *          Specifies EDALib xml file that is used to store the exported
   *          parts.
   * @throws EDAException
   * @throws IOException 
   **/
  public void preExportLibrary(String applicationName, String edaLibXmlFileName) throws EDACancelException, IOException, SAXException, ParserConfigurationException {
  	String itemType = null;
  	
    init();
    tools.initDynamicProperties();

    s_logger.trace("enter preExportLibrary", new Object[] { edaLibXmlFileName });
  
    try { 
      s_logger.info("START preExportLibrary " +  edaLibXmlFileName);
      
      if (System.getenv("EPLAN_LIB_EXPORT_XSL") == null)    throw new EDACancelException("Missing EPLAN_LIB_EXPORT_XSL");
      if (System.getenv("EPLAN_LIB_EXPORT_XSL").equals("")) throw new EDACancelException("Missing EPLAN_LIB_EXPORT_XSL");
      String xslName = System.getenv("EPLAN_LIB_EXPORT_XSL");
	  
      if (tools.Properties.get("EPLAN_LIB_EXPORT_XML") == null)    throw new EDACancelException("Missing EPLAN_LIB_EXPORT_XML");
      if (tools.Properties.get("EPLAN_LIB_EXPORT_XML").equals("")) throw new EDACancelException("Missing EPLAN_LIB_EXPORT_XML");
      String xmlName = tools.Properties.get("EPLAN_LIB_EXPORT_XML");

      if (System.getenv("ITEMID_INDEX") == null)    throw new EDACancelException("Missing ITEMID_INDEX");
      if (System.getenv("ITEMID_INDEX").equals("")) throw new EDACancelException("Missing ITEMID_INDEX");
      itemIdIndex = System.getenv("ITEMID_INDEX");	  
	  
      if (System.getenv("ARTNO_INDEX") == null)    throw new EDACancelException("Missing ARTNO_INDEX");
      if (System.getenv("ARTNO_INDEX").equals("")) throw new EDACancelException("Missing ARTNO_INDEX");
      artIdIndex = System.getenv("ARTNO_INDEX");	
	  
      // if the name includes "" cut them off
      if (xslName.startsWith("\"") && xslName.endsWith("\"")) xslName = xslName.substring(1, xslName.length()-1);
      if (xmlName.startsWith("\"") && xmlName.endsWith("\"")) xmlName = xmlName.substring(1, xmlName.length()-1);
      
      s_logger.info("INFO: preExportLibrary - Env XSL:" +  xslName + " XML:" + xmlName + " ID:" + itemIdIndex + " ART:" + artIdIndex);  
    	
      IEDASessionService sessionService = EDAConfiguration.getInstance().getFactory().getServiceFactory().getSessionService();

      if(!sessionService.isLoggedIn()) {
        
        LoginModel model = EDALibUtils.getSyncLoginModel();
        sessionService.autoLogin(model);
      }
      DefaultSOAService soaService = new DefaultSOAService();
      s_logger.info("preExportLibrary - soaService - OK");  
      Connection connection = soaService.getConnection();
      s_logger.info("preExportLibrary - Connection - OK");  
      DataManagementService dmSoaService = DataManagementService.getService(connection);
      s_logger.info("preExportLibrary - dmSoaService - OK"); 
      SavedQueryService queryService = SavedQueryService.getService(connection);
      s_logger.info("preExportLibrary - queryService - OK");  

      String[] prefValues = getPreferenceValues(connection, EDALIB_ITEM_TYPES_MAPPING_EPLAN, "site");
      String prefix = "Component,";
      for (int i=0; i<prefValues.length; ++i) {
        if (prefValues[i].startsWith(prefix)) {
          itemType = prefValues[i].substring(prefix.length()).split(",")[0];
          break;
        }
      }
      if (itemType == null || itemType.isEmpty()) {
      	throw new EDACancelException("Cannot determine Item type for Components from preference \"" + EDALIB_ITEM_TYPES_MAPPING_EPLAN + "\".");
      }
      s_logger.info("preExportLibrary - Searching for item type \"" + itemType + "\" (taken from site preference \"" + EDALIB_ITEM_TYPES_MAPPING_EPLAN + "\", line \"Component\"");  

      // parse xml
      if (CompleteXMLFile(xmlName, "UTF-16", dmSoaService, queryService, itemType))
      {
        // xsl call        
        Source xmlIn = new StreamSource(new File(xmlName));
        Source xsl = new StreamSource(new File(xslName));
        StreamResult xmlOut = new StreamResult(new File(edaLibXmlFileName));

        s_logger.info("Transformer call " +  xslName + "<>" + xmlName + "<>" + edaLibXmlFileName);  
        Transformer transformer = TransformerFactory.newInstance().newTransformer(xsl);
        transformer.transform(xmlIn, xmlOut);
      }
      else
      {
        s_logger.error( "preExportLibrary - CompleteXMLFile failed");  
        throw new EDACancelException("preExportLibrary - CompleteXMLFile failed");           
      }

      File edaXMLFile =new File(edaLibXmlFileName);
      if (!edaXMLFile.exists())
      {
        s_logger.error( "preExportLibrary - No edaLibExport.xml created");  
        throw new EDACancelException("preExportLibrary - No edaLibExport.xml created"); 
      }
      // TODO: debugging only!
//      tools.CopyFile(edaLibXmlFileName, edaLibXmlFileName + ".save");
    } catch (EDAException e) {
      s_logger.error( "preExportLibrary - EDAException " + e.getMessage());
      throw new EDACancelException("preExportLibrary - EDAException " + e.getMessage());  
    } catch (IOException e) {
      s_logger.error( "preExportLibrary - IOException " + e.getMessage());
      throw new EDACancelException("preExportLibrary - IOException " + e.getMessage());  	
    } catch (TransformerException e) {
      s_logger.error( "preExportLibrary - TransformerException " + e.getMessage());
      throw new EDACancelException("preExportLibrary - TransformerException " + e.getMessage());   
    } catch (Exception e) {
      s_logger.error( "preExportLibrary - Exception " + e.getMessage());
      throw new EDACancelException("ERROR: preExportLibrary - Exception " + e.getMessage()); 	 
    } finally {
       s_logger.info("FINISH preExportLibrary"); 
    }
    
    s_logger.trace("preExportLibrary exit");
  }

  /**
   * Parameter description: "Teamcenter EDA Library Connector Integration Guide"
   * 9.0:
   * 
   * @param edaLibXmlFileName
   *          Specifies EDALib xml file that is used to store the exported
   *          parts.
   * @param libraryPath
   *          Specifies the ECAD library path.
   * @param transferOption
   *          Specfies the transfer option. 1: Export the part number 3: Export
   *          the part attributes 5: Export the part native files 7: Export the
   *          part attributes and native files 8: Export the selected parts
   *          only.
   * @param selectedObejctXmlFileName
   *          Sepcfies the EDALib xml file that contains the selected parts to
   *          export.
   * @throws EDAException
   * @throws IOException 
   **/
  public void exportLibrary(String edaLibXmlFileName, String libraryPath,
      String transferOption, String selectedObjectXmlFileName)
      throws EDAException, IOException {
    init();
    s_logger.trace("enter exportLibrary",
        new Object[] { edaLibXmlFileName, libraryPath, transferOption,
            selectedObjectXmlFileName });

    s_logger.trace("exit exportLibrary");
  }

  /**
   * Configure the table mappings.
   * Parameter description: "Teamcenter EDA Library Connector Integration Guide"
   * 9.0:
   * @param configureFileName Specifies table mappings configuration file name.
   **/
  public void configureMetadataDB( String configureFileName ) {
    init();
    s_logger.trace("enter configureMetadataDB",
        new Object[] { configureFileName });

    File file = new File(configureFileName);
    if (!file.exists()) {
      try {
        file.createNewFile();
      } catch (IOException e) {
        s_logger.error("Create metadata file failed", e);
      }
    }

    s_logger.trace("exit configureMetadataDB");
  }

  /**
   * importMetadataDB: Import parts into the ODBC-based part metadata database.
   * @param configureFileName Speifies the table mappings configuration file name
   * @param edaLibXmlFileName Specifies the EDALib xml file which contains the parts.
   * @param logFileName: Specifies the log file name.
   **/
  public boolean importMetadataDB( String configureFileName, String edaLibXmlFileName, String logFileName ) {
    init();
    s_logger.trace("enter importMetadataDB",
        new Object[] { configureFileName, edaLibXmlFileName, logFileName});

    s_logger.trace("exit importMetadataDB");
    return true;
  }

  /**
   * exportMetadataDB: Export parts from the ODBC-based part metadata database.
   * @param edaLibXmlFileName Specifies EDALib xml file that is used to store the exported parts.
   * @param configureFileName Specifies the table mappings configuration file.
   * @param transferOption Specfies the transfer option.
   *                        1: Export the part number.
   *                        3: Export the part attributes
   *                        5: Export the part native files.
   *                        7: Export the part attributes and native files.
   *                        8: Export the selected parts only.
   * @param selectedObejctXmlFileName Sepcfies the EDALib xml file that contains the selected parts to export.
  **/
  public boolean exportMetadataDB( String edaLibXmlFileName, String configureFileName, String transferOption, String selectedObjectXmlFileName ) {
    init();
    s_logger.trace("enter exportMetadataDB",
        new Object[] { edaLibXmlFileName, configureFileName, transferOption, selectedObjectXmlFileName});

    s_logger.trace("exit exportMetadataDB");
    return true;
  }   
  
}
