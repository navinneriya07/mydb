using System.IO;
using System.ComponentModel;
using System.Drawing;
using System.Text;


public class SimpleScriptWithParameters 
{ 
    [Start] 
		public void CancleRevise(string sProjectName) 
		{
			
			//Remember Selected Project
			string lastRevisedProject = "USER.LastTCRevisedProject";
            SettingNode oNode = new SettingNode();

            if (!oNode.ExistSetting(lastRevisedProject))
            {
                oNode.AddStringSetting(lastRevisedProject, new string[] { }, new string[] { }, ISettings.CreationFlag.Insert);
            }
			Settings oSetting = new Settings();
			string sProject = oSetting.GetStringSetting(lastRevisedProject,0);

			if (sProjectName == Path.GetFileNameWithoutExtension(sProject))
			{
				
				if (getAttribute("2001","2", sProject) == "RO")
				{
					//Reset RO Properties
					setAttribute("2001","2","", sProject);
					
					System.IO.File.SetAttributes(sProject, FileAttributes.ReadOnly);
					
					ActionCallingContext context1 = new ActionCallingContext();
					new CommandLineInterpreter().Execute("XPrjActionProjectClose", context1);
					
					ActionCallingContext context2 = new ActionCallingContext();
					context2.AddParameter("PROJECT", sProject);
					context2.AddParameter("RequestedOpenMode", "1");
					new CommandLineInterpreter(true).Execute("XPrjActionProjectOpen", context2);					
				}
			}
			
			oSetting.SetStringSetting(lastRevisedProject,"",0);
		} 
		
		public string getAttribute(String parameter, String index, String sProjectName)
        {
		
		
            string strAction = "Get_Property_Value_Selected_Project";
            String sVal = "unknown";

            ActionManager oAMnr = new ActionManager();
            Eplan.EplApi.ApplicationFramework.Action oAction = oAMnr.FindAction(strAction);
            if (oAction != null)
            {
                ActionCallingContext ctx = new ActionCallingContext();
                ctx.AddParameter("ID", parameter);
                ctx.AddParameter("Index", index);
                ctx.AddParameter("Language", "??_??");
				ctx.AddParameter("ProjectFile", sProjectName);
                bool bRet = oAction.Execute(ctx);
                if (bRet)
                {
                    ctx.GetParameter("Value", ref sVal);
                    String sLang = "";
                    ctx.GetParameter("Language", ref sLang);
                }
                else
                {
                    ctx.GetParameter("Value", ref sVal);
                    MessageBox.Show("The Action " + strAction + " ended with errors!\r\n Value: " + sVal, "PLM Teamcenter Connector Error");
                }
            }
            else
            {
                MessageBox.Show("The Action " + strAction + " is not defined!\r\n EPIS version must be 2.2.5.1538 or 2.3.5.1614 or newer!", "PLM Teamcenter Connector Error");
            }
            return sVal;
        }
		
		//Set Project attributes
		public string setAttribute(String parameter, String index, String value, String sProjectName)
        {
            string strAction = "XEsSetProjectPropertyAction";
            String sVal = "unknown";
				

            ActionManager oAMnr = new ActionManager();
            Eplan.EplApi.ApplicationFramework.Action oAction = oAMnr.FindAction(strAction);
            if (oAction != null)
            {
                ActionCallingContext ctx = new ActionCallingContext();
                ctx.AddParameter("PropertyId", parameter);
                ctx.AddParameter("PropertyIndex", index);
				ctx.AddParameter("PropertyValue", value);
                ctx.AddParameter("Language", "??_??");
				ctx.AddParameter("ProjectFile", sProjectName);
                bool bRet = oAction.Execute(ctx);
                if (bRet)
                {
                    ctx.GetParameter("Value", ref sVal);
                    String sLang = "";
                    ctx.GetParameter("Language", ref sLang);
                }
                else
                {
                    ctx.GetParameter("Value", ref sVal);
                    MessageBox.Show("The Action " + strAction + " ended with errors!\r\n Value: " + sVal, "PLM Teamcenter Connector Error");
                }
            }
            else
            {
                MessageBox.Show("The Action " + strAction + " is not defined!\r\n EPIS version must be 2.2.5.1538 or 2.3.5.1614 or newer!", "PLM Teamcenter Connector Error");
            }
            return sVal;
        }
		
		
}
