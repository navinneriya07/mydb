// Copyright 2015 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
// ==================================================
// Copyright 2012.
// Siemens Product Lifecycle Management Software Inc.
// All Rights Reserved.
// ==================================================
// Copyright 2015 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.

package com.teamcenter.edacallbacks;

import com.teamcenter.edabase.EDAException;
import com.teamcenter.edabase.model.DerivedItemNamingInfo;
import com.teamcenter.edabase.utils.TcEDALogger;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import org.apache.log4j.Logger;

/**
 * A java callback for naming Derived Item
 */
public class NameDerivedItemCallback
{
    /** log4j logger */
    private static final Logger s_logger = Logger.getLogger( NameDerivedItemCallback.class );

    /**
     * Constructor
     */
    public NameDerivedItemCallback()
    {

    }

    /**
     * This method provides implementation for 'nameDerivedItem' callback. While
     * performing Save As, Save, Check in operations, at the time of naming
     * Derived Item on Derived Item Table page, the operation 'nameDerivedItem'
     * callback will be executed to name Derived Item. The Derived Item name
     * constructed and returned from this method will be used as the default
     * name for the Derived Item. This callback will be once for each Derived
     * Item row on the Derived Item Table page. If this method returns null or
     * an empty string then the Derived Item name will be defaulted to the name
     * constructed using Derived Item configuration definition. This method
     * accepts two parameters, 'application' (application name) and
     * 'derivedItemNamingInfo' (DerivedItemNamingInfo class object). The class
     * DerivedItemNamingInfo has accessor methods to retrieve information about
     * current Derived Item's parent Item Id, sibling Derived Item names,
     * Derived Item configuration definition information etc.
     * 
     * @param application -- application name
     * @param derivedItemNamingInfo -- DerivedItemNamingInfo class object
     * @return -- returns Derived Item name constructed in this method or null
     *         otherwise
     * @throws EDAException
     */
    public String nameDerivedItem( String application,
            DerivedItemNamingInfo derivedItemNamingInfo )
        throws EDAException
    {
        /*
         * The below implementation is an example to name Derived Items. This
         * method names each Derived Item with parent Item Id appended with
         * single postfix letter. The postfix letter starts with letter 'A' and
         * will be incremented for each Derived Item under the same parent. For
         * example, if parent Item Id is 000456 with three Derived Items under
         * it, then the first Derived Item name under parent Item Id 000456 will
         * be 000456A and the next two Derived Item names will be 000456B and
         * 000456C. If there are many Derived Items under same parent and all
         * letters from 'A' to 'Z' are already used as postfix letters for
         * naming Derived Items then the next postfix letter would be the
         * character '['. This postfix letter continues to increment for the
         * next sibling Derived Item.
         */
        TcEDALogger.entering( "NameDerivedItemCallback", "nameDerivedItem" );

        String derivedItemName = null;
        String parentItemId = derivedItemNamingInfo.getParentItemID();
        char postFixLetter = 'A';
        boolean postFixLetterFound = false;

        try
        {
            String[] siblingDerivedItemNames = derivedItemNamingInfo.getSiblingDerivedItemNames();

            // Check for the sibling Derived Item names
            if( siblingDerivedItemNames != null
                    && siblingDerivedItemNames.length > 0 )
            {
                List<Character> postFixLettersList = new ArrayList<Character>();
                for( int i = 0; i < siblingDerivedItemNames.length; i++ )
                {
                    // Get the sibling Derived Item name
                    String siblingDerivedItemName = siblingDerivedItemNames[i];

                    // Get the last letter and add it to the postFixLettersList
                    char lastLetter = siblingDerivedItemName.charAt( siblingDerivedItemName.length() - 1 );
                    Character tempCharacter = new Character( lastLetter );
                    postFixLettersList.add( lastLetter );
                }

                /*
                 * The postFixLettersList may contain any characters. It may not
                 * be the continuous list. We cannot assume that the next
                 * postfix letter would be the next highest postfix from the
                 * existing postFixLettersList. For example, if there are three
                 * Derived Items under the same parent Item Id on Derived Items
                 * Table page, then for a second Derived Item, the sibling
                 * Derived Items can have 'A' and 'C' as postfix letters. In
                 * this case, the next postfix letter should be 'B' and not 'D'.
                 * So, we need to traverse the postFixLettersList to find the
                 * next postfix letter.
                 */

                // Increment postfix letter 'A', postFixLettersList.size() times
                for( int i = 0; i < postFixLettersList.size(); i++ )
                {
                    postFixLetter++;
                }

                for( int i = 0; i < postFixLettersList.size(); i++ )
                {
                    /*
                     * Check if the postfix letter already exists in the
                     * postFixLettersList
                     */
                    if( postFixLettersList.get( i ).charValue() == postFixLetter )
                    {
                        postFixLetterFound = true;
                        break;
                    }
                }

                if( !postFixLetterFound )
                {
                    /*
                     * If postfix letter not found in postFixLettersList then
                     * append postfix letter to parent Item Id
                     */
                    derivedItemName = parentItemId + postFixLetter;
                }
                else
                {
                    if( postFixLettersList.size() == 1 )
                    {
                        /*
                         * If postfix letter is found in postFixLettersList and
                         * the list size is 1 then decrement post fix letter and
                         * append it parent Item Id
                         */
                        postFixLetter--;
                        derivedItemName = parentItemId + postFixLetter;
                    }
                    else if( postFixLettersList.size() > 1 )
                    {
                        /*
                         * If the postFixLettersList list size is greather than
                         * 1 first sort the list
                         */
                        Collections.sort( postFixLettersList );

                        for( int i = 0; i < postFixLettersList.size() - 1; i++ )
                        {
                            // Get the characters at index i and i+1
                            Character charater1 = postFixLettersList.get( i );
                            Character charater2 = postFixLettersList.get( i + 1 );

                            char firstLetter = charater1.charValue();
                            char nextLetter = charater2.charValue();

                            /*
                             * Increment the character at index i and check with
                             * character at index i+1
                             */
                            firstLetter++;
                            if( firstLetter == nextLetter )
                            {
                                /*
                                 * If end of the list is reached then postfix
                                 * letter should be the first letter.
                                 */
                                if( i + 1 == postFixLettersList.size() - 1 )
                                {
                                    postFixLetter = 'A';
                                    derivedItemName = parentItemId
                                            + postFixLetter;
                                    break;
                                }
                            }
                            else
                            {
                                postFixLetter = firstLetter;
                                derivedItemName = parentItemId + postFixLetter;
                                break;
                            }
                        }
                    }
                }
            }
            else
            {
                /*
                 * If there are no sibling Derived Items, then this is the first
                 * Derived Item. Append postfix letter 'A' to the parent Item
                 * Id.
                 */
                derivedItemName = parentItemId + postFixLetter;
            }
        }
        catch( Exception e )
        {
            throw new EDAException( e );
        }

        TcEDALogger.exiting( "NameDerivedItemCallback",
                "nameDerivedItem" );

        return derivedItemName;
    }
}
