// Copyright 2015 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
// ==================================================
// Copyright 2009.
// Siemens Product Lifecycle Management Software Inc.
// All Rights Reserved.
// ==================================================
// Copyright 2015 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.

package com.teamcenter.edacallbacks;

import com.teamcenter.edabase.EDAConfiguration;
import com.teamcenter.edabase.EDAException;
import com.teamcenter.edabase.services.DefaultSOAService;
import com.teamcenter.edabase.utils.EDAExceptionUtils;
import com.teamcenter.edabase.utils.TcEDALogger;
import com.teamcenter.edaxsd.edaDesign.EDADesignType;
import com.teamcenter.fms.clientcache.proxy.FileCacheProxy;
import com.teamcenter.fms.util.FMSException;
import com.teamcenter.schemas.soa._2006_03.exceptions.ServiceException;
import com.teamcenter.services.strong.core.DataManagementService;
import com.teamcenter.services.strong.core.FileManagementService;
import com.teamcenter.services.strong.core._2006_03.FileManagement.FileTicketsResponse;
import com.teamcenter.services.strong.core._2007_06.DataManagement.RelationAndTypesFilter;
import com.teamcenter.services.strong.core._2007_09.DataManagement.ExpandGRMRelationsData2;
import com.teamcenter.services.strong.core._2007_09.DataManagement.ExpandGRMRelationsOutput2;
import com.teamcenter.services.strong.core._2007_09.DataManagement.ExpandGRMRelationsPref2;
import com.teamcenter.services.strong.core._2007_09.DataManagement.ExpandGRMRelationsResponse2;
import com.teamcenter.services.strong.core._2008_06.DataManagement.BOHierarchy;
import com.teamcenter.services.strong.core._2008_06.DataManagement.BOWithExclusionIn;
import com.teamcenter.services.strong.core._2008_06.DataManagement.DisplayableBOsOut;
import com.teamcenter.services.strong.core._2008_06.DataManagement.DisplayableSubBOsResponse;
import com.teamcenter.services.strong.query.SavedQueryService;
import com.teamcenter.services.strong.query._2006_03.SavedQuery.GetSavedQueriesResponse;
import com.teamcenter.services.strong.query._2006_03.SavedQuery.SavedQueryObject;
import com.teamcenter.services.strong.query._2007_06.SavedQuery.ExecuteSavedQueriesResponse;
import com.teamcenter.services.strong.query._2007_06.SavedQuery.SavedQueryInput;
import com.teamcenter.services.strong.query._2007_06.SavedQuery.SavedQueryResults;
import com.teamcenter.soa.client.Connection;
import com.teamcenter.soa.client.model.ModelObject;
import com.teamcenter.soa.client.model.strong.Dataset;
import com.teamcenter.soa.client.model.strong.ImanFile;
import com.teamcenter.soa.client.model.strong.ImanQuery;
import com.teamcenter.soa.client.model.strong.ItemRevision;
import com.teamcenter.soa.exceptions.NotLoadedException;
import java.io.File;
import java.io.FileReader;
import java.io.Reader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.Unmarshaller;
import org.apache.log4j.Logger;
import org.xml.sax.InputSource;

/**
 * A Java callback for postOpen operation.
 */
public class PostOpenCallback
{
    /** log4j logger */
    private static final Logger s_logger = Logger.getLogger( PostOpenCallback.class );

    public PostOpenCallback()
    {
    }

    /**
     * The callback method that - Reads schematic EDADesign 
     * opened by 'open' operation and fetches derived data 
     * associated with the design from Teamcenter. Derived data
     * contains both - derived items and derived datasets. 
     * The method then downloads the attached datafile in the
     * derived datasets to the working directory (staging 
     * directory). E.g. For schematic design opened, loads 
     * derived datasets and loads attached file 
     * like- schematicDrawing.pdf - in staging directory.
     * 
     * @param appName --- Application name (schematic, simulation, pcb)
     * @param desingFile -- EDADesign XML
     * @param statusFile -- Status XML
     * 
     */
    public void openDS( String application, String edaDesignFileName, String statusFile )
    {
        TcEDALogger.entering( "PostOpenCallback", "openDS" );
        EDADesignType edaDesign = null;
        try
        {
            // Get the EDADesign object using JAXB Utility from EDA Design XML
            edaDesign = ( (JAXBElement<EDADesignType>) unmarshalFile(
                    edaDesignFileName, "com.teamcenter.edaxsd.edaDesign" ) ).getValue();

            // Get SOA Service connection. This will be used to connect to
            // Teamcenter
            DefaultSOAService soaService = new DefaultSOAService();
            Connection connection = soaService.getConnection();

            com.teamcenter.services.strong.core.DataManagementService dmSoaService = com.teamcenter.services.strong.core.DataManagementService.getService( connection );

            // Fetch Item Revision from Teamcenter
            ItemRevision itemRev = getItemRev( edaDesign, connection );
            // Fetch possible subtypes of ItemRevision
            String[] itemRevSetsubTypes = getSubtypes( dmSoaService,
                    "ItemRevision" );
            // Fetch possible subtypes of Dataset
            String[] dataSetsubTypes = getSubtypes( dmSoaService, "Dataset" );
            List<ModelObject> edaItemRevList = null;
            edaItemRevList = getEDASchematicRev( itemRev, itemRevSetsubTypes,
                    dmSoaService );
            // Fetch Derived Item List for the EDA Schematic Revisions
            List<ModelObject> derivedItemList = getDerivedItemList(
                    dmSoaService, itemRevSetsubTypes, edaItemRevList );
            if( null != derivedItemList && derivedItemList.size() > 0 )
            {
                // Fetch Derived Datasets List for the Derived Items
                List<Dataset> derivedDatasets = getDerivedDatasets(
                        dmSoaService, dataSetsubTypes, derivedItemList );
                String downloadDir = getDownloadDirName( itemRev );
                // Download the files fetched from Teamcenter for the derived
                // datasets
                downloadFilesFromDatasets( derivedDatasets, downloadDir,
                        connection );
            }
            s_logger.debug( "Finished downloading derived dataset file" );
        }
        catch( Exception ex )
        {
            s_logger.error( ex.getMessage(), ex );
        }
    }

    /**
     * This method expands relation 'EDAHasDerivedDataset' on 
     * derived item objects and fetches derived datasets 
     * associated with those items. It accepts SOA 
     * DataManagementService object, an array of strings 
     * containing values of sub-types of dataset type ( so that
     * all types of dataset objects associated with the derived
     * items can be fetched ) and list of ItemRevision objects 
     * which are derived from the primary dataset ItemRevision 
     * using 'EDAHasDerivedItem' relation. To expand the 
     * 'EDAHasDerivedDataset' relation on item revisions, 
     * DataManagementService is used to communicate with Teamcenter
     * and fetch the data.
     * 
     * @param dmSoaService    - Teamcenter service to fetch data
     * @param dataSetsubTypes - Array of strings of Dataset 
     *                          subtypes' names.
     * @param derivedItemList - List of derived items from 
     *                          which derived datasets to be fetched.
     * @return List of datasets (derived datasets)
     * 
     */
    private List<Dataset> getDerivedDatasets(
            com.teamcenter.services.strong.core.DataManagementService dmSoaService,
            String[] dataSetsubTypes, List<ModelObject> derivedItemList )
    {
        ExpandGRMRelationsPref2 datasetRelsPref = new ExpandGRMRelationsPref2();
        datasetRelsPref.expItemRev = true;
        datasetRelsPref.returnRelations = true;

        RelationAndTypesFilter[] datasetRelsFilter = new RelationAndTypesFilter[1];
        datasetRelsFilter[0] = new RelationAndTypesFilter();
        datasetRelsFilter[0].relationTypeName = "EDAHasDerivedDataset";
        datasetRelsFilter[0].otherSideObjectTypes = dataSetsubTypes;
        datasetRelsPref.info = datasetRelsFilter;

        ExpandGRMRelationsResponse2 expandDatasetRevResp = dmSoaService.expandGRMRelationsForPrimary(
                derivedItemList.toArray( new ModelObject[0] ), datasetRelsPref );

        ExpandGRMRelationsOutput2[] datasetRelOutput = expandDatasetRevResp.output;
        List<Dataset> derivedDatasets = new ArrayList<Dataset>();
        for( int i = 0; i < datasetRelOutput.length; i++ )
        {
            ExpandGRMRelationsData2[] relData = datasetRelOutput[i].relationshipData;
            for( int j = 0; j < relData.length; j++ )
            {
                for( int k = 0; k < relData[j].relationshipObjects.length; k++ )
                {
                    Dataset ds = (Dataset) relData[j].relationshipObjects[k].otherSideObject;
                    derivedDatasets.add( ds );
                }
            }
        }
        return derivedDatasets;
    }

    /**
     * This method expands relation 'EDAHasDerivedItem' on given
     * ItemRevision object to fetch derived item revisions. The 
     * method accepts DataManagementService object, array of
     * strings containing sub-types of ItemRevision type and list
     * of ItemRevision objects for which the derived items are 
     * to be fetched. DataManagementService is used to expand
     * the relation on each of the item revisions and fetch
     * the derived items from Teamcenter
     * 
     * @param dmSoaService - Teamcenter service to fetch data
     * @param itemRevSetsubTypes - Array of ItemRevision subtypes
     * @param edaItemRevList - List of EDA Item Revision objects
     * @return - list of derived items
     */
    private List<ModelObject> getDerivedItemList(
            com.teamcenter.services.strong.core.DataManagementService dmSoaService,
            String[] itemRevSetsubTypes, List<ModelObject> edaItemRevList )
    {
        List<ModelObject> derivedItemList = new ArrayList<ModelObject>();
        ExpandGRMRelationsPref2 secItemRevRelsPref = new ExpandGRMRelationsPref2();
        secItemRevRelsPref.expItemRev = true;
        secItemRevRelsPref.returnRelations = true;

        RelationAndTypesFilter[] secItemRevRelsFilter = new RelationAndTypesFilter[1];
        secItemRevRelsFilter[0] = new RelationAndTypesFilter();
        secItemRevRelsFilter[0].relationTypeName = "EDAHasDerivedItem";
        secItemRevRelsFilter[0].otherSideObjectTypes = itemRevSetsubTypes;
        secItemRevRelsPref.info = secItemRevRelsFilter;

        ModelObject[] parentItemRevs = edaItemRevList.toArray( new ModelObject[0] );
        ExpandGRMRelationsResponse2 expandItemRevResp = dmSoaService.expandGRMRelationsForPrimary(
                parentItemRevs, secItemRevRelsPref );
        ExpandGRMRelationsOutput2[] itemRelOutput = expandItemRevResp.output;

        for( int i = 0; i < itemRelOutput.length; i++ )
        {
            ExpandGRMRelationsOutput2 outputIter = itemRelOutput[i];
            ExpandGRMRelationsData2[] relationshipItemRevData = outputIter.relationshipData;
            for( int j = 0; j < relationshipItemRevData.length; j++ )
            {
                ExpandGRMRelationsData2 relData = relationshipItemRevData[j];
                for( int k = 0; k < relData.relationshipObjects.length; k++ )
                {
                    derivedItemList.add( relData.relationshipObjects[k].otherSideObject );
                }
            }
        }
        return derivedItemList;
    }

    /**
     * This method retrieves ItemRevision of schematic type for
     * a parent ItemRevision. The method accepts an ItemRevision
     * object, array of strings containing values of sub-types
     * of ItemRevision type and instance of DataManagementService
     * (an SOA service). To fetch the ItemRevision which is of 
     * type schematic type, relation 'EDAHasSchematic' is 
     * expanded on the parent ItemRevision.
     * 
     * @param itemRev - ItemRevision object
     * @param itemRevSetsubTypes - Array of ItemRevision subtypes
     * @param dmSoaService - Teamcenter service to fetch data
     * @return
     * 
     */
    private List<ModelObject> getEDASchematicRev( ItemRevision itemRev,
            String[] itemRevSetsubTypes, DataManagementService dmSoaService )
    {
        ExpandGRMRelationsPref2 secItemRevRelsPref = new ExpandGRMRelationsPref2();
        secItemRevRelsPref.expItemRev = true;
        secItemRevRelsPref.returnRelations = true;

        RelationAndTypesFilter[] secItemRevRelsFilter = new RelationAndTypesFilter[1];
        secItemRevRelsFilter[0] = new RelationAndTypesFilter();
        secItemRevRelsFilter[0].relationTypeName = "EDAHasSchematic";
        secItemRevRelsFilter[0].otherSideObjectTypes = itemRevSetsubTypes;
        secItemRevRelsPref.info = secItemRevRelsFilter;

        ModelObject[] parentItemRevs = new ModelObject[1];
        parentItemRevs[0] = itemRev;
        ExpandGRMRelationsResponse2 expandItemRevResp = dmSoaService.expandGRMRelationsForPrimary(
                parentItemRevs, secItemRevRelsPref );
        ExpandGRMRelationsOutput2[] edaSchemItemOutput = expandItemRevResp.output;
        List<ModelObject> edaSchemItemRevList = new ArrayList<ModelObject>();

        for( int i = 0; i < edaSchemItemOutput.length; i++ )
        {
            ExpandGRMRelationsOutput2 outputIter = edaSchemItemOutput[i];
            ExpandGRMRelationsData2[] relEDASchemItemRevData = outputIter.relationshipData;
            for( int j = 0; j < relEDASchemItemRevData.length; j++ )
            {
                ExpandGRMRelationsData2 relData = relEDASchemItemRevData[j];
                for( int k = 0; k < relData.relationshipObjects.length; k++ )
                {
                    edaSchemItemRevList.add( relData.relationshipObjects[k].otherSideObject );
                }
            }
        }
        return edaSchemItemRevList;
    }

    /**
     * This method fetches the sub-types for a parent type
     * provided to it. It uses DataManagementService instance
     * to communicate with Teamcenter.
     *  
     * @param dmSoaService - Teamcenter service to fetch data
     * @param parentType   - The type for which sub types
     *                       should be fetched
     * @return - Array of strings.
     * @throws ServiceException
     * @unpublished
     */
    private String[] getSubtypes(
            com.teamcenter.services.strong.core.DataManagementService dmSoaService,
            String parentType )
        throws ServiceException
    {
        BOWithExclusionIn[] input = new BOWithExclusionIn[1];
        input[0] = new BOWithExclusionIn();
        input[0].boTypeName = parentType;
        input[0].exclusionBOTypeNames = new String[0];

        DisplayableSubBOsResponse respForDatasetSubtypes = dmSoaService.findDisplayableSubBusinessObjects( input );
        DisplayableBOsOut[] bosOut = respForDatasetSubtypes.output;
        BOHierarchy[] hierarchy = bosOut[0].displayableBOTypeNames;

        String[] subTypes = null;
        if( null != hierarchy && hierarchy.length > 0 )
        {
            subTypes = new String[hierarchy.length];
            for( int i = 0; i < hierarchy.length; i++ )
            {
                subTypes[i] = hierarchy[i].BOName;
            }
        }
        return subTypes;
    }

    /**
     * This method returns ItemRevision in an EDADesign. The SOA
     * service-SavedQueryService is used to execute the saved 
     * query - 'Item Revision...' in Teamcenter. Criteria 
     * 'Item Id' and 'Revision' are used to execute the query. 
     * The values for these criteria are retrieved from the input
     * EDADesign. The connection required to communicate with
     * Teamcenter is provided by input Connection 
     * (SOA client connection) object.
     * 
     * @param edaDesign  - EDADesign in operation
     * @param connection - Connection obejct used to
     *                     connect to Teamcenter
     * @return - ItemRevision object
     * @throws EDAException
     * @throws ServiceException
     * @throws NotLoadedException
     * @unpublished
     */
    private ItemRevision getItemRev( EDADesignType edaDesign,
            Connection connection )
        throws EDAException
    {

        ItemRevision itemRev = null;
        SavedQueryService savedQueryService = SavedQueryService.getService( connection );
        GetSavedQueriesResponse savedQueriesRes = null;
        ImanQuery inputQuery = null;
        try
        {
            savedQueriesRes = savedQueryService.getSavedQueries();
            SavedQueryObject[] savedQueries = savedQueriesRes.queries;

            // Use saved query for Item Revision. Use criteria for
            // Item ID and Revision to fetch Item Revision
            for( int i = 0; i < savedQueries.length; i++ )
            {
                ImanQuery query = savedQueries[i].query;
                String qname = query.get_query_name();
                if( ( "Item Revision..." ).equals( qname ) )
                {
                    inputQuery = query;
                    break;
                }
            }
            List<String> criteriaName = new ArrayList<String>();
            List<String> criteriaValue = new ArrayList<String>();

            criteriaName.add( "Item ID" );
            criteriaValue.add( edaDesign.getCCA().getItemId() );

            criteriaName.add( "Revision" );
            criteriaValue.add( edaDesign.getCCA().getRevId() );

            SavedQueryInput queryInput = new SavedQueryInput();
            queryInput.query = inputQuery;
            queryInput.maxNumToInflate = -1;
            queryInput.entries = criteriaName.toArray( new String[0] );
            queryInput.values = criteriaValue.toArray( new String[0] );

            SavedQueryInput[] inputs = new SavedQueryInput[1];
            inputs[0] = queryInput;
            ExecuteSavedQueriesResponse sqResp = savedQueryService.executeSavedQueries( inputs );
            SavedQueryResults[] results = sqResp.arrayOfResults;
            List<ModelObject> modelObjs = Arrays.asList( results[0].objects );
            if( modelObjs.size() == 0 )
            {
                EDAExceptionUtils.throwEDAException( "getItemRev:: No Item revision found for EDA design in the operation..." );
            }
            itemRev = (ItemRevision) modelObjs.get( 0 );
        }
        catch( ServiceException e )
        {
            EDAExceptionUtils.throwEDAException( "getItemRev:: Failed to fetch Item revision" ); //$NON-NLS-1$
        }
        catch( NotLoadedException e )
        {
            EDAExceptionUtils.throwEDAException( "getItemRev:: Failed to fetch Item revision" ); //$NON-NLS-1$
        }
        return itemRev;
    }

    /**
     * The method iterates through list of 'Dataset' objects
     * input to it and extracts list of attached files 
     * (ImanFile objects) in each of the object. 
     * FileManagementService is used to fetch these files
     * from Teamcenter. The FileManagementService creates read
     * tickets on the files and these read tickets are used fetch
     * UIDs of the files using FileCacheProxy instance. Using
     * these UIDs, the files are then downloaded from 
     * Teamcenter to desired location - 'downloadDir' which is
     * input to the method as a parameter.
     * 
     * @param datasets    - List of datasets
     * @param downloadDir - the directory where the attached 
     *                      files from the datasets to be 
     *                      downloaded
     * @param connection  - Connection obejct used to connect to Teamcenter.
     * @throws EDAException
     */
    private void downloadFilesFromDatasets( List<Dataset> datasets,
            String downloadDir, Connection connection )
        throws EDAException
    {

        Iterator<Dataset> dsItr = datasets.iterator();
        FileCacheProxy fccProxy = null;

        if( datasets.size() < 0 )
        {
            s_logger.info( "downloadFilesFromDatasets:: The datasets list is empty...No files will be downloaded." );
        }

        if( null == downloadDir || downloadDir.length() == 0 )
        {
            s_logger.info( "downloadFilesFromDatasets:: Download directory not specified..." );
        }

        List<ImanFile> externalFiles = new ArrayList<ImanFile>();
        Map<String, String> fileNameMap = new HashMap<String, String>();

        while( dsItr.hasNext() )
        {
            Dataset ds = dsItr.next();
            List<ImanFile> files = getFileList( ds );
            for( Iterator<ImanFile> fileItr = files.iterator(); fileItr.hasNext(); )
            {
                try
                {
                    ImanFile f = fileItr.next();
                    externalFiles.add( f );
                    String fname = f.get_original_file_name();
                    fileNameMap.put( f.getUid(), fname );
                }
                catch( NotLoadedException e )
                {
                    s_logger.warn( e.getMessage(), e );
                }
            }
        }

        ImanFile[] externalFilesArray = externalFiles.toArray( new ImanFile[0] );
        FileManagementService fmService = FileManagementService.getService( connection );
        FileTicketsResponse response = fmService.getFileReadTickets( externalFilesArray );

        // Make sure we got tickets back.
        if( response.tickets.isEmpty() )
        {
            s_logger.info( "Zero tickets returned from getFileReadTickets" );
            System.out.println( "Zero tickets returned from getFileReadTickets" );
            // This happens when there is an error getting all files
            return;
        }

        // Get the tickets from the response.
        // We need to construct 2 arrays at this point. One
        // containing the ticket IDs, and the other containing
        // the filenames we want to use for the downloaded files.
        // The ordering of these HAS TO match so that the files
        // will be downloaded with the proper filenames.

        String[] tickets = new String[response.tickets.size()];
        String[] filenames = new String[response.tickets.size()];
        int cntr = 0;

        Iterator ticketIter = response.tickets.keySet().iterator();
        while( ticketIter.hasNext() )
        {
            ImanFile currFile = (ImanFile) ticketIter.next();

            // We still need an array of ticket strings to do the
            // actual download.
            tickets[cntr] = (String) response.tickets.get( currFile );
            filenames[cntr] = fileNameMap.get( currFile.getUid() );

            ++cntr;
        }

        try
        {
            fccProxy = new FileCacheProxy();
            fccProxy.Init();
            String[] uids = fccProxy.RegisterTickets( tickets );
            fccProxy.DownloadFilesToLocation( "IMD", null, null, uids,
                    downloadDir, filenames );
        }
        catch( FMSException e )
        {
            EDAExceptionUtils.throwEDAException( e.getMessage() );
        }
    }

    /**
     * The method retrieves list of ImanFile objects from the 
     * input 'Dataset' object
     * 
     * @param ds - Dataset
     * @return - List of files derived from dataset
     * @throws EDAException
     * 
     */
    private List<ImanFile> getFileList( Dataset ds )
        throws EDAException
    {
        List<ImanFile> fileList = new ArrayList<ImanFile>();
        try
        {
            ModelObject[] refList = ds.get_ref_list();
            for( int i = 0; i < refList.length; i++ )
            {
                if( refList[i] instanceof ImanFile )
                {
                    fileList.add( (ImanFile) refList[i] );

                }
            }
        }
        catch( Exception e )
        {
            EDAExceptionUtils.throwEDAException( e );
        }
        return fileList;
    }

    /**
     * The method returns the directory path where files from 
     * derived datasets for the input ItemRevision are to be 
     * downloaded. It suffixes item id (fetched from 
     * ItemRevision supplied) to the staging directory path 
     * (fetched from EDAConfiguration) and forms the 
     * download directory path.
     * 
     * @param itemRev - ItemRevision object
     * @return - Staging directory where design is stored
     * @throws EDAException
     */
    private String getDownloadDirName( ItemRevision itemRev )
        throws EDAException
    {
        String downloadDirName = null;
        try
        {
            downloadDirName = EDAConfiguration.getInstance().getStagingDirName()
                    + File.separator
                    + "latest"
                    + File.separator
                    + itemRev.get_item_id();
        }
        catch( NotLoadedException e )
        {
            EDAExceptionUtils.throwEDAException( e.getMessage() );
        }
        return downloadDirName;
    }

    /**
     * This method extracts object from the XML file provided 
     * to it. The namespace value, provided as in input, is 
     * namespace of the object which is marshaled in the XML 
     * file. This method is used to fetch the EDADesign and 
     * EDAStatus objects from EDADesign XML and EDA Status XML.
     * It internally uses JAXB API to extract the object from XML.
     * 
     * @param fileName  - the name of the file to be un-marshaled
     *                    and from which the object is to be extracted.
     * @param namespace - the namespace of the object to be extracted
     * @return The object extracted from the input xml file.
     * @throws EDAException
     * 
     */
    private Object unmarshalFile( String fileName, String namespace )
        throws EDAException
    {
        Object object = null;
        if( fileName == null )
        {
            EDAExceptionUtils.throwEDAException( "unmarshalFile:: Null file name." ); //$NON-NLS-1$
        }
        try
        {
            FileReader fileReader = new FileReader( fileName );
            object = unmarshal( fileReader, namespace );
        }
        catch( Exception e )
        {
            EDAExceptionUtils.throwEDAException( e.getMessage() );
        }
        return object;
    }

    /**
     * This method is called from method 'unmarshalFile'. 
     * It uses JAXB API to extract object from the input 
     * Reader object.
     * 
     * @param reader -- File reader
     * @param namespace - Namespace of the object
     * @return The extracted object
     * @throws EDAException
     * 
     */
    private Object unmarshal( Reader reader, String namespace )
        throws EDAException
    {
        Object object = null;
        try
        {
            JAXBContext jc = JAXBContext.newInstance( namespace );
            Unmarshaller unmarshaller = jc.createUnmarshaller();

            InputSource inputSource = new InputSource( reader );
            object = unmarshaller.unmarshal( inputSource );

            reader.close();
        }
        catch( Exception e )
        {
            EDAExceptionUtils.throwEDAException( e );
        }
        return object;
    }
}
