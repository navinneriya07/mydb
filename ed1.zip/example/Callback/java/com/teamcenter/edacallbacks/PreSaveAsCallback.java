// Copyright 2015 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
// ==================================================
// Copyright 2015.
// Siemens Product Lifecycle Management Software Inc.
// All Rights Reserved.
// ==================================================
// Copyright 2015 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.

package com.teamcenter.edacallbacks;

import com.teamcenter.edabase.EDAConfiguration;
import com.teamcenter.edabase.EDAException;
import com.teamcenter.edabase.utils.TcEDALogger;
import java.io.File;
import java.io.IOException;
import java.util.Properties;
import org.apache.log4j.Logger;

/**
 * Java callback for preSaveAs operation. It is configured in
 * %TCEDACLIENT%\exampleSchematic_edadef.xml
 * 
 */
public class PreSaveAsCallback
 {
    /** log4j logger */
    private static final Logger s_logger = Logger.getLogger( PreSaveAsCallback.class );

    // String constant containing script file name executed
    // by the callback
    static final String SCRIPT_FILE_NAME = "createDataFile.bat";

    // String constant containing path for the design file
    static final String DESIGN_FILE_PATH = "d:" + File.separator
            + "drawing.pdf";

    // String constant for TC EDA root
    static final String DEFAULT_TCECAD_ROOT = "d:" + File.separator + "Siemens"
            + File.separator + "Teamcenter8" + File.separator + "eda";

    // String constant for the path of the script from where
    // the script is executed by the callback
    static final String SCRIPT_PATH = "example" + File.separator + "Callback"
            + File.separator + "scripts" + File.separator;

    // String constant containing value for client schematic
    // application type
    static final String APP_SCHEMATIC = "exampleSchematic";

    // String constant containing value for client PCB
    // application type
    static final String APP_PCB = "examplePcb";

    public PreSaveAsCallback()
    {
    }

    /**
     * The method provides implementation for preSaveAs callback. 
     * When 'save as' action is performed, control comes to this
     * callback before the save as operation. This callback adds 
     * a PDF file for derived dataset so that it is created as an 
     * attachment of the derived dataset. This method receives the
     * parameters application name and eda design file name. It 
     * fetches staging directory location. It executes a runtime 
     * script which puts PDF file in the staging directory. The save
     * as operation will then upload this PDF as an attachment of the
     * derived dataset.
     * 
     * @param application -- Application name
     * @param edaDesignFileName -- EDADesign XML
     * @throws EDAException
     */
    public void createDerivedDataFile( String application,
            String edaDesignFileName )
        throws EDAException
    {
        TcEDALogger.entering( "PreSaveAsCallback", "createDerivedDataFile" );
        if( !( APP_SCHEMATIC.equals( application ) ) )
        {
            s_logger.info( "The application for the 'preSaveAs'callback was called is not exampleSchematic. "
                    + "Exiting the callback....." );
        }
        try
        {
            String stagingDir = EDAConfiguration.getInstance().getStagingDirName();
            Properties props = System.getProperties();
            String TCECAD_ROOT = props.getProperty( "TCEDAECAD_ROOT" );
            if( null == TCECAD_ROOT || ( "" ).equals( TCECAD_ROOT ) )
            {
                TCECAD_ROOT = DEFAULT_TCECAD_ROOT;
            }
            String scriptCommand = TCECAD_ROOT + File.separator + SCRIPT_PATH
                    + SCRIPT_FILE_NAME;
            Runtime rt = Runtime.getRuntime();
            String[] command = { "cmd", "/c", "start", scriptCommand,
                    DESIGN_FILE_PATH, stagingDir };
            rt.exec( command );
        }
        catch( IOException e )
        {
            s_logger.error(
                    "Error running bat file for derived data file creation: "
                            + e.getMessage(), e );
        }
    }
}
