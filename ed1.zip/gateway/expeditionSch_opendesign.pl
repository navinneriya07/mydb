#!/usr/bin/perl

# Copyright 2010 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
# =============================================================
# Copyright 2008.
# Siemens Product Lifecycle Management Software Inc.
# All Rights Reserved.
# =============================================================
# Copyright 2010 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
#
# This script is called by Gateway callback for openDesign and reOpenDesign  
#
# ==============================================================

# validate inputs

if( @ARGV != 1)
{
    print "Usage: expeditionSch_opendesign <design folder>\n";
    print "ARGV[1]".$ARGV[1]."\n";
    exit 1;
}

# get list of files with file extension .prj
opendir( DESIGN_DIR, $ARGV[0] ) || die "Cannot open $ARGV[0]: $!";
@prjFiles=grep( /\.prj$/i, readdir DESIGN_DIR );
$prjSize=@prjFiles;
#if the Project extension is not prj, it is a EE2005 Design which has dproj extension
my $isEE2005Version = 0 ;
if( $prjSize == 0 )
{
    rewinddir DESIGN_DIR;
    @prjFiles=grep( /\.dproj$/i, readdir DESIGN_DIR );
    $prjSize=@prjFiles;
    if( $prjSize > 0 )
    {
        $isEE2005Version = 1;
    }
}
close( DESIGN_DIR );

# get/select a prj file
$schePrjFile="";
if( $prjSize == 1 )
{
    $schePrjFile=$prjFiles[0];
    
}
elsif ( $prjSize == 0 )
{
    print "No DXDesign Project (prj) file can be found in $ARGV[0] \n";
}
else
{
    print qq(\nSelect an DXDesign schematic design (PRJ) file from the following list\n\n);
    foreach( @prjFiles )
    {
        print "$_\n";
    }

    print "\n\n";

    foreach( @prjFiles )
    {
        $schePrjFile=pickFile( $_ );
        last if( $schePrjFile );
    }
}

if ( $schePrjFile )
{
    $scheprjPath = "$ARGV[0]\\$schePrjFile";
    # $schePrjFile carries path of the design folder *.prj
    if( $isEE2005Version != 1 )
    {
        # For EE2007.2
        # change the stat of file \\database\\sesid in design folder from readonly to writeabel
        # If the design folder has database\sesid, the method will work on it.
        changefilestat($scheprjPath);
        
        # For EE2007.6 and EE7.9
        # delete the adr file in archiveDir\database\cdbsvr so the copy design can be opened.
        # If the design folder has database\cdbsvr, the method will work on it.
        Delete_adr_File($ARGV[0]);
    }
        
    $cmd="viewdraw $scheprjPath";
    print "\nExecuting ...\n  $cmd\n";
    system( $cmd );

    exit 0;
}
else 
{
    print "\nNo DXDesign Project (prj) file is selected.\nPlease check if the design folder is valid or not\n<hit RETURN to continue>";
    $tempWait=<STDIN>;
    exit 1;
}

sub pickFile 
{
    my ($curerntFile, $yesno);
    ($currentFile)=@_;
    $yesno = "";
    while ( $yesno ne 'y' and $yesno ne 'n' )
    {
        print "$currentFile (y/n): ";
        $yesno=<STDIN>;
        chomp $yesno;    # remove new line character
        $yesno = lc( $yesno );
    }

    if( $yesno eq 'y' ) 
    {
       return( $currentFile );   
    }
    else 
    {
        return( "" );
    }
}


#change the state of file sesid to readwrite, so the design can be opened successfully
#the structure of the design is:

#..\\designfolder\\design.prj
#..\\designfolder\\database\\sesid
#..\\designfolder\\...
sub changefilestat
{
    my $file = $_[0];                                # $file =~ s/\/[^\/]+.prj$/\/database\/sesid/i
    if($file =~ s/\\[^\\]+.prj$/\\database\\sesid/i )#replace the sub string from "\\design.prj" to 
                                                     #"\\database\\sesid" or from "/design.prj" to "/database/sesid"
    {    
        if(-f $file)
        {

            my @mode = (stat($file))[2];
            if($mode[0]==0100444) # 0100444 readonly 0100666 readwrite
            {
               chmod 0100666, "$file";
            }
        }
        
    }
    
}

sub Delete_adr_File
{
    $prjPath = $_[0];
    my $adrFilePath = "$prjPath\\database\\cdbsvr\\sAddress.adr";
    if( -e $adrFilePath )
    {
        print "\nDelete sAddress at $adrFilePath for opening the design.\n";
        unlink "$adrFilePath";
    }
}
