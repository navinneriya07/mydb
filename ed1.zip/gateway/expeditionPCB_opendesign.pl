#!/usr/bin/perl

# Copyright 2015 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
# =============================================================
# Copyright 2008.
# Siemens Product Lifecycle Management Software Inc.
# All Rights Reserved.
# =============================================================
# Copyright 2015 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
#
# This script is called by Gateway callback for openDesign and reOpenDesign  
#
# ==============================================================

# validate inputs
if( @ARGV != 1)
{
    print "Usage: expeditionPCB_opendesign <design folder>\n";
    exit 1;
}

# get list of files with file extension .PCB
opendir( DESIGN_DIR, $ARGV[0] ) || die "Cannot open $ARGV[0]: $!";
@PCBFiles=grep( /\.PCB$/i, readdir DESIGN_DIR );
$PCBSize=@PCBFiles;
close( DESIGN_DIR );


# get/select a PCB file
$EXPPCBFile="";
if( $PCBSize == 1 )
{
    $EXPPCBFile=$PCBFiles[0];
    
}
elsif ( $PCBSize == 0 )
{
    print "No design (PCB) file can be found in $ARGV[0]\n";
}
else
{
    print qq(\nSelect an ExpeditionPCB Design (PCB) file from the following list\n\n);
    foreach( @PCBFiles )
    {
        print "$_\n";
    }

    print "\n\n";

    foreach( @PCBFiles )
    {
        $EXPPCBFile=pickFile( $_ );
        last if( $EXPPCBFile );
    }
}

if ( $EXPPCBFile )
{
    $exppcbpath = "$ARGV[0]\\$EXPPCBFile";
    # ${ARGV[0]} carries path of the design folder
    $cmd="start ExpeditionPCB ${exppcbpath}";
    print "\nExecuting ...\n  $cmd\n";
    system( $cmd );
    exit 0;
}
else 
{
    print "\nNo design (PCB) file is selected.\nPlease check if the design folder is valid or not\n<hit RETURN to continue>";
    $tempWait=<STDIN>;
    exit 1;
}

sub pickFile 
{
    my ($curerntFile, $yesno);
    ($currentFile)=@_;
    $yesno = "";
    while ( $yesno ne 'y' and $yesno ne 'n' )
    {
        print "$currentFile (y/n): ";
        $yesno=<STDIN>;
        chomp $yesno;    # remove new line character
        $yesno = lc( $yesno );
    }

    if( $yesno eq 'y' ) 
    {
       return( $currentFile );   
    }
    else 
    {
        return( "" );
    }
}
