#!/usr/bin/perl

# Copyright 2015 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
# =============================================================
# Copyright 2008.
# Siemens Product Lifecycle Management Software Inc.
# All Rights Reserved.
# =============================================================
# Copyright 2015 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
#
# This script is called by Gateway callback for openDesign and reOpenDesign  
#
# ==============================================================

# validate inputs
if( @ARGV != 1)
{
    print "Usage: orcadcapture_opendesign <design folder>\n";
    exit 1;
}

# get list of files with file extension .dsn
opendir( DESIGN_DIR, $ARGV[0] ) || die "Cannot open $ARGV[0]: $!";
@dsnFiles=grep( /\.dsn$/i, readdir DESIGN_DIR );
$dsnSize=@dsnFiles;
close( DESIGN_DIR );

# get/select a dsn file
$captureDsnFile="";
if( $dsnSize == 1 )
{
    $captureDsnFile=$dsnFiles[0];
    
}
elsif ( $dsnSize == 0 )
{
    print "\nNo design (dsn) file can be found in $ARGV[0]\n";
}
else
{
    print qq(\nSelect an OrCAD Capture Design (DSN) file from the following list to open\n\n);
    foreach( @dsnFiles )
    {
        print "$_\n";
    }

    print "\n\n";

    foreach( @dsnFiles )
    {
        $captureDsnFile=pickFile( $_ );
        last if( $captureDsnFile );
    }
}

if ( $captureDsnFile )
{
    my $cdsRoot = $ENV{"CDSROOT"};
    my $command = "$cdsRoot\\tools\\capture\\capture";
    my $sourceFile = "${ARGV[0]}\\${captureDsnFile}";
    print "\nExecuting ...\n  $command $sourceFile\n";
    my @args = ( $command, $sourceFile );
    system( @args );
    exit 0;
}
else 
{
    print "\nCapture was not started because no design (dsn) file was selected or existed\n";
    print "\n<hit RETURN to continue>";
    $tempWait=<STDIN>;
    exit 1;
}

sub pickFile 
{
    my ($curerntFile, $yesno);
    ($currentFile)=@_;
    $yesno = "";
    while ( $yesno ne 'y' and $yesno ne 'n' )
    {
        print "$currentFile (y/n): ";
        $yesno=<STDIN>;
        chomp $yesno;    # remove new line character
        $yesno = lc( $yesno );
    }

    if( $yesno eq 'y' ) 
    {
       return( $currentFile );   
    }
    else 
    {
        return( "" );
    }
}
