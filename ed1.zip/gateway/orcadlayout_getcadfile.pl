#!/usr/bin/perl

# Copyright 2015 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
# =============================================================
# Copyright 2008.
# Siemens Product Lifecycle Management Software Inc.
# All Rights Reserved.
# =============================================================
# Copyright 2015 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
#
# This script is an EDA Gateway callback for extractCADFromPCB
#
#==============================================================

# validate inputs
if( @ARGV != 2)
{
    print "Usage: orcadlayout_getcadfile <design folder> <CAD file folder>\n";
    exit 1;
}

if( opendir( CAD_DIR, $ARGV[1] ) )
{
    @cadFiles=grep( !/^\.\.?$/, readdir CAD_DIR );
    close( CAD_DIR );
    if( @cadFiles > 0 )
    {
       print "\nError: Failed to remove the old CAD (min) file\n";
       print "Please manually delete files in ${ARGV[1]} and then continue.\n";
       $tempWait=<STDIN>;
    }
}
else
{
    system( "md", "${ARGV[1]}" );
}

opendir( DESIGN_DIR, $ARGV[0] ) || die "Cannot open $ARGV[0]: $!";
@maxFiles=grep( /\.max$/i, readdir DESIGN_DIR );
$maxSize=@maxFiles;
close( DESIGN_DIR );

# get/select a max file
$layoutBrdFile="";
if( $maxSize == 1 )
{
    $layoutBrdFile=$maxFiles[0];

}
elsif ( $maxSize == 0 )
{
    print "\nNo max file can be found in $ARGV[0] \n";
}
else
{
    print qq(\nSelect an OrCAD Layout board (MAX) file from the following list\n);
    print qq(\nThis is required to export CAD (min) file\n\n);
    foreach( @maxFiles )
    {
        print "$_\n";
    }

    print "\n\n";

    foreach( @maxFiles )
    {
        $layoutBrdFile=pickFile( $_ );
        last if( $layoutBrdFile );
    }
}

if ( $layoutBrdFile )
{
    my $cdsRoot = $ENV{"CDSROOT"};
    my $command = "$cdsRoot\\tools\\layout\\maxminw";
    my $sourceFile = "${ARGV[0]}\\${layoutBrdFile}";
    my $targetFile = "${ARGV[1]}\\orcadLayout.min";
    print "\nExecuting ...\n  $command $sourceFile $targetFile\n";

    my @args = ( $command, $sourceFile, $targetFile );
    system( @args );
    exit 0;
}
else
{
    print "\nNo valid board (max) file was selected or available for exporting CAD (min) file.\n";
    print "You will be asked to select CAD (min) file directly from your file system.\n";
    print "Please make sure to select a right CAD (min) file or cancel the operation.\n";
    print "\n<hit RETURN to continue>";
    $tempWait=<STDIN>;
    exit 1;
}

sub pickFile
{
    my ($currentFile, $yesno);
    ($currentFile)=@_;
    $yesno = "";
    while ( $yesno ne 'y' and $yesno ne 'n' )
    {
        print "$currentFile (y/n): ";
        $yesno=<STDIN>;
        chomp $yesno;    # remove new line character
        $yesno = lc( $yesno );
    }

    if( $yesno eq 'y' )
    {
       return( $currentFile );
    }
    else
    {
        return( "" );
    }
}
