#!/usr/bin/perl
use File::Basename;

# Copyright 2008 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
# =============================================================
# Copyright 2008.
# Siemens Product Lifecycle Management Software Inc.
# All Rights Reserved.
# =============================================================
# Copyright 2008 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
#
# This script is an EDA Gateway callback for extractCADFromPCB
#
#==============================================================

# validate inputs
#$get = <STDIN>;
if( @ARGV != 2)
{
    print "Usage: expeditionPCB_getcadfile <design folder> <CAD file folder>\n";
    exit 1;
}
my $InputPath = $ARGV[0];
my $OutputPath = $ARGV[1];
if( opendir( CAD_DIR, $OutputPath ) )
{
    @cadFiles=grep( !/^\.\.?$/, readdir CAD_DIR );
    if( @cadFiles > 0 )
    {
       system( "del /Q /F /S ${ARGV[1]}\\*" );
    }
    close( CAD_DIR );
}
else
{
    system( "md ${ARGV[1]}" );
}

#get design folder ,get PCB file
opendir( DESIGN_DIR, $InputPath ) || die "Cannot open $InputPath: $!";
@prjFiles=grep( /\.pcb$/i, readdir DESIGN_DIR );
$prjSize=@prjFiles;
close( DESIGN_DIR );


# Check a PCB file
$ExpeditionPCBFile="";
if( $prjSize == 1 )
{
    $ExpeditionPCBFile=$prjFiles[0];
    
}
elsif ( $prjSize == 0 )
{
    print "\nNo PCB file can be found in $InputPath \n";
}
else
{
    print qq(\nSelect an DXDesign Project (PCB) file from the following list\n);
    print qq(\nThis is required to export CAD (edif) file\n\n);
    foreach( @prjFiles )
    {
        print "$_\n";
    }

    print "\n\n";

    foreach( @prjFiles )
    {
        $ExpeditionPCBFile=pickFile( $_ );
        last if( $ExpeditionPCBFile );
    }
}



if ( $ExpeditionPCBFile )
{
    $ExpeditionPCBPath = "$InputPath\\$ExpeditionPCBFile";
    my ($designName,$designDIR,$ext) = fileparse($ExpeditionPCBPath, qr/\.[^.]*/);
    
    my $SddCommonBin = $ENV{"SDD_COMMON_BIN"};
    my $commandLayoutDB2HKP = "$SddCommonBin\\LayoutDB2HKP.exe";
    my $commandCellDB2HKP = "$SddCommonBin\\CellDB2HKP.exe";
    my $commandJobPrefsDB2HKP = "$SddCommonBin\\JobPrefsDB2HKP.exe";
    my $commandNetClassDB2HKP = "$SddCommonBin\\NetClassDB2HKP.exe";
    my $commandNetPropsDB2HKP = "$SddCommonBin\\NetPropsDB2HKP.exe";
    my $commandPadstackDB2HKP = "$SddCommonBin\\PadstackDB2HKP.exe";
    my $commandPartsDB2HKP = "$SddCommonBin\\PartsDB2HKP.exe";
    
    #for space in path issue:
    $commandLayoutDB2HKP = Win32::GetShortPathName( $commandLayoutDB2HKP );
    $commandCellDB2HKP = Win32::GetShortPathName( $commandCellDB2HKP );
    $commandJobPrefsDB2HKP = Win32::GetShortPathName( $commandJobPrefsDB2HKP );
    $commandNetClassDB2HKP = Win32::GetShortPathName( $commandNetClassDB2HKP );
    $commandNetPropsDB2HKP = Win32::GetShortPathName( $commandNetPropsDB2HKP );
    $commandPadstackDB2HKP = Win32::GetShortPathName( $commandPadstackDB2HKP );
    $commandPartsDB2HKP = Win32::GetShortPathName( $commandPartsDB2HKP );
    
    
    #test whether the hkp file is encrypted
    #create an hkp file for lmc
    my $randString = int( rand(100) * 1000 );
    my $HKPTestFile="$OutputPath\\Test$randString.hkp";
    my $LMCTestFile="$OutputPath\\Test$randString.lmc";
    my $LOGTestFile = "$OutputPath\\HKP2LMCDB.log";
    my $rt = open( FILE , ">>$HKPTestFile");
    if($rt == 0 )
    {
        print "\n Fail to create test file:$HKPTestFile \n";
        print "\n <hit RETURN to continue>";
        $tempWait=<STDIN>;
        exit(1);
    }
    else
    {
        syswrite( FILE , "\n.FILETYPE    LIBRARY_MANAGER_CATALOG\n.LIBRARY_KEY 947195107");
    }
    close( FILE );
    
    #use HKP2LMCDB.exe to convert hkp file to lmc file
    printf "\nTest whether the HKP files are encrypted.\n";
    my $commandHKP2LMCDB="$SddCommonBin\\HKP2LMCDB.exe";
    $commandHKP2LMCDB = Win32::GetShortPathName( $commandHKP2LMCDB );
    
    $cmd="$commandHKP2LMCDB -i $HKPTestFile -o $LMCTestFile -l $LOGTestFile";
    print "\nExecuting ...\n  $cmd \n";
    system( $cmd );
   
    unlink $HKPTestFile ;
    unlink $LOGTestFile ;
    $isencrypt = 0;
    #try to read lmc file
    open FILE, "$LMCTestFile" or $isencrypt=1;

    my $encryptString = "";
    if( $isencrypt == 1 )
    {
        $encryptString = "_encrypted";
        print "\nThe HKP file will be encrypted!\n";
    }
    else
    {
        close( FILE );
        unlink($LMCTestFile);
        print "\nThe HKP file will NOT be encrypted!\n";
    }
          
    my $InputFile = " -i \"$designDIR\\Layout\\LayoutDB.lyt\"";
    $cmd="$commandLayoutDB2HKP $InputFile -o \"$OutputPath\\Layout$encryptString.hkp\"";
    print "\nExecuting ...\n  $cmd \n";
    system( $cmd );

    $InputFile = " -i \"$designDIR\\Layout\\CellDB.cel\"";
    $cmd="$commandCellDB2HKP $InputFile -o \"$OutputPath\\Cell$encryptString.hkp\"";
    print "\nExecuting ...\n  $cmd \n";
    system( $cmd );
    
    $InputFile = " -u mm -i \"$designDIR\\Layout\\JobPrefsDB.jpf\"";
    $cmd="$commandJobPrefsDB2HKP $InputFile -o \"$OutputPath\\JobPrefs$encryptString.hkp\"";
    print "\nExecuting ...\n  $cmd \n";
    system( $cmd );
    
    $InputFile = " -u mm -i \"$designDIR\\Layout\\NetClassDB.ncl\"";
    $cmd="$commandNetClassDB2HKP $InputFile -o \"$OutputPath\\NetClass$encryptString.hkp\"";
    print "\nExecuting ...\n  $cmd \n";
    system( $cmd );
    
    $InputFile = " -u mm -i \"$designDIR\\Layout\\NetPropsDB.npr\"";
    $cmd="$commandNetPropsDB2HKP $InputFile -o \"$OutputPath\\NetProps$encryptString.hkp\"";
    print "\nExecuting ...\n  $cmd \n";
    system( $cmd );
    
    $InputFile = " -i \"$designDIR\\Layout\\PadstackDB.psk\"";
    $cmd="$commandPadstackDB2HKP $InputFile -o \"$OutputPath\\Padstack$encryptString.hkp\"";
    print "\nExecuting ...\n  $cmd \n";
    system( $cmd );
    
    $InputFile = " -u mm -i \"$designDIR\\Layout\\PartsDB.pdb\"";
      $cmd="$commandPartsDB2HKP $InputFile -o \"$OutputPath\\PDB$encryptString.hkp\"";
    print "\nExecuting ...\n  $cmd \n";
    system( $cmd );
 
    if( $isencrypt == 1 )
    {
        print( "\n\nEncrypted HKP files , need to be converted... \n\n");
        my $commandConvertData = "$SddCommonBin\\DataConvert.exe";
        $commandConvertData = Win32::GetShortPathName( $commandConvertData );
        
        $InputFile = " -decrypt -i \"$OutputPath\\Layout$encryptString.hkp\"";
        $cmd="$commandConvertData $InputFile -o \"$OutputPath\\Layout.hkp\"";
        print "\nExecuting ...\n  $cmd \n";
        system( $cmd );
        
        $InputFile = " -decrypt -i \"$OutputPath\\Cell$encryptString.hkp\"";
        $cmd="$commandConvertData $InputFile -o \"$OutputPath\\Cell.hkp\"";
        print "\nExecuting ...\n  $cmd \n";
        system( $cmd );
      
        $InputFile = " -decrypt -i \"$OutputPath\\JobPrefs$encryptString.hkp\"";
        $cmd="$commandConvertData $InputFile -o \"$OutputPath\\JobPrefs.hkp\"";
        print "\nExecuting ...\n  $cmd \n";
        system( $cmd );
        
        $InputFile = " -decrypt -i \"$OutputPath\\NetClass$encryptString.hkp\"";
        $cmd="$commandConvertData $InputFile -o \"$OutputPath\\NetClass.hkp\"";
        print "\nExecuting ...\n  $cmd \n";
        system( $cmd );
        
        $InputFile = " -decrypt -i \"$OutputPath\\NetProps$encryptString.hkp\"";
        $cmd="$commandConvertData $InputFile -o \"$OutputPath\\NetProps.hkp\"";
        print "\nExecuting ...\n  $cmd \n";
        system( $cmd );
        
        $InputFile = " -decrypt -i \"$OutputPath\\Padstack$encryptString.hkp\"";
        $cmd="$commandConvertData $InputFile -o \"$OutputPath\\Padstack.hkp\"";
        print "\nExecuting ...\n  $cmd \n";
        system( $cmd );
        
        $InputFile = " -decrypt -i \"$OutputPath\\PDB$encryptString.hkp\"";
        $cmd="$commandConvertData $InputFile -o \"$OutputPath\\PDB.hkp\"";
        print "\nExecuting ...\n  $cmd \n";
        system( $cmd );
        
        
        print( "\nDelete encrypted files:\n ");
        unlink( "$OutputPath\\Layout$encryptString.hkp" );
        print( "Deleting $OutputPath\\Layout$encryptString.hkp\n");
        
        unlink( "$OutputPath\\Cell$encryptString.hkp" );
        print( "Deleting $OutputPath\\Cell$encryptString.hkp\n");
        
        unlink( "$OutputPath\\JobPrefs$encryptString.hkp" );
        print( "Deleting $OutputPath\\JobPrefs$encryptString.hkp\n");
        
        unlink( "$OutputPath\\NetClass$encryptString.hkp" );
        print( "Deleting $OutputPath\\NetClass$encryptString.hkp\n");
        
        unlink( "$OutputPath\\NetProps$encryptString.hkp" );
        print( "Deleting $OutputPath\\NetProps$encryptString.hkp\n");
        
        unlink( "$OutputPath\\Padstack$encryptString.hkp" );
        print( "Deleting $OutputPath\\Padstack$encryptString.hkp\n");
        
        unlink( "$OutputPath\\PDB$encryptString.hkp" );
        print( "Deleting $OutputPath\\PDB$encryptString.hkp\n");
        
        my $isDecryptedSuccss = 1;
        #try to read Layout.hkp
        open FILE, "$OutputPath\\Layout.hkp" or $isDecryptedSuccss = 0;
        if( $isDecryptedSuccss == 0 )
        {   
            print "\n Generation of viewable failed because \"DataConvert\" license key is missing.\n";
            print " Please contact Mentor Graphics support.\n";
            print "\n <hit RETURN to continue>";
            $tempWait=<STDIN>;
        }
    }
    exit 0;
}
else
{
    print "\nNo valid board (PCB) file was selected or available for exporting CAD (HKP) files.\n";
    print "You will be asked to select CAD (HKP) file directly from your file system.\n";
    print "Please make sure to select a right CAD (HKP) file or cancel the operation.\n";
    print "\n<hit RETURN to continue>";
    $tempWait=<STDIN>;
    exit 1;
}

sub pickFile
{
    my ($currentFile, $yesno);
    ($currentFile)=@_;
    $yesno = "";
    while ( $yesno ne 'y' and $yesno ne 'n' )
    {
        print "$currentFile (y/n): ";
        $yesno=<STDIN>;
        chomp $yesno;    # remove new line character
        $yesno = lc( $yesno );
    }

    if( $yesno eq 'y' )
    {
       return( $currentFile );
    }
    else
    {
        return( "" );
    }
}

