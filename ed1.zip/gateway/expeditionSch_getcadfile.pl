#!/usr/bin/perl
use File::Basename;

# Copyright 2010 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
# =============================================================
# Copyright 2008.
# Siemens Product Lifecycle Management Software Inc.
# All Rights Reserved.
# =============================================================
# Copyright 2010 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
#
# This script is an EDA Gateway callback for extractCADFromSchematic
#
#==============================================================

# validate inputs

#$get = <STDIN>;
if( @ARGV != 2)
{
    print "Usage: expeditionSch_getcadfile <design folder> <CAD file folder>\n";
    exit 1;
}

my $InputPath = $ARGV[0];
my $OutputPath = $ARGV[1];
if( opendir( CAD_DIR, $OutputPath ) )
{
    print "\n Try to clean the output folder.\n";
    @cadFiles=grep( !/^\.\.?$/, readdir CAD_DIR );
    if( @cadFiles > 0 )
    {
       system( "del /Q /F /S $OutputPath\\*" );
    }
    close( CAD_DIR );
}
else
{
    system( "md $OutputPath" );
}

#get design folder ,get prj file
opendir( DESIGN_DIR, $InputPath ) || die "Cannot open $InputPath: $!";
@prjFiles=grep( /\.prj$/i, readdir DESIGN_DIR );
$prjSize=@prjFiles;
#if the Project extension is not prj, it is a EE2005 Design which has dproj extension
my $isEE2005Version = 0 ;
if( $prjSize == 0 )
{
    rewinddir DESIGN_DIR;
    @prjFiles=grep( /\.dproj$/i, readdir DESIGN_DIR );
    $prjSize=@prjFiles;
    if( $prjSize > 0 )
    {
        $isEE2005Version = 1;
    }
}
close( DESIGN_DIR );


# Check a prj or dproj file
$DXDesignPrjFile="";
if( $prjSize == 1 )
{
    $DXDesignPrjFile=$prjFiles[0];
    
}
elsif ( $prjSize == 0 )
{
    print "\nNo project file can be found in $InputPath \n";
}
else
{
    print qq(\nSelect an DXDesign Project file from the following list\n);
    print qq(\nThis is required to export CAD (edif) file\n\n);
    foreach( @prjFiles )
    {
        print "$_\n";
    }

    print "\n\n";

    foreach( @prjFiles )
    {
        $DXDesignPrjFile=pickFile( $_ );
        last if( $DXDesignPrjFile );
    }
}

if ( $DXDesignPrjFile )
{
    my $SddCommonBin = $ENV{"SDD_COMMON_BIN"};
    $DXDesignPrjPath = "$InputPath\\$DXDesignPrjFile";
    my ($designName,$designDIR,$ext) = fileparse($DXDesignPrjPath, qr/\.[^.]*/);
    my $command = "$SddCommonBin\\MGSWrite.bat";

    $command = Win32::GetShortPathName( $command );

    #For EE2005 version 
    if( $isEE2005Version == 1 )
    {
        my $schematicName = getSchematic2005( $designDIR );
        my $targetFile = "-export -o \"${ARGV[1]}\\$designName.edif\"";
        #must change to design directory first and invoke the MGSWrite,
        #So the utility can find the viewdraw.ini in design folder.
        chdir( $designDIR );
        print "\n Work on EE2005 Design:\n";
        $cmd=(" \"$schematicName\" $targetFile");
    }
    else
    {
        #For EE2007.6 and later version, check the dataconvert and create archive folder 
        #There is a problem after EE2007.6: Every time invoking the MGSWrite.exe, the database of design
        #will be used by EE, so zip the design to TC will be rejected.
        my $dataconvertPath = "$SddCommonBin\\DataConvert.exe";
        print "\n Check the dataconvert at $dataconvertPath\n";
        if( -e $dataconvertPath )
        {
            my $copyDesignPath = Create_Archive( $DXDesignPrjPath );
            if( -e $copyDesignPath )
            {
                print "\n Now using copy design to extract edif! \n";
                print "\n The copyDesignPath is: $copyDesignPath\n";
                print "\n Work on EE2007.6 and later version Design:\n";
                $DXDesignPrjPath = $copyDesignPath;
            }
        }
        else
        {
            print "\n Work on EE2007.2 Design:\n";
        }
        ($newdesignName,$newdesignDIR,$ext) = fileparse($DXDesignPrjPath, qr/\.[^.]*/);
        my $icdbFile = "-icdb \"$newdesignDIR\\database\"";
        my $schematic = getSchematic($DXDesignPrjPath);
        print "\nGet schematic name: $schematic from project: $DXDesignPrjPath! \n";
        my $schematiccmd ="-ischematic \"$schematic\"";
        my $targetFile = "-o \"$OutputPath\\$designName.edif\"";
        $cmd=("$icdbFile $targetFile $schematiccmd");
    }
   
    print "\nExecuting ...\n$command  $cmd\n";
    system( $command , $cmd );
    
    exit 0;
}
else
{
    print "\nNo valid board file was selected or available for exporting CAD (edif) file.\n";
    print "You will be asked to select CAD (edif) file directly from your file system.\n";
    print "Please make sure to select a right CAD (edif) file or cancel the operation.\n";
    print "\n<hit RETURN to continue>";
    $tempWait=<STDIN>;
    exit 1;
}

sub pickFile
{
    my ($currentFile, $yesno);
    ($currentFile)=@_;
    $yesno = "";
    while ( $yesno ne 'y' and $yesno ne 'n' )
    {
        print "$currentFile (y/n): ";
        $yesno=<STDIN>;
        chomp $yesno;    # remove new line character
        $yesno = lc( $yesno );
    }

    if( $yesno eq 'y' )
    {
       return( $currentFile );
    }
    else
    {
        return( "" );
    }
}
sub getSchematic
{
    $prjPath = $_[0];
 
    if( -f $prjPath && $prjPath=~/\.prj$/i)
    {
        my $rt = open( PRJFILE, $prjPath );
        if( $rt == 0 )
        {
            print "Cannot read $prjPath: $!";
            print "\n<hit RETURN to continue>";
            $tempWait=<STDIN>;
        }
        my $line = "";
        while ( $line = <PRJFILE> )
        {
            if( $line =~ /KEY RootBlock/ )
            {
                $line =~ s/KEY RootBlock "//i;
                $line =~ s/"//i;
                 close PRJFILE;
                return $line;
            }
        }
     }    
}

sub getSchematic2005
{
    my $schematicDir = "$_[0]\\sch";
	
	
	opendir( SCHEMATIC_DIR, $schematicDir ) || die "Cannot open $schematicDir: $!";
	my @schematicFiles=grep( /\.1$/i, readdir SCHEMATIC_DIR );
	my $schematicSize=@schematicFiles;
	close( SCHEMATIC_DIR );


	# Check a schematic file
	my $schematicFile="";
	if( $schematicSize == 1 )
	{
		$schematicFile=$schematicFiles[0];
		
	}
	elsif ( $schematicSize == 0 )
	{
		print "\nNo schematic file can be found in $schematicDir \n";
	}
	else
	{
		print qq(\nSelect an schematic file from the following list\n);
		print qq(\nThis is required to export CAD (edif) file\n\n);
		foreach( @schematicFiles )
		{
			print "$_\n";
		}

		print "\n\n";

		foreach( @schematicFiles )
		{
			$schematicFile=pickFile( $_ );
			last if( $schematicFile );
		}
	}
	my ($schematicName,$ext) = fileparse($schematicFile, qr/\.[^.]*/);
	print "\nGet schematic name from EE2005 sch folder: $schematicName\n";
	return $schematicName;
}

sub Create_Archive
{
    $prjPath = $_[0];
    my ($designName,$designDIR,$ext) = fileparse($prjPath, qr/\.[^.]*/);
    my $SddHome = $ENV{"SDD_HOME"};
    if( -f $prjPath && $prjPath=~/\.prj$/i)
    {
        my $tempPath = $ENV{"TEMP"};
        if( !$tempPath )
        {
            $tempPath = $ENV{"TMP"};
            if( !$tempPath )
            {
                $tempPath = $ENV{"TMPDIR"};
                if( !$tempPath )
                {
                    print "\n Can not find Temp folder in Environment Variable: TEMP, TMP, TMPDIR. \n ";
                    print "\n Please make sure you have set it. \n ";
                    print "\n <hit RETURN to continue>";
                    $tempWait=<STDIN>;
                    exit 1;
                }
            }
        }
        
        my $randnum = int( rand(10000) );
        my $archiveDir = "$tempPath\\expeditionArchiveDir";
        print "\n Create copy design at : $archiveDir \n";
        #create copy design path:
        if( opendir( ARCHIVE_DIR, $archiveDir ) )
        {
           print "\n Try to delete the archive folder.\n";
           #remove the archive
           close( ARCHIVE_DIR );
           system( "rmdir /Q /S $archiveDir" );
        }
        
        system( "md $archiveDir" );
        
        my $DxarchiverPath = "$SddHome\\wv\\win32\\bin\\dxarchiver.exe";
        $DxarchiverPath = Win32::GetShortPathName($DxarchiverPath);

        my $designPath = " -nogui -p \"$prjPath\"";
        my $targetPath = " -t \"$archiveDir\\$designName$randnum\"";
        my $archiveLogFile = " -l \"$archiveDir\\$designName$randnum\.log\"";
        my $cmd = "$designPath $targetPath $archiveLogFile";
        print "\nExecuting ...\n$DxarchiverPath  $cmd\n";
        system( $DxarchiverPath,$cmd );
                   
        my $copyDesignPath = "$archiveDir\\$designName$randnum\\$designName$ext";
        if( -e $copyDesignPath )
        {
            print "\n SUCCESS to use dxarchiver!\n";
            print "Create copy design at : $copyDesignPath\n";
            return $copyDesignPath;
        }
        else
        {
            print "\n Fail to use dxarchiver! The copy Design Path is: $copyDesignPath \n";
            return "";
        }
    }
}

