#!/usr/bin/perl

# Copyright 2015 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
# =============================================================
# Copyright 2008.
# Siemens Product Lifecycle Management Software Inc.
# All Rights Reserved.
# =============================================================
# Copyright 2015 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
#
# This script is called by Gateway callback for openDesign and reOpenDesign  
#
# ==============================================================

# validate inputs
if( @ARGV != 1)
{
    print "Usage: orcadlayout_opendesign <design folder>\n";
    exit 1;
}

# get list of files with file extension .max
opendir( DESIGN_DIR, $ARGV[0] ) || die "Cannot open $ARGV[0]: $!";
@maxFiles=grep( /\.max$/i, readdir DESIGN_DIR );
$maxSize=@maxFiles;
close( DESIGN_DIR );

# get/select a max file
$layoutBrdFile="";
if( $maxSize == 1 )
{
    $layoutBrdFile=$maxFiles[0];
    
}
elsif ( $maxSize == 0 )
{
    print "\nNo board (max) file can be found in $ARGV[0] \n";
}
else
{
    print qq(\nSelect an OrCAD Layout board (MAX) file from the following list to open\n\n);
    foreach( @maxFiles )
    {
        print "$_\n";
    }

    print "\n\n";

    foreach( @maxFiles )
    {
        $layoutBrdFile=pickFile( $_ );
        last if( $layoutBrdFile );
    }
}

if ( $layoutBrdFile )
{
    my $cdsRoot = $ENV{"CDSROOT"};
    my $command = "$cdsRoot\\tools\\layout\\lsession";
    my $sourceFile = "${ARGV[0]}\\${layoutBrdFile}";
    print "\nExecuting ...\n  $command $sourceFile\n";
    my @args = ( $command, $sourceFile );
    system( @args );
    exit 0;
}
else 
{
    print "\nLayout was not started because no board (max) file was selected or existed\n";
    print "\n<hit RETURN to continue>";
    $tempWait=<STDIN>;
    exit 1;
}

sub pickFile 
{
    my ($curerntFile, $yesno);
    ($currentFile)=@_;
    $yesno = "";
    while ( $yesno ne 'y' and $yesno ne 'n' )
    {
        print "$currentFile (y/n): ";
        $yesno=<STDIN>;
        chomp $yesno;    # remove new line character
        $yesno = lc( $yesno );
    }

    if( $yesno eq 'y' ) 
    {
       return( $currentFile );   
    }
    else 
    {
        return( "" );
    }
}
