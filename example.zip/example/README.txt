Contents:
=========
  - Proprietary & Restricted Rights Notice
  - Introduction
  - Contents
  - Directory structure
  - Prerequisites
-------------------------------------------------------------------------

Proprietary & Restricted Rights Notice:
=======================================
This software and related documentation are proprietary to Siemens Product
Lifecycle Management Software Inc. @2015 Siemens Product Lifecycle Management
Software Inc. All Rights Reserved. All trademarks belong to their respective
holders.

-------------------------------------------------------------------------

Introduction:
=============
This file describes the contents of the (EDA) "example" directory.

-------------------------------------------------------------------------

Contents:
=========
The following folders and components are included in this folder:

  1) Callback           Contains source and sample build scripts for examples
                        of embedded callbacks. The examples are for java and
                        script callback types. These examples illustrate ways
                        in which embedded callbacks can be written for an
                        EDA Client. The sample build scripts
                        for both, WINDOWS and UNIX environment, are included
                        which will help to build callback source code. These
                        scripts are basically written taking into consideration
                        callback examples provided. These scripts might need
                        to be modified as per build the environment where
                        callbacks are being compiled.

   2) config            Contains configuration sample for EDA Callbacks. This
                        file shows how to configure EDA callbacks for an EDA
                        client for an application like, 'schematic'.

   3) docs              Contains documentation for callbacks and javadoc for
                        EDA Design and EDA Status APIs. EDA XML file schema and
                        associated java API are subject to change from release
                        to release.

-------------------------------------------------------------------------

Directory structure:
===================
The various components of EDA Callback Examples (described above) are
arranged in a typical directory structure.

    Folder              Content
    -------             --------------
    Callback            Source code for java and script callback examples and
                        build scripts.

    Callback\java       Folder 'java' contains java classes for java callback
                        examples.

    Callback\scripts    Contains scripts for callback examples.

    Callback\build      Contains sample build scripts for WINDOWS and UNIX
                        environments for the callback examples. The scripts are
                        provided as examples. You might need to modify them
                        according to your build environment.
                        See the instructions in the scripts for details.

    config              Contains sample configuration XML files for
                        EDA Callbacks.

    docs                Contains documentation for EDA Callback examples.

-------------------------------------------------------------------------

Prerequisites:
=============
For prerequisites of setting up and using EDA Callbacks refer to the
documentation of EDA Callbacks.

-------------------------------------------------------------------------
