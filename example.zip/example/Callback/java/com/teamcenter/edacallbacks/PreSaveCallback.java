// Copyright 2015 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
// ==================================================
// Copyright 2009.
// Siemens Product Lifecycle Management Software Inc.
// All Rights Reserved.
// ==================================================
// Copyright 2015 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.

package com.teamcenter.edacallbacks;

import com.teamcenter.edabase.EDACancelException;
import com.teamcenter.edabase.EDAException;
import com.teamcenter.edaxsd.edaDesign.CCAVariantType;
import com.teamcenter.edaxsd.edaDesign.EDADesignType;
import java.io.FileReader;
import java.io.Reader;
import java.util.Iterator;
import java.util.List;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.Unmarshaller;
import org.apache.log4j.Logger;
import org.xml.sax.InputSource;

public class PreSaveCallback
{
    /** log4j logger */
    private static final Logger s_logger = Logger.getLogger( PreSaveCallback.class );

    public PreSaveCallback()
    {
    }

    /**
     * This method provides implementation for 'preSave' 
     * callback. When 'save' operation is performed, before
     * the operation 'preSave' callback is called. This 
     * method shows hot to abort the main eda operation 
     * (here 'save') using callback. The method accepts 
     * parameters, 'application' (application name) and 
     * 'edaDesignFileName' (eda design file name). EDA Design 
     * object is extracted from eda design xml using JAXB. 
     * Variant inputs from EDA Design are checked for 'isBOM' 
     * option. If this option is false for at least one variant,
     * the method throws EDACancelException. As a result 'save'
     * operation is aborted.     
     * 
     * @param application -- application name (schematic, simulation or pcb)
     * @param edaDesignFileName -- EDADesign XML
     * @throws EDAException
     */

    public void checkCCAItemStatusForSave( String application,
            String edaDesignFileName )
        throws EDAException
    {
        s_logger.debug( "Starting preSave callback" );
        boolean stopSaveFlag = false;
        EDADesignType edaDesign = null;
        try
        {
            edaDesign = ( (JAXBElement<EDADesignType>) unmarshalFile(
                    edaDesignFileName, "com.teamcenter.edaxsd.edaDesign" ) ).getValue();
            List<CCAVariantType> variants = edaDesign.getCCA().getCCAVariant();
            boolean isBOM = true;
            // Check BOM value for variants. If one or more of
            // them has isBom false, abort save.
            for( Iterator<CCAVariantType> itr = variants.iterator(); itr.hasNext(); )
            {
                CCAVariantType variant = itr.next();
                if( !variant.isBom() )
                {
                    isBOM = false;
                    break;
                }
            }
            if( !isBOM )
            {
                stopSaveFlag = true;
                s_logger.warn( "Aborting save in PreSave callback...." );
            }
        }
        catch( EDAException e )
        {
            
        }
        if( stopSaveFlag )
        {
            throw new EDACancelException( "Design variants set without BOM. Save will be aborted." );
        }
    }
    
    /**
     * This method extracts object from the XML file provided 
     * to it. The namespace value, provided as in input, is 
     * namespace of the object which is marshaled in the 
     * XML file. This method is used to fetch the EDADesign and 
     * EDAStatus objects from EDADesign XML and EDA Status XML.
     * It internally uses JAXB API to extract the object from XML.
     * 
     * @param fileName  - the name of the file to be unmarshalled
     *                    and from which the object is to be extracted.
     * @param namespace - the namespace of the object 
     *                    to be extracted
     * @return The object extracted from the input xml file.
     * @throws EDAException
     * 
     */
    private Object unmarshalFile( String fileName, String namespace )
        throws EDAException
    {
        Object object = null;
        if( fileName == null )
        {
            throw new EDAException( "PreSaveCallback.unmarshalFile:: Null file name." ); //$NON-NLS-1$
        }
        try
        {
            FileReader fileReader = new FileReader( fileName );
            object = unmarshal( fileReader, namespace );
        }
        catch( Exception e )
        {
            throw new EDAException( e );
        }
        return object;
    }

    /**
     * This method is called from method 'unmarshalFile'. It uses
     * JAXB API to extract object from the input Reader object. 
     * 
     * @param reader -- File reader
     * @param namespace - Namespace of the object
     * @return The extracted object
     * @throws EDAException
     * 
     */
    private Object unmarshal( Reader reader, String namespace )
        throws EDAException
    {
        Object object = null;
        try
        {
            JAXBContext jc = JAXBContext.newInstance( namespace );
            Unmarshaller unmarshaller = jc.createUnmarshaller();

            InputSource inputSource = new InputSource( reader );
            object = unmarshaller.unmarshal( inputSource );

            reader.close();
        }
        catch( Exception e )
        {
            throw new EDAException( e );
        }
        return object;
    }
}
