// Copyright 2015 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
// ==================================================
// Copyright 2012.
// Siemens Product Lifecycle Management Software Inc.
// All Rights Reserved.
// ==================================================
// Copyright 2015 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.

package com.teamcenter.edacallbacks;

import com.teamcenter.edabase.EDAException;
import com.teamcenter.edabase.model.DerivedDatasetNamingInfo;
import com.teamcenter.edabase.utils.TcEDALogger;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import org.apache.log4j.Logger;

/**
 * A java callback for naming Derived Dataset
 */
public class NameDerivedDatasetCallback
{
    /** log4j logger */
    private static final Logger s_logger = Logger.getLogger( NameDerivedDatasetCallback.class );
    
    /**
     * Constructor
     */
    public NameDerivedDatasetCallback()
    {

    }

    /**
     * This method provides implementation for 'nameDerivedDataset' callback.
     * While performing Save As, Save, Check in and Save Derived Data
     * operations, at the time of naming Derived Dataset on Derived Dataset
     * Table page, the operation 'nameDerivedDataset' callback will be executed
     * to name Derived Dataset. The Derived Dataset name constructed and
     * returned from this method will be used as the default name for the
     * Derived Dataset. This callback will be exectued once for each Derived
     * Dataset row on the Derived Dataset Table page. If this method returns
     * null or an empty string then the Derived Dataset name will be defaulted
     * to the name constructed using Derived Dataset configuration definition.
     * This method accepts two parameters, 'application' (application name) and
     * 'DerivedDatasetNamingInfo' (DerivedDatasetNamingInfo class object). The
     * class DerivedDatasetNamingInfo has accessor methods to retrieve
     * information about current Derived Dataset's parent Item Id, sibling
     * Derived Dataset names, Derived Dataset configuration definition
     * information etc.
     * 
     * @param application -- application name
     * @param DerivedDatasetNamingInfo -- DerivedDatasetNamingInfo class object
     * @return -- returns Derived Dataset name constructed in this method or
     *         null otherwise
     * @throws EDAException
     */
    public String nameDerivedDataset( String application,
            DerivedDatasetNamingInfo derivedDatasetNamingInfo )
        throws EDAException
    {
        /*
         * The below implementation is an example to name Derived Datasets. This
         * method names each Derived Dataset with parent Item Id appended with
         * single postfix letter. The postfix letter starts with letter 'A' and
         * will be incremented for each Derived Dataset under the same parent.
         * For example, if parent Item Id is 000456 with three Derived Datasets
         * under it, then the first Derived Dataset under parent Item Id 000456
         * will be 000456A and the next two Derived Datasets will be 000456B and
         * 000456C. If there are many Derived Datasets under same parent and all
         * letters from 'A' to 'Z' are already used as postfix letters for
         * naming Derived Datasets then the next postfix letter would be the
         * character '['. This postfix letter continues to increment for the
         * next sibling Derived Dataset.
         */
        TcEDALogger.entering( "NameDerivedDatasetCallback",
                "nameDerivedDataset" );

        String derivedDatasetName = null;
        String parentItemId = derivedDatasetNamingInfo.getParentItemID();
        char postFixLetter = 'A';
        boolean postFixLetterFound = false;

        try
        {
            String[] siblingDerivedDatasetNames = derivedDatasetNamingInfo.getSiblingDerivedDatasetNames();

            // Check for the sibling Derived Dataset names
            if( siblingDerivedDatasetNames != null
                    && siblingDerivedDatasetNames.length > 0 )
            {
                List<Character> postFixLettersList = new ArrayList<Character>();
                for( int i = 0; i < siblingDerivedDatasetNames.length; i++ )
                {
                    // Get the sibling Derived Data name
                    String siblingDerivedDatasetName = siblingDerivedDatasetNames[i];

                    // Get the last letter and add it to the postFixLettersList
                    char lastLetter = siblingDerivedDatasetName.charAt( siblingDerivedDatasetName.length() - 1 );
                    Character tempCharacter = new Character( lastLetter );
                    postFixLettersList.add( lastLetter );
                }

                /*
                 * The postFixLettersList may contain any characters. It may not
                 * be the continuous list. We cannot assume that the next
                 * postfix letter would be the next highest postfix from the
                 * existing postFixLettersList. For example, if there are three
                 * Derived Datasets under the same parent Item Id on Derived
                 * Datasets Table page, then for a second Derived Dataset the
                 * sibling Derived Datasets can have 'A' and 'C' as postfix
                 * letters. In this case, the next postfix letter should be 'B'
                 * and not 'D'. So, we need to traverse the postFixLettersList
                 * to find the next postfix letter.
                 */

                // Increment postfix letter 'A', postFixLettersList.size() times
                for( int i = 0; i < postFixLettersList.size(); i++ )
                {
                    postFixLetter++;
                }

                for( int i = 0; i < postFixLettersList.size(); i++ )
                {
                    /*
                     * Check if the postfix letter already exists in the
                     * postFixLettersList
                     */
                    if( postFixLettersList.get( i ).charValue() == postFixLetter )
                    {
                        postFixLetterFound = true;
                        break;
                    }
                }

                if( !postFixLetterFound )
                {
                    /*
                     * If postfix letter not found in postFixLettersList then
                     * append postfix letter to parent Item Id
                     */
                    derivedDatasetName = parentItemId + postFixLetter;
                }
                else
                {
                    if( postFixLettersList.size() == 1 )
                    {
                        /*
                         * If postfix letter is found in postFixLettersList and
                         * the list size is 1 then decrement post fix letter and
                         * append it parent Item Id
                         */
                        postFixLetter--;
                        derivedDatasetName = parentItemId + postFixLetter;
                    }
                    else if( postFixLettersList.size() > 1 )
                    {
                        /*
                         * If the postFixLettersList list size is greather than
                         * 1 first sort the list.
                         */
                        Collections.sort( postFixLettersList );

                        for( int i = 0; i < postFixLettersList.size() - 1; i++ )
                        {
                            // Get the characters at index i and i+1
                            Character charater1 = postFixLettersList.get( i );
                            Character charater2 = postFixLettersList.get( i + 1 );

                            char firstLetter = charater1.charValue();
                            char nextLetter = charater2.charValue();

                            /*
                             * Increment the character at index i and check with
                             * character at index i+1
                             */
                            firstLetter++;
                            if( firstLetter == nextLetter )
                            {
                                /*
                                 * If end of the list is reached then postfix
                                 * letter should be the first letter.
                                 */
                                if( i + 1 == postFixLettersList.size() - 1 )
                                {
                                    postFixLetter = 'A';
                                    derivedDatasetName = parentItemId
                                            + postFixLetter;
                                    break;
                                }
                            }
                            else
                            {
                                postFixLetter = firstLetter;
                                derivedDatasetName = parentItemId
                                        + postFixLetter;
                                break;
                            }
                        }
                    }
                }
            }
            else
            {
                /*
                 * If there are no sibling Derived Datasets, then this is the
                 * first Derived Dataset. Append postfix letter 'A' to the
                 * parent Item Id.
                 */
                derivedDatasetName = parentItemId + postFixLetter;
            }
        }
        catch( Exception e )
        {
            throw new EDAException( e );
        }

        TcEDALogger.exiting( "NameDerivedDatasetCallback", "nameDerivedDataset" );

        return derivedDatasetName;
    }
}
