// Copyright 2015 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.
// ==================================================
// Copyright 2014.
// Siemens Product Lifecycle Management Software Inc.
// All Rights Reserved.
// ==================================================
// Copyright 2015 Siemens Product Lifecycle Management Software Inc. All Rights Reserved.

package com.teamcenter.edacallbacks;

import com.teamcenter.edabase.EDAConfiguration;
import com.teamcenter.edabase.EDAException;
import com.teamcenter.edabase.model.ECADComponentValidationInfo;
import com.teamcenter.edabase.services.IDataManagementService;
import com.teamcenter.edabase.utils.TcEDALogger;
import com.teamcenter.soa.client.model.ModelObject;
import com.teamcenter.soa.client.model.strong.WorkspaceObject;
import com.teamcenter.soa.exceptions.NotLoadedException;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import org.apache.log4j.Logger;

/**
 * A Callback to validate that a Teamcenter Item is an ECAD component
 */
public class ValidateECADComponents
{
    /** log4j logger */
    private static final Logger s_logger = Logger.getLogger( ValidateECADComponents.class );
    
    /** validateECADComponents method identifier */
    private static final String VALIDATEECADCOMPONENTS = "validateECADComponents"; //$NON-NLS-1$

    /**
     * Constructor
     *
     */
    public ValidateECADComponents()
    {

    }

    /**
     * Implementation of customized logic to validate that Teamcenter objects
     * specifed as components in an ECAD design are indeed electrical components
     * that can be used in ECAD designs according to Teamcenter. This callback
     * overrides the EDA Common Client COTS component validation by item type.
     * 
     * EDA operations that consume BOM information from the ECAD design, require
     * that each ECAD component specified in the ECAD design is validated to
     * insure it is an ECAD component according to Teamcenter. EDA Common Client
     * will activate this callback provided that it is configured in the
     * appropriate EDA Application Configuration file(s).
     * 
     * A single object is passed to this method that provides for all the input
     * and output information necessary to perform validation of all ECAD
     * component candidates for an operation. Candidates are those objects
     * returned from a Teamcenter query for the Item Ids specified in the
     * operation BOM(s). For customers utilizing multi-field keys for their ECAD
     * component items, a query by item ID may return multiple candidate
     * objects. Each candidate must be validated, to determine the specific
     * Teamcenter item that is the valid ECAD component.
     * 
     * Validation is performed analyzing specific properties and values of each
     * candidate object in the context of the ECAD component according to
     * customer requirements.
     * 
     * @param application The application name.
     * @param ecadComponentValidationInfo An ECADComponentValidationInfo class
     *            object. This object provides for both input and output
     *            information required to validate ECAD component items.
     * @throws EDAException In the case of an error
     */
    public void validateECADComponents( String application,
            ECADComponentValidationInfo ecadComponentValidationInfo )
        throws EDAException
    {
        /*
         * For each ECAD component specified in the EDA operation BOMs...
         */
        String itemId = ecadComponentValidationInfo.getFirstComponentItemIdToValidate();
        while( itemId != null )
        {
            /*
             * For each ECAD component candidate...
             *
             * NOTE: Normally there will be a single component candidate. However,
             * if component objects have multi-field keys, each object with
             * the same Item ID will be include in the set of candidates.
             *
             * NOTE: If the component has not yet been created in Teamcenter,
             * there will be zero candidates.
             */

            // System.out.println( "Item ID: " + itemId );
            String candidateUID = ecadComponentValidationInfo.getFirstComponentCandidateUIDToValidate();
            while( candidateUID != null )
            {
                /*
                 * Get the candidate model object
                 */
                // System.out.println( "  Candidate UID: " + candidateUID );
                ModelObject modelObj = ecadComponentValidationInfo.getComponentCandidateObj( candidateUID );
                if( modelObj != null )
                {
                    /*
                     * Validate the candidate based on object propeties
                     */
                    if( modelObj instanceof WorkspaceObject )
                    {
                        WorkspaceObject wso = (WorkspaceObject) modelObj;

                        /*
                         * If the candidate is a valid ECAD component
                         */
                        if( isValidComponent( wso ) )
                        {
                            /*
                             * Record the candidate as a validated component
                             */
                            ecadComponentValidationInfo.recordValidatedComponentCandidate( candidateUID );
                        }
                    }
                }
                candidateUID = ecadComponentValidationInfo.getNextComponentCandidateUIDToValidate();
            }
            itemId = ecadComponentValidationInfo.getNextComponentItemIdToValidate();
        }
    }

    /**
     * Examine the appropriate properties of a Teamcenter Item to determine
     * if it is a valid ECAD component.
     *
     * @param item The Teamcenter Item to be validated.
     * @return true in the case that the item is a valid ECAD component, false otherwise.
     * @throws EDAException In the case of an error
     */
    private boolean isValidComponent( WorkspaceObject wso )
        throws EDAException
    {
        boolean retValue = false;

        /*
         * The below implementation is an example of a simple validation of the
         * Teamcenter item type.
         *
         * Note that item type is used to control the property
         * values to examine.
         */

        String objectType = getObjectType(wso);
        // System.out.println( "    ObjectType: " + objectType );

        /*
         * If Workspace object type is EDAComp
         * AND ...
         * OR ...
         */
        if( objectType != null && objectType.equals( "EDAComp" ) )
        {
            /* EDAComp object candidate is a component */
            retValue = true;
        }
        /*
         * Else if Workspace object type is Foo (Foo is an example object)
         * AND bar property value is qux
         * OR ...
        else if( objectType != null && objectType.equals( "Foo" ) )
        {
            * If all the properties of Foo object indicate an ECAD component *
            String bar = getBar(wso); // bar is an example property
            if( bar != null && bar.equals( "qux" ) ) // qux is an example property value
            {
                * Foo object candidate is a component *
                retValue = true;
            }
        }
         */

        // System.out.println( "      " + (retValue ? "is valid" : "is NOT valid") );
        return retValue;
    }

    /**
     * Get the object type property value of a Workspace object.
     *
     * @param item The Teamcenter Workspace object of interest.
     * @return The Workspace object type.
     * @throws EDAException In the case of an error
     */
    private String getObjectType( WorkspaceObject wso )
        throws EDAException
    {
        String objectType = null;

        /*
         * If a property has not already been loaded with the object,
         * a NotLoadedException will be thrown when the property is accessed.
         * In this case, the property can be loaded explicitly in the exception catch
         * block.
         *
         * This is an example of handling the NotLoadedException. The property
         * object_type is already specified in the EDA Client policy file.
         */

        try
        {
            objectType = wso.get_object_type();
        }
        catch( NotLoadedException nle )
        {
            try
            {
                IDataManagementService dataMgmtService = EDAConfiguration.getInstance().getFactory().getServiceFactory().getDataManagementService();
                String[] propNames = new String[1];
                propNames[0] = "object_type";
                dataMgmtService.getProperties( wso, propNames );
                objectType = wso.get_object_type();
            }
            catch( NotLoadedException nle2 )
            {
                throw new EDAException( nle2 );
            }
        }

        return objectType;
    }

    /**
     * Get the bar property of a Foo object
     *
     * @param item The Teamcenter workspace object of interest.
     * @return The Foo object bar property value, or null if the WorkSpace object is not a Foo
     * @throws EDAException In the case of an error
     *
    private String getBar( WorkspaceObject wso )
        throws EDAException
    {
        FooObject fo = null;
        String bar = null;

        try
        {
            if( wso instanceof FooObject )
            {
                fo = (FooObject)wso;
                {
                    bar = fo.get_bar();
                }
            }
        }
        catch( NotLoadedException nle )
        {
            * bar property was not already loaded, load it now *
            try
            {
                dataMgmtService = EDAConfiguration.getInstance().getFactory().getServiceFactory().getDataManagementService();
                String[] propNames = new String[1];
                propNames[0] = "bar";
                dataMgmtService.getProperties( fo, propNames );
                bar = fo.get_bar();
            }
            catch( NotLoadedException nle2 )
            {
                throw new EDAException( nle2 );
            }
        }

        return frazmus;
    }
     */

}
