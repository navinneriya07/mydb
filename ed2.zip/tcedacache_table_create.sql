create table edacacheversion
(
cachekey VARCHAR(32) NOT NULL primary key,
cacheversion int
)
;
-- Whenever cache schema is changed, please increment the cache version number
-- and also modify EDA_CACHE_VERSION in EDACache.java to match the chnages.
insert into edacacheversion values
(
'CACHEKEY',
5
)
;
create table dataset
(
uid VARCHAR(64) NOT NULL primary key,
source VARCHAR(256),
datasettype VARCHAR(32) NOT NULL,
datasetname VARCHAR(128) NOT NULL,
datasetdesc VARCHAR(240),
checkedout VARCHAR(1) NOT NULL,
nonlatest VARCHAR(1) NOT NULL,
sub VARCHAR(1) NOT NULL,
version int
)
;
create table library
(
name VARCHAR(64) NOT NULL,
path VARCHAR(256) NOT NULL,
primary key (name)
)
;
exit;
